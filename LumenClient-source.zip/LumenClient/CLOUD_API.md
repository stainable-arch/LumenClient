# Lumen Config Cloud: server API

The client (`CloudClient.java`) expects a server with this REST API. All bodies are JSON.
Set the address in game with `/lumen cloud url https://your-server`, open the screen with `/lumen cloud`.

## Sign-in (Minecraft account)
1. `GET /v1/auth/challenge` -> `{"serverId": "<random string>"}`
2. The client calls Mojang `joinServer(profile, accessToken, serverId)`.
3. `POST /v1/auth/login` `{"name","uuid","serverId"}` -> the server verifies with
   `GET https://sessionserver.mojang.com/session/minecraft/hasJoined?username=<name>&serverId=<serverId>`
   and returns `{"token": "<bearer token>"}`. Reject if `hasJoined` fails or the id doesn't match `uuid`.
   Challenges should be single use and expire after a minute or two.

Authenticated calls send `Authorization: Bearer <token>`; return 401 when it is missing/expired
(the client signs in again once and retries).

## Configs
| Call | Auth | Result |
|---|---|---|
| `GET /v1/configs?q=<text>` | no | array of public configs `{id,name,author,description,visibility,downloads}` |
| `GET /v1/configs/{id}` | for private | `{id,name,author,...,"data":{...config json...}}`; private only for its owner (404 otherwise). Public downloads count +1 |
| `GET /v1/my/configs` | yes | array of the caller's configs (public + private) |
| `POST /v1/configs` | yes | body `{name,description,visibility:"public"|"private",data}` -> `{id}` |
| `DELETE /v1/configs/{id}` | yes | owner only |

Errors: HTTP 4xx/5xx with `{"error": "message shown to the user"}`.
Suggested limits: body <= 512 KB, name <= 32 chars, description <= 80, rate limit per account.
The uploaded `data` never contains API keys or the cloud URL (the client strips them).
