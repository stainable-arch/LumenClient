# Lumen Client — PvP client mod for Minecraft Forge 1.8.9 (OptiFine compatible)

A client-side Forge mod. It only uses Forge events: no coremod, no mixins, no reflection, no
packets. That is what keeps it compatible with OptiFine (OptiFine patches the renderer; this mod
never touches the same code).

## Get the jar without a PC (GitHub builds it for you, free)

1. Make a free account at github.com (in your tablet browser; "Desktop site" mode makes it easier).
2. Create a **new public repository** (any name).
3. In the repo: **Add file > Upload files**, pick `LumenClient-source.zip` (do NOT unzip it), then **Commit changes**.
4. **Add file > Create new file**. In the name box type `.github/workflows/build.yml`
   (typing the slashes makes the folders) and paste the contents of `build.yml` from the chat /
   from this zip (`.github/workflows/build.yml`). Commit.
5. Open the **Actions** tab. A run called "Build jar" starts by itself (first run takes ~5-10 min).
6. When it has a green check, open the run, scroll to **Artifacts**, tap **LumenClient-jar**.
   You get a zip; unzip it and the `.jar` inside is the mod. If the run is red, open it, copy the
   last ~30 lines of the log and send them to Claude.

## Build it yourself (PC)

JDK 17 + Gradle 7.6.x: run `gradle build` in this folder. The jar is `build/libs/LumenClient-1.0.0.jar`
(ignore any `-dev` jar).

## Install (Zalith Launcher 2)

1. Install **Forge 1.8.9 (11.15.1.2318)** as a game version in the launcher.
2. Put `LumenClient-1.0.0.jar` (and OptiFine 1.8.9 HD U M5, optional) in that version's `mods` folder.
3. Launch the Forge version.

## Main menu

The title screen is replaced by Lumen's own: theme-coloured background with drifting wave ribbons and
outlined stars, your skin on the right, text-only entries (Singleplayer, Multiplayer, Minecraft Settings,
Client = opens the ClickGUI, Quit Game).

## Controls

- **Right Shift** opens / closes the ClickGUI (rebindable: Options > Controls > "Open ClickGUI").
  On a touch device: map an on-screen control button to Right Shift in the launcher's control
  editor, **or just type `/lumen` (alias `/lc`) in chat.**
- **Left-click** a module = on/off. **Tap its arrow (right end of the row) or right-click** = expand its
  settings (Boolean = click, Mode = click to cycle, Number = drag, Bind = click then press a key).
- Drag a panel by its header. Right-click a header to collapse the panel.
- HUD elements can only be moved in the HUD editor (see the pencil button below), not from the normal ClickGUI.
- **Pencil button** (bottom-left corner of the ClickGUI) opens the HUD editor: the menu hides and you can drag every enabled HUD element around. Click the pencil again or press Esc to go back.
- Theme bar at the bottom: 7 themes, Aurora background on/off, UI sounds on/off.
- Settings are saved to `config/lumenclient.json` in the game folder (API keys also in `config/lumenclient-keys.json`).

## Modules

HUD: CPS Display, FPS Display, Keystrokes, Armor Status, Potion Status
Combat: Hit Visuals, Combo Counter, Reach Display, Toggle Sprint
Visuals: Bed Visuals, Block Outlines, Level Head, 1.7 Animations

- **Level Head** — shows each player's Hypixel network level above their name. Needs a free API key from
  developer.hypixel.net: type `/lumen apikey <key>` in chat (`/lumen apikey clear` removes it). The key is saved in
  `config/lumenclient.json`. Settings: Show On Self, Decimals, Background, Hypixel Only, Scale.
- **1.7 Animations** — old first-person hand animations, each with its own switch: Block Hit (arm swings while blocking),
  Eat/Drink Swing (arm swings while eating/drinking) and Bow (the 1.7 bow draw). Off switches fall back to vanilla 1.8.
- **Block Outlines** — replaces the vanilla block outline. Thickness 1-10 (10 = thickest), colour via Custom (Red/Green/Blue sliders), Theme or Rainbow, plus opacity.
- **Bed Visuals** — when a bed breaks, custom pastel hearts/stars/sparkles/bubbles spread out.
  The particles are drawn by the mod's own particle engine from sprites generated at runtime
  (no image files). Trigger "Mine" = beds you break; "Nearby" = any bed vanishing within ~12 blocks.
- **Hit Visuals** — particle burst on confirmed hits (Sparks / Stars / Hearts / Crit / Blood).
- **Combo Counter / Reach Display** — computed on the client from your clicks and the target's hurt animation.
- **Toggle Sprint** — holds the sprint key for you.

## Source layout

    com.lumen.client            LumenClient (mod entry), ClientEvents, ClientSettings
    com.lumen.client.core       Module, HudModule, settings, ModuleManager, ConfigManager
    com.lumen.client.gui        ClickGui, Theme, Aurora, Sounds
    com.lumen.client.fx         ParticleSystem, SpriteSheet
    com.lumen.client.util       RenderUtil, Colors, CombatTracker, ClickCounter, Events
    com.lumen.client.modules    one class per module

To add a module: extend `Module` (or `HudModule`), add settings with `add(new BooleanSetting(...))`,
put `@SubscribeEvent` methods on it (they only run while it's enabled), and list it in `ModuleManager.init()`.

## Heads-up

This source was compile-checked against hand-written API stubs, not against the real 1.8.9 jars,
so the first cloud build / first launch is the real test. Check your server's rules before using
Toggle Sprint, Reach Display and the other utility modules on competitive servers.

## ClickGUI font

The ClickGUI uses the **Winkle** font; Winkle is by createshaa (personal use only; see
`src/main/resources/assets/lumen/fonts/Winkle-LICENSE.txt`). It is baked into a bitmap atlas
(`winkle.png` + `winkle.txt`) with `tools/gen_font_atlas.py`, so no java.awt font support is needed.
The menu is drawn up to 1.5x larger than before (`UI_MAX` in `ClickGui.java`).
