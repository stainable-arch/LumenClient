plugins {
    java
    id("gg.essential.loom") version "0.10.0.+"
    id("dev.architectury.architectury-pack200") version "0.1.3"
}

group = "com.lumen.client"
version = "1.0.0"

base {
    archivesName.set("LumenClient")
}

java {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
}

loom {
    runConfigs {
        // load the coremod (menu FPS unlock) in the dev client too
        "client" {
            property("fml.coreMods.load", "com.lumen.client.asm.LumenCorePlugin")
        }
    }
    forge {
        pack200Provider.set(dev.architectury.pack200.java.Pack200Adapter())
    }
}

tasks.jar {
    manifest.attributes(
        "FMLCorePlugin" to "com.lumen.client.asm.LumenCorePlugin",
        "FMLCorePluginContainsFMLMod" to "true"
    )
}

repositories {
    mavenCentral()
    maven("https://maven.minecraftforge.net")
}

dependencies {
    minecraft("com.mojang:minecraft:1.8.9")
    mappings("de.oceanlabs.mcp:mcp_stable:22-1.8.9")
    // Loom creates the "forge" configuration lazily, so there is no typed forge(...) accessor in the Kotlin DSL
    "forge"("net.minecraftforge:forge:1.8.9-11.15.1.2318-1.8.9")
}
