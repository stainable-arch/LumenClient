#!/usr/bin/env python3
"""Bakes the 64x64 texture of the Tung Tung Sahur pet (src/main/resources/assets/lumen/textures/sahur.png).
Layout matches SahurModel: body box at (0,0), arm at (32,0), leg at (44,0), bat at (0,24).
Needs: pip install pillow.  Usage: python3 tools/gen_sahur.py   (from the project root)
"""
from PIL import Image

OUT = "src/main/resources/assets/lumen/textures/sahur.png"
img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
px = img.load()

BASE, DARK, LIGHT = (176, 120, 62), (132, 88, 44), (206, 152, 88)
BLACK, WHITE, MOUTH = (22, 14, 10), (250, 246, 238), (60, 24, 18)


def grain(x, y):
    n = (x * 7 + (y // 3) * 3 + (x * y) % 4) % 6
    return DARK if n == 0 else (LIGHT if n == 3 else BASE)


def fill(x0, y0, w, h, fn):
    for yy in range(h):
        for xx in range(w):
            px[x0 + xx, y0 + yy] = fn(xx, yy) + (255,)


def rings(w, h):
    def f(x, y):
        d = max(abs(x - (w - 1) / 2.0), abs(y - (h - 1) / 2.0))
        return DARK if int(d) % 2 == 1 else LIGHT
    return f


def box(u, v, w, h, d, face=grain, cap=None):
    cap = cap or rings
    fill(u + d, v, w, d, cap(w, d))               # top
    fill(u + d + w, v, w, d, cap(w, d))           # bottom
    fill(u, v + d, d, h, face)                    # right
    fill(u + d, v + d, w, h, face)                # front
    fill(u + d + w, v + d, d, h, face)            # left
    fill(u + 2 * d + w, v + d, w, h, face)        # back


# body: 8 x 16 x 6 log at (0,0); front face is at (6,6)
box(0, 0, 8, 16, 6)
FX, FY = 6, 6
eyes = [(1, 3), (2, 3), (1, 4), (2, 4), (5, 3), (6, 3), (5, 4), (6, 4)]
for (x, y) in eyes:
    px[FX + x, FY + y] = WHITE + (255,)
for (x, y) in [(2, 4), (5, 4)]:                  # pupils
    px[FX + x, FY + y] = BLACK + (255,)
for x in range(1, 7):                            # brows
    if x in (1, 2, 5, 6):
        px[FX + x, FY + 2] = BLACK + (255,)
for x in range(2, 6):                            # mouth with teeth
    px[FX + x, FY + 8] = MOUTH + (255,)
    px[FX + x, FY + 9] = MOUTH + (255,)
for x in (2, 4):
    px[FX + x, FY + 8] = WHITE + (255,)
px[FX + 3, FY + 6] = DARK + (255,)               # nose
px[FX + 4, FY + 6] = DARK + (255,)

# arm 2x10x2 at (32,0), leg 2x8x2 at (44,0)
box(32, 0, 2, 10, 2)
box(44, 0, 2, 8, 2)


# bat 3x16x3 at (0,24): light wood, dark grip tape on the handle end
def bat_face(x, y):
    return (60, 40, 28) if y < 6 else (222, 176, 112) if (x + y) % 5 else (196, 150, 90)


box(0, 24, 3, 16, 3, face=bat_face, cap=lambda w, h: (lambda x, y: (222, 176, 112)))

img.save(OUT)
print("saved", OUT)
