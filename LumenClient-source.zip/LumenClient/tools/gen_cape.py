#!/usr/bin/env python3
"""Bakes the Lumen cape: fully black, with white "claude" in the Winkle font on the outer face.
Reads the Winkle atlas (winkle.png / winkle.txt) so no TTF is needed. Needs: pip install pillow
Usage: python3 tools/gen_cape.py     (from the project root)
"""
from PIL import Image

FONTS = "src/main/resources/assets/lumen/fonts/"
OUT = "src/main/resources/assets/lumen/textures/cape.png"
TEXT = "claude"
S = 16                     # the cape is 64x32 in vanilla; this is 16x that (1024x512), sharper
W, H = 64 * S, 32 * S

atlas = Image.open(FONTS + "winkle.png").convert("RGBA")
alpha = atlas.split()[3]
lines = open(FONTS + "winkle.txt").read().split("\n")
raster, space = float(lines[0].split()[0]), float(lines[0].split()[1])
glyphs = {}
for ln in lines[1:]:
    p = ln.split()
    if len(p) == 8:
        glyphs[int(p[0])] = [float(v) for v in p[1:]]

# lay the text out on a big mask at raster size
mask = Image.new("L", (int(raster * 20), int(raster * 3)), 0)
pen, base = 20.0, raster * 1.6
for ch in TEXT:
    if ch == " ":
        pen += space
        continue
    adv, u, v, w, h, xo, yo = glyphs[ord(ch)]
    g = alpha.crop((int(u), int(v), int(u + w), int(v + h)))
    mask.paste(g, (int(round(pen + xo)), int(round(base + yo))), g)
    pen += adv
bbox = mask.getbbox()
mask = mask.crop(bbox)

cape = Image.new("RGBA", (W, H), (0, 0, 0, 255))        # everything black, opaque
# outer face of the cape model is the 10x16 box at (1,1)
fx, fy, fw, fh = 1 * S, 1 * S, 10 * S, 16 * S
tw = int(fw * 0.86)
th = max(1, int(mask.height * tw / mask.width))
txt = mask.resize((tw, th), Image.LANCZOS)
white = Image.new("RGBA", txt.size, (255, 255, 255, 255))
white.putalpha(txt)
cape.alpha_composite(white, (fx + (fw - tw) // 2, fy + int(fh * 0.30)))
cape.save(OUT)
print("cape", cape.size, "text", txt.size)
