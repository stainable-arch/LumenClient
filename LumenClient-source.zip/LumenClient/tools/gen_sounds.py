#!/usr/bin/env python3
"""Synthesises the keyboard UI sound packs (OGG Vorbis, mono) + sounds.json used by Sounds.java.

Usage (from the project root):  python3 tools/gen_sounds.py
Needs: numpy, scipy and ffmpeg (with libvorbis) on the PATH.

Each pack gets 4 key variants + 2 space-bar (heavy) variants. sounds.json lists all variants of a
pack under one event ("creamy.key", "creamy.space", ...), so Minecraft picks one at random per play.
The result is deterministic (fixed seed). Tweak PACKS below to design your own pack, then add its name
to Sounds.PACKS in Sounds.java.

How a "thock" is built (modal synthesis):
  * body    - two damped sines (the key/plate resonance) that glide down a little = the round "thock"
  * impact  - a few ms of low-passed noise = the finger hitting the key (softer cutoff = creamier)
  * bottom  - a second, quieter impact a few ms later = the key bottoming out on the plate
  * sparkle - optional high, very short mode = the clacky/plasticky top end (only the Clack pack)
"""
import json
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy import signal

SR = 44100
OUT = "src/main/resources/assets/lumen/"
PEAK = 0.9

PACKS = {
    # name: parameters. f0 = body frequency range (Hz), ratio = 2nd mode / f0, m2 = its level,
    # tau = body decay time constant (ms), glide = downward pitch glide, noise_* = impact transient,
    # bottom_* = bottom-out hit, hf = (freq, tau ms, level) sparkle, post_lp = final low-pass (Hz)
    "creamy": dict(f0=(190, 240), ratio=1.68, m2=0.45, tau=48, glide=0.10, noise_fc=1500,
                   noise_amp=0.30, noise_tau=7, attack_ms=0.7, bottom_delay=(8, 11),
                   bottom_amp=0.38, hf=None, post_lp=5200, length_ms=200),
    "thock": dict(f0=(120, 150), ratio=1.90, m2=0.50, tau=78, glide=0.14, noise_fc=900,
                  noise_amp=0.28, noise_tau=9, attack_ms=0.9, bottom_delay=(10, 13),
                  bottom_amp=0.42, hf=None, post_lp=3800, length_ms=280),
    "clack": dict(f0=(300, 360), ratio=2.40, m2=0.35, tau=26, glide=0.05, noise_fc=6500,
                  noise_amp=0.55, noise_tau=4, attack_ms=0.15, bottom_delay=(6, 8),
                  bottom_amp=0.30, hf=(2900, 9, 0.22), post_lp=12000, length_ms=140),
}
KEY_VARIANTS = 4
SPACE_VARIANTS = 2
SPACE_SCALE = 0.72   # space bar: lower body ...
SPACE_TAU = 1.35     # ... and longer ring


def lowpass(x, fc, order=2):
    b, a = signal.butter(order, min(fc, SR * 0.45) / (SR / 2), "low")
    return signal.lfilter(b, a, x)


def mode(n, f, tau_ms, glide):
    t = np.arange(n) / SR
    freq = f * (1.0 - glide * (1.0 - np.exp(-t / 0.015)))
    phase = 2 * np.pi * np.cumsum(freq) / SR
    return np.sin(phase) * np.exp(-t / (tau_ms / 1000.0))


def impact(n, rng, fc, tau_ms, offset=0):
    """A short low-passed noise burst starting `offset` samples in."""
    out = np.zeros(n)
    m = n - offset
    if m <= 0:
        return out
    t = np.arange(m) / SR
    burst = lowpass(rng.standard_normal(m), fc) * np.exp(-t / (tau_ms / 1000.0))
    out[offset:] = burst
    return out


def render(p, rng, heavy):
    n = int(SR * p["length_ms"] / 1000.0 * (1.2 if heavy else 1.0))
    f0 = rng.uniform(*p["f0"]) * (SPACE_SCALE if heavy else 1.0)
    tau = p["tau"] * (SPACE_TAU if heavy else 1.0)

    body = mode(n, f0, tau, p["glide"]) + p["m2"] * mode(n, f0 * p["ratio"], tau * 0.55, p["glide"])
    hit = p["noise_amp"] * impact(n, rng, p["noise_fc"], p["noise_tau"])

    delay = int(SR * rng.uniform(*p["bottom_delay"]) / 1000.0 * (1.3 if heavy else 1.0))
    bottom = p["bottom_amp"] * impact(n, rng, p["noise_fc"] * 0.7, p["noise_tau"] * 1.2, delay)
    bottom_body = np.zeros(n)
    bottom_body[delay:] = mode(n - delay, f0 * 0.9, tau * 0.6, p["glide"])
    bottom += p["bottom_amp"] * 0.6 * bottom_body

    x = body + hit + bottom
    if p["hf"]:
        hf_f, hf_tau, hf_amp = p["hf"]
        x += hf_amp * mode(n, hf_f * rng.uniform(0.95, 1.05), hf_tau, 0.0)

    # soft attack so the start is a push, not a tick
    t = np.arange(n) / SR
    x *= 1.0 - np.exp(-t / (p["attack_ms"] / 1000.0))
    x = lowpass(x, p["post_lp"])

    # tail fade (never end on a non-zero sample) and normalise
    fade = int(SR * 0.012)
    x[-fade:] *= np.linspace(1.0, 0.0, fade)
    x = x - np.mean(x)
    return x / np.max(np.abs(x)) * PEAK


def write_ogg(x, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "s.wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes(pcm.tobytes())
        subprocess.check_call(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1",
                               "-c:a", "libvorbis", "-q:a", "5", path])


def main():
    rng = np.random.default_rng(1337)
    events = {}
    for name, p in PACKS.items():
        keys, spaces = [], []
        for i in range(KEY_VARIANTS):
            rel = "%s/key%d" % (name, i + 1)
            write_ogg(render(p, rng, False), OUT + "sounds/" + rel + ".ogg")
            keys.append(rel)
        for i in range(SPACE_VARIANTS):
            rel = "%s/space%d" % (name, i + 1)
            write_ogg(render(p, rng, True), OUT + "sounds/" + rel + ".ogg")
            spaces.append(rel)
        events[name + ".key"] = {"category": "master", "sounds": keys}
        events[name + ".space"] = {"category": "master", "sounds": spaces}
    with open(OUT + "sounds.json", "w") as f:
        json.dump(events, f, indent=2)
        f.write("\n")
    print("wrote %d events" % len(events))


if __name__ == "__main__":
    main()
