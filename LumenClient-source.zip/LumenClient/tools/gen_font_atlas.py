#!/usr/bin/env python3
"""Bakes a TTF into the bitmap atlas (winkle.png) + metrics (winkle.txt) used by LumenFont.

Usage: python3 tools/gen_font_atlas.py Font.ttf|otf [fallback.ttf] [name]   (name defaults to "winkle")
Glyphs the main font lacks (e.g. | _ % ( ) /) are taken from the fallback font, if given.
Needs: pip install pillow
"""
import sys
from PIL import Image, ImageDraw, ImageFont

SIZE = 56   # raster size in px; LumenFont scales it down
PAD = 4
ATLAS_W = 1024
OUT = "src/main/resources/assets/lumen/fonts/"
NAME = sys.argv[3] if len(sys.argv) > 3 else "winkle"

main = ImageFont.truetype(sys.argv[1], SIZE)
fb = ImageFont.truetype(sys.argv[2], int(SIZE * 0.92)) if len(sys.argv) > 2 else None

from fontTools.ttLib import TTFont
cmap = TTFont(sys.argv[1]).getBestCmap()

glyphs = []
for code in range(33, 127):
    ch = chr(code)
    font = main if code in cmap else fb
    if font is None:
        continue
    l, t, r, b = font.getbbox(ch, anchor="ls")
    glyphs.append((code, ch, font, l, t, r, b, font.getlength(ch)))
space_adv = main.getlength(" ") if 32 in cmap else SIZE * 0.3

# shelf packing
x = y = row_h = 0
placed = []
for g in glyphs:
    code, ch, font, l, t, r, b, adv = g
    w, h = (r - l) + 2 * PAD, (b - t) + 2 * PAD
    if x + w > ATLAS_W:
        x, y, row_h = 0, y + row_h, 0
    placed.append((g, x, y, w, h))
    x += w
    row_h = max(row_h, h)
atlas_h = 1
while atlas_h < y + row_h:
    atlas_h *= 2

img = Image.new("RGBA", (ATLAS_W, atlas_h), (255, 255, 255, 0))
mask = Image.new("L", (ATLAS_W, atlas_h), 0)
d = ImageDraw.Draw(mask)
lines = []
for (code, ch, font, l, t, r, b, adv), gx, gy, w, h in placed:
    d.text((gx + PAD - l, gy + PAD - t), ch, font=font, fill=255, anchor="ls")
    lines.append("%d %.3f %d %d %d %d %.3f %.3f" % (code, adv, gx, gy, w, h, l - PAD, t - PAD))
img.putalpha(mask)
img.save(OUT + NAME + ".png")
with open(OUT + NAME + ".txt", "w") as f:
    f.write("%d %.3f %d %d\n" % (SIZE, space_adv, ATLAS_W, atlas_h))
    f.write("\n".join(lines) + "\n")
print("atlas", ATLAS_W, atlas_h, len(lines), "glyphs")
