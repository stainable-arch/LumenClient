package com.lumen.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

import java.util.Locale;

public final class ServerUtil {
    private ServerUtil() {}

    /** True while connected to a Hypixel server (by address). */
    public static boolean onHypixel() {
        ServerData sd = Minecraft.getMinecraft().getCurrentServerData();
        return sd != null && sd.serverIP != null && sd.serverIP.toLowerCase(Locale.ROOT).contains("hypixel");
    }
}
