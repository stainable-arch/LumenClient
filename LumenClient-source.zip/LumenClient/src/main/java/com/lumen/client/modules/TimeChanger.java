package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Forces a client-side time value; a server may periodically override it. */
public class TimeChanger extends Module {
    private final NumberSetting time = add(new NumberSetting("Time", 6000, 0, 24000, 100));

    public TimeChanger() {
        super("Time Changer", "Sets the visible client world time (servers may override it).", Category.VISUALS);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && mc.theWorld != null) {
            mc.theWorld.setWorldTime((long) time.getInt());
        }
    }
}
