package com.lumen.client;

import com.lumen.client.core.HudModule;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.gui.ClickGui;
import com.lumen.client.gui.LumenMainMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreenResourcePacks;
import com.lumen.client.gui.LumenOptions;
import com.lumen.client.gui.LumenPackSelect;
import com.lumen.client.gui.LumenServerSelect;
import com.lumen.client.gui.LumenWorldSelect;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/** Always-on event handlers: opening the GUI, module keybinds and drawing the HUD. */
public class ClientEvents {
    /** Set by the /lumen command; the GUI opens on the next client tick. */
    public static boolean openGuiRequested;

    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        boolean keyPressed = LumenClient.openGuiKey.isPressed();
        if ((keyPressed || openGuiRequested) && mc.theWorld != null && (mc.currentScreen == null || openGuiRequested)) {
            if (!(mc.currentScreen instanceof ClickGui) && !(mc.currentScreen instanceof com.lumen.client.gui.ColumnGui)) {
                mc.displayGuiScreen(com.lumen.client.gui.ColumnGui.create());
            }
        }
        openGuiRequested = false;
    }

    /** Swaps the vanilla title screen for Lumen's own. */
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent e) {
        if (e.gui != null && e.gui.getClass() == GuiMainMenu.class) {
            e.gui = new LumenMainMenu();
        } else if (e.gui != null && e.gui.getClass() == GuiMultiplayer.class) {
            // e.g. "Disconnect" from a server: vanilla opens its server list over the title screen
            e.gui = new LumenServerSelect(new LumenMainMenu());
        } else if (e.gui != null && e.gui.getClass() == GuiSelectWorld.class) {
            e.gui = new LumenWorldSelect(new LumenMainMenu());
        } else if (e.gui != null && e.gui.getClass() == GuiOptions.class) {
            // e.g. from the pause menu: the screen that opens it is still current and is where Done returns to
            e.gui = new LumenOptions(mc.currentScreen, mc.gameSettings);
        } else if (e.gui != null && e.gui.getClass() == GuiScreenResourcePacks.class) {
            // the screen that opens it (Options) is still current: that is where Done / Cancel return to
            e.gui = new LumenPackSelect(mc.currentScreen);
        }
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (!Keyboard.getEventKeyState() || mc.currentScreen != null) return;
        int key = Keyboard.getEventKey();
        if (key == Keyboard.KEY_NONE) return;
        for (Module m : ModuleManager.modules) {
            if (m.key == key) m.toggle();
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL) return;
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled() && m instanceof HudModule) {
                ((HudModule) m).renderHud(e.resolution);
            }
        }
        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
