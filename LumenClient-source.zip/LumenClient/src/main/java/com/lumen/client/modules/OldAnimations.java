package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import net.minecraft.block.material.Material;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.util.glu.Project;

/**
 * Brings back the 1.7 first-person animations. Every animation has its own switch.
 *
 * Vanilla 1.8 ignores the arm swing while you use an item and simplified the bow. To change that
 * without touching vanilla code, this module cancels the first-person hand render only on frames
 * where one of its enabled animations applies (blocking, eating/drinking, drawing a bow) and draws
 * the hand itself with the 1.7 transforms. In every other situation vanilla renders as normal.
 */
public class OldAnimations extends Module {
    private final BooleanSetting blockHit = add(new BooleanSetting("Block Hit", true));
    private final BooleanSetting useSwing = add(new BooleanSetting("Eat/Drink Swing", true));
    private final BooleanSetting bow = add(new BooleanSetting("Bow", true));

    // our own copy of vanilla's "equipped item" tracking (the real one is private)
    private ItemStack itemToRender;
    private int equippedSlot = -1;
    private float equip, prevEquip;

    public OldAnimations() {
        super("1.7 Animations", "Old 1.7 hand animations: block hit, eat/drink swing and the 1.7 bow. Each can be turned off.", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        EntityPlayerSP p = mc.thePlayer;
        if (p != null) {
            itemToRender = p.inventory.getCurrentItem();
            equippedSlot = p.inventory.currentItem;
            equip = prevEquip = 1f;
        } else {
            itemToRender = null;
            equip = prevEquip = 0f;
        }
    }

    // ------------------------------------------------------------------------------------------
    // equip tracking (same logic as vanilla's ItemRenderer.updateEquippedItem)
    // ------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        EntityPlayerSP p = mc.thePlayer;
        if (p == null) {
            itemToRender = null;
            return;
        }
        prevEquip = equip;
        ItemStack cur = p.inventory.getCurrentItem();
        boolean same = equippedSlot == p.inventory.currentItem && cur == itemToRender;
        if (itemToRender == null && cur == null) same = true;
        if (cur != null && itemToRender != null && cur != itemToRender
                && cur.getItem() == itemToRender.getItem() && cur.getMetadata() == itemToRender.getMetadata()) {
            itemToRender = cur;
            same = true;
        }
        float d = MathHelper.clamp_float((same ? 1f : 0f) - equip, -0.4f, 0.4f);
        equip += d;
        if (equip < 0.1f) {
            itemToRender = cur;
            equippedSlot = p.inventory.currentItem;
        }
    }

    // ------------------------------------------------------------------------------------------
    // first-person hand
    // ------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onRenderHand(RenderHandEvent e) {
        EntityPlayerSP p = mc.thePlayer;
        if (p == null || mc.theWorld == null || mc.getRenderViewEntity() != p) return;
        if (mc.gameSettings.thirdPersonView != 0 || mc.gameSettings.hideGUI || p.isPlayerSleeping()
                || mc.playerController.isSpectator() || mc.gameSettings.anaglyph) return;
        ItemStack stack = itemToRender;
        if (stack == null || p.getItemInUseCount() <= 0 || stack.getItem() instanceof ItemMap) return;

        EnumAction action = stack.getItemUseAction();
        boolean take = (action == EnumAction.BLOCK && blockHit.value)
                || ((action == EnumAction.EAT || action == EnumAction.DRINK) && useSwing.value)
                || (action == EnumAction.BOW && bow.value);
        if (!take) return; // vanilla draws it

        e.setCanceled(true);
        drawHand(e.partialTicks, p, stack, action);
    }

    private void drawHand(float pt, EntityPlayerSP p, ItemStack stack, EnumAction action) {
        // the same projection / camera effects vanilla sets up for the hand
        GlStateManager.clear(256);
        GlStateManager.matrixMode(5889);
        GlStateManager.loadIdentity();
        Project.gluPerspective(handFov(pt, p), (float) mc.displayWidth / (float) mc.displayHeight,
                0.05f, mc.gameSettings.renderDistanceChunks * 16f * 2f);
        GlStateManager.matrixMode(5888);
        GlStateManager.loadIdentity();
        GlStateManager.pushMatrix();
        hurtCamera(pt);
        if (mc.gameSettings.viewBobbing) viewBobbing(pt);

        mc.entityRenderer.enableLightmap();
        renderItem(pt, p, stack, action);
        mc.entityRenderer.disableLightmap();

        GlStateManager.popMatrix();
    }

    private float handFov(float pt, EntityPlayerSP p) {
        float f = 70f;
        if (p.getHealth() <= 0f) {
            float t = p.deathTime + pt;
            f /= (1f - 500f / (t + 500f)) * 2f + 1f;
        }
        if (ActiveRenderInfo.getBlockAtEntityViewpoint(mc.theWorld, p, pt).getMaterial() == Material.water) {
            f = f * 60f / 70f;
        }
        return f;
    }

    private void hurtCamera(float pt) {
        Entity re = mc.getRenderViewEntity();
        if (!(re instanceof EntityLivingBase)) return;
        EntityLivingBase le = (EntityLivingBase) re;
        float f = le.hurtTime - pt;
        if (le.getHealth() <= 0f) {
            float t = le.deathTime + pt;
            GlStateManager.rotate(40f - 8000f / (t + 200f), 0f, 0f, 1f);
        }
        if (f < 0f) return;
        f = f / le.maxHurtTime;
        f = MathHelper.sin(f * f * f * f * (float) Math.PI);
        float yaw = le.attackedAtYaw;
        GlStateManager.rotate(-yaw, 0f, 1f, 0f);
        GlStateManager.rotate(-f * 14f, 0f, 0f, 1f);
        GlStateManager.rotate(yaw, 0f, 1f, 0f);
    }

    private void viewBobbing(float pt) {
        Entity re = mc.getRenderViewEntity();
        if (!(re instanceof EntityPlayer)) return;
        EntityPlayer pl = (EntityPlayer) re;
        float f = pl.distanceWalkedModified - pl.prevDistanceWalkedModified;
        float f1 = -(pl.distanceWalkedModified + f * pt);
        float f2 = pl.prevCameraYaw + (pl.cameraYaw - pl.prevCameraYaw) * pt;
        float f3 = pl.prevCameraPitch + (pl.cameraPitch - pl.prevCameraPitch) * pt;
        GlStateManager.translate(MathHelper.sin(f1 * (float) Math.PI) * f2 * 0.5f, -Math.abs(MathHelper.cos(f1 * (float) Math.PI) * f2), 0f);
        GlStateManager.rotate(MathHelper.sin(f1 * (float) Math.PI) * f2 * 3f, 0f, 0f, 1f);
        GlStateManager.rotate(Math.abs(MathHelper.cos(f1 * (float) Math.PI - 0.2f) * f2) * 5f, 1f, 0f, 0f);
        GlStateManager.rotate(f3, 1f, 0f, 0f);
    }

    private void renderItem(float pt, EntityPlayerSP p, ItemStack stack, EnumAction action) {
        float equipAmt = 1f - (prevEquip + (equip - prevEquip) * pt);
        float swing = p.getSwingProgress(pt);
        float pitch = p.prevRotationPitch + (p.rotationPitch - p.prevRotationPitch) * pt;
        float yaw = p.prevRotationYaw + (p.rotationYaw - p.prevRotationYaw) * pt;

        // lighting direction follows the camera
        GlStateManager.pushMatrix();
        GlStateManager.rotate(pitch, 1f, 0f, 0f);
        GlStateManager.rotate(yaw, 0f, 1f, 0f);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.popMatrix();

        // light level at the player's eyes
        int light = mc.theWorld.getCombinedLight(new BlockPos(p.posX, p.posY + p.getEyeHeight(), p.posZ), 0);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (light & 65535), (float) (light >> 16));

        // the hand lags slightly behind when you turn
        float armPitch = p.prevRenderArmPitch + (p.renderArmPitch - p.prevRenderArmPitch) * pt;
        float armYaw = p.prevRenderArmYaw + (p.renderArmYaw - p.prevRenderArmYaw) * pt;
        GlStateManager.rotate((p.rotationPitch - armPitch) * 0.1f, 1f, 0f, 0f);
        GlStateManager.rotate((p.rotationYaw - armYaw) * 0.1f, 0f, 1f, 0f);

        GlStateManager.enableRescaleNormal();
        GlStateManager.pushMatrix();

        // 1.7: the swing is always applied, even while an item is in use
        float s = MathHelper.sqrt_float(swing);
        GlStateManager.translate(-0.4f * MathHelper.sin(s * (float) Math.PI),
                0.2f * MathHelper.sin(s * (float) Math.PI * 2f),
                -0.2f * MathHelper.sin(swing * (float) Math.PI));
        GlStateManager.translate(0.56f, -0.52f, -0.72f);
        GlStateManager.translate(0f, equipAmt * -0.6f, 0f);
        GlStateManager.rotate(45f, 0f, 1f, 0f);
        float a = MathHelper.sin(swing * swing * (float) Math.PI);
        float b = MathHelper.sin(s * (float) Math.PI);
        GlStateManager.rotate(a * -20f, 0f, 1f, 0f);
        GlStateManager.rotate(b * -20f, 0f, 0f, 1f);
        GlStateManager.rotate(b * -80f, 1f, 0f, 0f);
        GlStateManager.scale(0.4f, 0.4f, 0.4f);

        if (action == EnumAction.EAT || action == EnumAction.DRINK) {
            float left = p.getItemInUseCount() - pt + 1f;
            float frac = left / stack.getMaxItemUseDuration();
            float bob = MathHelper.abs(MathHelper.cos(left / 4f * (float) Math.PI) * 0.1f);
            if (frac >= 0.8f) bob = 0f;
            GlStateManager.translate(0f, bob, 0f);
            float k = 1f - (float) Math.pow(frac, 27.0);
            GlStateManager.translate(k * 0.6f, k * -0.5f, 0f);
            GlStateManager.rotate(k * 90f, 0f, 1f, 0f);
            GlStateManager.rotate(k * 10f, 1f, 0f, 0f);
            GlStateManager.rotate(k * 30f, 0f, 0f, 1f);
        } else if (action == EnumAction.BLOCK) {
            GlStateManager.translate(-0.5f, 0.2f, 0f);
            GlStateManager.rotate(30f, 0f, 1f, 0f);
            GlStateManager.rotate(-80f, 1f, 0f, 0f);
            GlStateManager.rotate(60f, 0f, 1f, 0f);
        } else if (action == EnumAction.BOW) {
            GlStateManager.rotate(-18f, 0f, 0f, 1f);
            GlStateManager.rotate(-12f, 0f, 1f, 0f);
            GlStateManager.rotate(-8f, 1f, 0f, 0f);
            GlStateManager.translate(-0.9f, 0.2f, 0f);
            float used = stack.getMaxItemUseDuration() - (p.getItemInUseCount() - pt + 1f);
            float draw = used / 20f;
            draw = (draw * draw + draw * 2f) / 3f;
            if (draw > 1f) draw = 1f;
            if (draw > 0.1f) {
                GlStateManager.translate(0f, MathHelper.sin((used - 0.1f) * 1.3f) * 0.01f * (draw - 0.1f), 0f);
            }
            GlStateManager.translate(0f, 0f, draw * 0.1f);
            // 1.7 stretches the bow along a tilted axis instead of straight forward
            GlStateManager.rotate(-335f, 0f, 0f, 1f);
            GlStateManager.rotate(-50f, 0f, 1f, 0f);
            GlStateManager.translate(0f, 0.5f, 0f);
            GlStateManager.scale(1f, 1f, 1f + draw * 0.2f);
            GlStateManager.translate(0f, -0.5f, 0f);
            GlStateManager.rotate(50f, 0f, 1f, 0f);
            GlStateManager.rotate(335f, 0f, 0f, 1f);
        }

        mc.getItemRenderer().renderItem(p, stack, ItemCameraTransforms.TransformType.FIRST_PERSON);

        GlStateManager.popMatrix();
        GlStateManager.disableRescaleNormal();
        RenderHelper.disableStandardItemLighting();
    }
}
