package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.util.CombatTracker;

import java.util.Locale;

public class ReachDisplay extends HudModule {
    public ReachDisplay() {
        super("Reach Display", "Shows the distance of your last hit.", Category.COMBAT, 4, 76);
    }

    @Override
    protected void draw() {
        String value = CombatTracker.lastReach > 0
                ? String.format(Locale.ROOT, "%.2f blocks", CombatTracker.lastReach)
                : "-";
        labelValue("Reach", value);
    }
}
