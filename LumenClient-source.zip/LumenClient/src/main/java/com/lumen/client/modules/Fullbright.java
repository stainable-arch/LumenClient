package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Client-side gamma boost with a user-adjustable brightness level. */
public class Fullbright extends Module {
    private final NumberSetting brightness = add(new NumberSetting("Brightness", 16, 1, 100, 1));
    private float oldGamma;

    public Fullbright() {
        super("Fullbright", "Raises client gamma while enabled.", Category.VISUALS);
    }

    @Override protected void onEnable() {
        if (mc.gameSettings != null) oldGamma = mc.gameSettings.gammaSetting;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && mc.gameSettings != null) {
            mc.gameSettings.gammaSetting = brightness.getFloat();
        }
    }

    @Override protected void onDisable() {
        if (mc.gameSettings != null) mc.gameSettings.gammaSetting = oldGamma;
    }
}
