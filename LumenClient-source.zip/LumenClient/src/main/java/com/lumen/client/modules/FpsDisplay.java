package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import net.minecraft.client.Minecraft;

public class FpsDisplay extends HudModule {
    private final BooleanSetting colored = add(new BooleanSetting("Colored", true));

    public FpsDisplay() {
        super("FPS Display", "Shows your current frames per second.", Category.HUD, 4, 22);
    }

    @Override
    protected void draw() {
        int fps = Minecraft.getDebugFPS();
        int color = 0xFFFFFFFF;
        if (colored.value) {
            color = fps >= 100 ? 0xFF6BFF8A : (fps >= 45 ? 0xFFFFE066 : 0xFFFF6B6B);
        }
        labelValue("FPS", String.valueOf(fps), color);
    }
}
