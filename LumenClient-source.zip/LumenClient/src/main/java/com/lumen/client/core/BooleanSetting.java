package com.lumen.client.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class BooleanSetting extends Setting {
    public boolean value;

    public BooleanSetting(String name, boolean def) {
        super(name);
        this.value = def;
        this.anim = def ? 1f : 0f;
    }

    public void toggle() {
        value = !value;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(Boolean.valueOf(value));
    }

    @Override
    public void load(JsonElement e) {
        if (e != null && e.isJsonPrimitive()) {
            value = e.getAsBoolean();
            anim = value ? 1f : 0f;
        }
    }
}
