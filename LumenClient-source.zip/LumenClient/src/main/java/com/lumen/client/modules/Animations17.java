package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModeSetting;

/**
 * Configuration surface for classic 1.7-style animation preferences.
 * Full animation replacement requires a renderer/coremod hook; this Forge-only
 * version exposes the requested controls without claiming unsupported render hooks.
 */
public class Animations17 extends Module {
    public final ModeSetting blockHit = add(new ModeSetting("Block Hitting", "1.7", "1.7", "1.8"));
    public final ModeSetting eating = add(new ModeSetting("Eating", "1.7", "1.7", "1.8"));
    public final ModeSetting sword = add(new ModeSetting("Sword", "1.7", "1.7", "1.8"));
    public final ModeSetting bow = add(new ModeSetting("Bow", "1.7", "1.7", "1.8"));
    public final ModeSetting rod = add(new ModeSetting("Rod", "1.7", "1.7", "1.8"));
    public final BooleanSetting swing = add(new BooleanSetting("Classic Swing", true));

    public Animations17() {
        super("1.7 Animations", "Animation preference controls; full replacement needs a renderer hook.", Category.VISUALS);
    }
}
