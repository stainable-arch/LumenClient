package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.ClickCounter;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.input.Mouse;

public class Keystrokes extends HudModule {
    private final BooleanSetting mouseButtons = add(new BooleanSetting("Mouse Buttons", true));
    private final BooleanSetting spacebar = add(new BooleanSetting("Spacebar", true));
    private final BooleanSetting showCps = add(new BooleanSetting("Show CPS", true));

    /** Press animation per key: W A S D LMB RMB SPACE. */
    private final float[] fade = new float[7];
    private long lastNanos = System.nanoTime();

    public Keystrokes() {
        super("Keystrokes", "Shows WASD, mouse buttons and space, lighting up as you press them.", Category.HUD, 4, 78);
    }

    @Override
    protected void draw() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1.0e9f);
        lastNanos = now;

        GameSettings gs = mc.gameSettings;
        boolean[] down = {
                gs.keyBindForward.isKeyDown(), gs.keyBindLeft.isKeyDown(), gs.keyBindBack.isKeyDown(), gs.keyBindRight.isKeyDown(),
                Mouse.isButtonDown(0), Mouse.isButtonDown(1), gs.keyBindJump.isKeyDown()
        };
        for (int i = 0; i < fade.length; i++) {
            fade[i] += ((down[i] ? 1f : 0f) - fade[i]) * Math.min(1f, dt * 16f);
        }

        float k = 22f, gap = 2f;
        float full = 3 * k + 2 * gap;
        key(0, k + gap, 0, k, k, "W", null);
        key(1, 0, k + gap, k, k, "A", null);
        key(2, k + gap, k + gap, k, k, "S", null);
        key(3, 2 * (k + gap), k + gap, k, k, "D", null);

        float y = 2 * (k + gap);
        if (mouseButtons.value) {
            float bw = (full - gap) / 2f;
            key(4, 0, y, bw, k, "LMB", showCps.value ? String.valueOf(ClickCounter.cps(true)) : null);
            key(5, bw + gap, y, bw, k, "RMB", showCps.value ? String.valueOf(ClickCounter.cps(false)) : null);
            y += k + gap;
        }
        if (spacebar.value) {
            key(6, 0, y, full, 16, "", null);
            y += 16 + gap;
        }
        this.width = full;
        this.height = y - gap;
    }

    private void key(int idx, float x, float y, float w, float h, String label, String sub) {
        float f = fade[idx];
        Theme th = Theme.current();
        if (background.value && th.glass) {
            com.lumen.client.gui.GlassFx.pane(x, y, x + w, y + h, 3f, 1f, f);
        } else if (background.value) {
            RenderUtil.roundedRect(x, y, x + w, y + h, 3, Colors.lerp(0x8C000000, Colors.withAlpha(th.c1, 225), f));
        }
        int text = th.glass ? 0xFFFFFFFF : Colors.lerp(0xFFFFFFFF, 0xFF0B1020, f);
        if (label.isEmpty()) {
            // space bar: draw a small bar instead of text
            RenderUtil.rect(x + w / 2f - 9, y + h / 2f - 0.5f, x + w / 2f + 9, y + h / 2f + 0.5f, text);
        } else if (sub == null) {
            RenderUtil.stringFlat(label, x + (w - RenderUtil.width(label)) / 2f, y + (h - 8f) / 2f, text);
        } else {
            RenderUtil.stringFlat(label, x + (w - RenderUtil.width(label)) / 2f, y + 3f, text);
            RenderUtil.stringFlat(sub, x + (w - RenderUtil.width(sub)) / 2f, y + 12f, Colors.withAlpha(text, 190));
        }
    }
}
