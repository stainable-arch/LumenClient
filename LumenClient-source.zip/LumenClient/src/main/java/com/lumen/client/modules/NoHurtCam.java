package com.lumen.client.modules;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Backs the "No Hurt Cam" option (Options screen, no configuration): removes the camera shake when you take damage. Vanilla derives the shake from hurtTime, so we
 * set it to 0 for the duration of the frame being rendered and restore it right after. Game
 * logic never sees the change (it only happens between RenderTickEvent START and END).
 */
public class NoHurtCam {
    private final Minecraft mc = Minecraft.getMinecraft();
    private EntityLivingBase target;
    private int savedHurtTime;

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            if (ClientSettings.noHurtCam.value && mc.getRenderViewEntity() instanceof EntityLivingBase) {
                target = (EntityLivingBase) mc.getRenderViewEntity();
                savedHurtTime = target.hurtTime;
                target.hurtTime = 0;
            }
        } else if (target != null) {
            target.hurtTime = savedHurtTime;
            target = null;
        }
    }
}
