package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Removes the camera shake when you take damage. Vanilla derives the shake from hurtTime, so we
 * set it to 0 for the duration of the frame being rendered and restore it right after. Game
 * logic never sees the change (it only happens between RenderTickEvent START and END).
 */
public class NoHurtCam extends Module {
    private EntityLivingBase target;
    private int savedHurtTime;

    public NoHurtCam() {
        super("No Hurt Cam", "Disables the camera shake when you get hit.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            if (mc.getRenderViewEntity() instanceof EntityLivingBase) {
                target = (EntityLivingBase) mc.getRenderViewEntity();
                savedHurtTime = target.hurtTime;
                target.hurtTime = 0;
            }
        } else if (target != null) {
            target.hurtTime = savedHurtTime;
            target = null;
        }
    }

    @Override
    protected void onDisable() {
        if (target != null) {
            target.hurtTime = savedHurtTime;
            target = null;
        }
    }
}
