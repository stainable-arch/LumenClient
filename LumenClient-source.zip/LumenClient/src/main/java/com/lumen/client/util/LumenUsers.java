package com.lumen.client.util;

import net.minecraft.client.Minecraft;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Knows which players are Lumen users. You are always one. Other players can only be recognised
 * if something tells us about them (a future shared service would call {@link #mark}); the client
 * is fully offline otherwise, so nobody else is detected yet.
 */
public final class LumenUsers {
    private static final Map<UUID, Boolean> KNOWN = new ConcurrentHashMap<UUID, Boolean>();

    private LumenUsers() {}

    public static void mark(UUID id) {
        KNOWN.put(id, Boolean.TRUE);
    }

    public static void unmark(UUID id) {
        KNOWN.remove(id);
    }

    public static boolean isLumenUser(UUID id) {
        if (id == null) return false;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null && id.equals(mc.thePlayer.getUniqueID())) return true;
        return KNOWN.containsKey(id);
    }
}
