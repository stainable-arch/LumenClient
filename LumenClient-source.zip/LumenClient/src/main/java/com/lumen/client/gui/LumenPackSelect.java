package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Resource pack screen in the look of {@link LumenMainMenu}. Two lists (available / selected);
 * a click moves a pack across, small arrows reorder it, and with "Draggable" on, packs can also be
 * dragged between the lists and to any position in the selected list.
 */
public class LumenPackSelect extends GuiScreen {
    private static final String[] ACTIONS = { "Open Pack Folder", "Cancel", "Done" };
    private static final int A_FOLDER = 0, A_CANCEL = 1, A_DONE = 2;

    private final GuiScreen parent;
    private final float[] actionHover = new float[ACTIONS.length];

    private List<ResourcePackRepository.Entry> all = new ArrayList<ResourcePackRepository.Entry>();
    private final List<ResourcePackRepository.Entry> avail = new ArrayList<ResourcePackRepository.Entry>();
    /** Highest priority first (the order vanilla shows); the "Default" row is implicit at the end. */
    private final List<ResourcePackRepository.Entry> sel = new ArrayList<ResourcePackRepository.Entry>();
    private final List<String> initial = new ArrayList<String>();

    private float[] hoverA = new float[0], hoverS = new float[0];
    private float scrollA, scrollAT, scrollS, scrollST;
    private float dragHover;

    // press / drag state
    private boolean pressed, dragging;
    private boolean pressSel;
    private int pressIdx = -1;
    private int pressX, pressY;
    private float grabDX, grabDY;

    private long start = System.currentTimeMillis();
    private long last = start;
    private float fade;
    private float parX, parY;

    public LumenPackSelect(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    // ------------------------------------------------------------------------------------------
    // data
    // ------------------------------------------------------------------------------------------

    @Override
    public void initGui() {
        if (!all.isEmpty() || !sel.isEmpty() || !initial.isEmpty()) return; // coming back from nothing: keep state
        ResourcePackRepository repo = mc.getResourcePackRepository();
        repo.updateRepositoryEntriesAll();
        all = new ArrayList<ResourcePackRepository.Entry>(repo.getRepositoryEntriesAll());
        sel.addAll(repo.getRepositoryEntries());
        Collections.reverse(sel);
        for (ResourcePackRepository.Entry e : sel) initial.add(e.getResourcePackName());
        rebuildAvail();
    }

    private void rebuildAvail() {
        avail.clear();
        for (ResourcePackRepository.Entry e : all) {
            if (!sel.contains(e)) avail.add(e);
        }
    }

    private boolean changed() {
        if (initial.size() != sel.size()) return true;
        for (int i = 0; i < sel.size(); i++) {
            if (!initial.get(i).equals(sel.get(i).getResourcePackName())) return true;
        }
        return false;
    }

    private void apply() {
        if (!changed()) return;
        List<ResourcePackRepository.Entry> out = new ArrayList<ResourcePackRepository.Entry>(sel);
        Collections.reverse(out);
        mc.getResourcePackRepository().setRepositories(out);
        mc.gameSettings.resourcePacks.clear();
        for (ResourcePackRepository.Entry e : out) mc.gameSettings.resourcePacks.add(e.getResourcePackName());
        mc.gameSettings.saveOptions();
        mc.refreshResources();
    }

    private void openFolder() {
        File dir = mc.getResourcePackRepository().getDirResourcepacks();
        try {
            dir.mkdirs();
            java.awt.Desktop.getDesktop().open(dir);
        } catch (Throwable t) {
            try {
                org.lwjgl.Sys.openURL("file://" + dir.getAbsolutePath());
            } catch (Throwable ignored) {
                // nothing else to try
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // layout
    // ------------------------------------------------------------------------------------------

    private float k() {
        return height / 254f;
    }

    private float paneW() {
        return Math.min(width * 0.43f, 200f * k());
    }

    private float paneX(boolean selPane) {
        float gap = 18f * k();
        float x0 = (width - 2f * paneW() - gap) / 2f;
        return selPane ? x0 + paneW() + gap : x0;
    }

    private float listTop() {
        return height * 0.30f;
    }

    private float listBottom() {
        return height * 0.80f;
    }

    private float rowH() {
        return 30f * k();
    }

    private int rowsIn(boolean selPane) {
        return selPane ? sel.size() + 1 : avail.size();
    }

    private float maxScroll(boolean selPane) {
        return Math.max(0f, rowsIn(selPane) * rowH() - (listBottom() - listTop()));
    }

    private float scroll(boolean selPane) {
        return selPane ? scrollS : scrollA;
    }

    /** 0 = available pane, 1 = selected pane, -1 = none. */
    private int paneAt(int mx, int my) {
        if (my < listTop() - 4f * k() || my > listBottom()) return -1;
        for (int p = 0; p < 2; p++) {
            float x = paneX(p == 1);
            if (mx >= x && mx <= x + paneW()) return p;
        }
        return -1;
    }

    private int rowAt(boolean selPane, int my) {
        int i = (int) ((my - listTop() + scroll(selPane)) / rowH());
        return i >= 0 && i < rowsIn(selPane) ? i : -1;
    }

    /** Width of the "Draggable" check with its label (it sits right after "Open Pack Folder"). */
    private float checkW() {
        return checkSize() + 5f * k() + LumenFont.width("Draggable") * checkLabelScale();
    }

    private float actionX(int i, float[] outW) {
        float sc = 0.9f * k();
        float gap = 18f * k();
        float total = checkW() + gap;
        for (int n = 0; n < ACTIONS.length; n++) {
            outW[n] = LumenFont.width(ACTIONS[n]) * sc;
            total += outW[n] + (n > 0 ? gap : 0f);
        }
        float x = (width - total) / 2f;
        for (int n = 0; n < i; n++) {
            x += outW[n] + gap;
            if (n == A_FOLDER) x += checkW() + gap;
        }
        return x;
    }

    private float actionY() {
        return height * 0.90f;
    }

    private boolean overAction(int i, int mx, int my) {
        float[] w = new float[ACTIONS.length];
        float x = actionX(i, w);
        float pad = 6f * k();
        float cy = actionY();
        return mx >= x - pad && mx <= x + w[i] + pad && my >= cy - 9f * k() && my <= cy + 9f * k();
    }

    // "Draggable" check: in the action row, right after "Open Pack Folder"
    private float checkSize() {
        return 8f * k();
    }

    private float checkLabelScale() {
        return 0.8f * k();
    }

    private float checkX() {
        float[] w = new float[ACTIONS.length];
        return actionX(A_FOLDER, w) + w[A_FOLDER] + 18f * k();
    }

    private float checkY() {
        return actionY() - checkSize() / 2f;
    }

    private boolean overCheck(int mx, int my) {
        return mx >= checkX() - 4f * k() && mx <= checkX() + checkW() + 4f * k()
                && my >= checkY() - 3f * k() && my <= checkY() + checkSize() + 3f * k();
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (float) Math.pow(1f - x, 3);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    private static String plain(String s) {
        if (s == null) return "";
        String t = EnumChatFormatting.getTextWithoutFormattingCodes(s);
        if (t == null) return "";
        int nl = t.indexOf('\n');
        return (nl >= 0 ? t.substring(0, nl) : t).trim();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now - start) / 1000f;
        fade = Math.min(1f, fade + dt * 2.2f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        float pk = Math.min(1f, dt * 3f);
        parX += (((float) mouseX / Math.max(1, width) - 0.5f) * 2f - parX) * pk;
        parY += (((float) mouseY / Math.max(1, height) - 0.5f) * 2f - parY) * pk;
        float pox = -parX * width * 0.03f, poy = -parY * height * 0.03f;

        scrollAT = Math.max(0f, Math.min(maxScroll(false), scrollAT));
        scrollST = Math.max(0f, Math.min(maxScroll(true), scrollST));
        scrollA += (scrollAT - scrollA) * Math.min(1f, dt * 14f);
        scrollS += (scrollST - scrollS) * Math.min(1f, dt * 14f);
        if (hoverA.length != avail.size()) hoverA = new float[avail.size()];
        if (hoverS.length != sel.size() + 1) hoverS = new float[sel.size() + 1];

        Theme th = Theme.current();
        int tint = Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
        float k = k();

        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, true, pox, poy);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.11f));
        }
        GlStateManager.pushMatrix();
        GlStateManager.translate(pox * 0.5f, poy * 0.5f, 0f);
        Stripes.draw(width, height, t, e);
        GlStateManager.popMatrix();
        if (!th.glass) GlassFx.ambient(width, height, e, now, pox, poy);

        // ---- title ----
        float tScale = 1.5f * k;
        String first = "\u00a7oResource";
        String rest = " Packs";
        float tw = (LumenFont.width(first) + LumenFont.width(rest)) * tScale;
        float tx = (width - tw) / 2f;
        float te = ease((t - 0.05f) / 0.6f);
        float ty = height * 0.12f + (1f - te) * 10f * k;
        if (th.glass) {
            GlassFx.pane(tx - 14f * k, ty - 6f * k, tx + tw + 14f * k, ty + LumenFont.EM * tScale + 5f * k, 9f * k, te, 0f);
        }
        text(first, tx, ty, tScale, Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f), te));
        text(rest, tx + LumenFont.width(first) * tScale, ty, tScale, Colors.mulAlpha(0xFFFFFFFF, te));


        // ---- panes ----
        dragHover += (((dragging) ? 1f : 0f) - dragHover) * Math.min(1f, dt * 12f);
        int overPane = dragging ? paneAt(mouseX, mouseY) : -1;
        drawPane(false, mouseX, mouseY, t, dt, e, overPane);
        drawPane(true, mouseX, mouseY, t, dt, e, overPane);

        // ---- actions (with the "Draggable" check after Open Pack Folder) ----
        drawCheck(mouseX, mouseY, e * ease((t - 0.45f) / 0.5f), dt);
        float asc = 0.9f * k;
        float[] w = new float[ACTIONS.length];
        for (int i = 0; i < ACTIONS.length; i++) {
            float x = actionX(i, w);
            float ae = ease((t - 0.45f - i * 0.06f) / 0.5f);
            boolean hov = overAction(i, mouseX, mouseY);
            actionHover[i] += ((hov ? 1f : 0f) - actionHover[i]) * Math.min(1f, dt * 14f);
            float h = actionHover[i];
            int base = i == A_DONE ? 0xFFFFFFFF : 0xFFB8BCC6;
            int col = Colors.lerp(base, 0xFFFFFFFF, h);
            float sc = asc * (1f + 0.05f * h);
            float sw = LumenFont.width(ACTIONS[i]) * sc;
            float cy = actionY() + (1f - ae) * 8f * k;
            text(ACTIONS[i], x + (w[i] - sw) / 2f, cy - LumenFont.EM * sc / 2f, sc, Colors.mulAlpha(col, ae));
            if (h > 0.02f && !th.glass) {
                float lw = sw * h;
                float ly = cy + LumenFont.EM * sc / 2f + 2f * k;
                float mid = x + w[i] / 2f;
                RenderUtil.gradientH(mid - lw / 2f, ly, mid + lw / 2f, ly + Math.max(1f, k * 0.9f),
                        Colors.mulAlpha(Colors.opaque(th.c1), ae), Colors.mulAlpha(Colors.opaque(th.c3), ae));
            }
        }

        // ---- the pack being dragged follows the cursor ----
        if (dragging && pressIdx >= 0) {
            ResourcePackRepository.Entry en = pressSel ? sel.get(pressIdx) : avail.get(pressIdx);
            float gx = mouseX - grabDX, gy = mouseY - grabDY;
            float gw = paneW();
            if (th.glass) {
                GlassFx.pane(gx, gy + 1f * k, gx + gw, gy + rowH() - 1f * k, 7f * k, 0.95f, 1f);
            } else {
                RenderUtil.rect(gx, gy + 1f * k, gx + gw, gy + rowH() - 1f * k, 0xE0181A22);
                RenderUtil.gradientH(gx, gy + 1f * k, gx + gw, gy + rowH() - 1f * k,
                        Colors.withAlpha(th.c1, 70), Colors.withAlpha(th.c3, 30));
                RenderUtil.rectOutline(gx, gy + 1f * k, gx + gw, gy + rowH() - 1f * k, Math.max(1f, 0.8f * k),
                        Colors.withAlpha(th.c1, 150));
            }
            drawEntry(en, false, gx, gx + gw, gy, k, 1f, 1f, 1f);
        }

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawCheck(int mx, int my, float e, float dt) {
        Theme th = Theme.current();
        float k = k();
        float s = checkSize(), x = checkX(), y = checkY();
        boolean on = ClientSettings.packDraggable;
        boolean hov = overCheck(mx, my);
        int rim = Colors.lerp(0xFF6A6F7E, 0xFFFFFFFF, hov ? 1f : 0f);
        if (on) {
            RenderUtil.roundedRectH(x, y, x + s, y + s, 2f * k,
                    Colors.mulAlpha(Colors.opaque(th.c1), e), Colors.mulAlpha(Colors.opaque(th.c3), e));
            GlStateManager.disableTexture2D();
            GlStateManager.enableBlend();
            GL11.glLineWidth(Math.max(1.2f, 1.4f * k));
            GlStateManager.color(0.04f, 0.06f, 0.1f, e);
            GL11.glBegin(GL11.GL_LINE_STRIP);
            GL11.glVertex2f(x + s * 0.22f, y + s * 0.52f);
            GL11.glVertex2f(x + s * 0.43f, y + s * 0.74f);
            GL11.glVertex2f(x + s * 0.78f, y + s * 0.26f);
            GL11.glEnd();
            GL11.glLineWidth(1f);
            GlStateManager.enableTexture2D();
            GlStateManager.color(1f, 1f, 1f, 1f);
        } else {
            RenderUtil.roundedOutline(x, y, x + s, y + s, 2f * k, Math.max(1f, 0.9f * k),
                    Colors.mulAlpha(rim, e), Colors.mulAlpha(rim, e));
        }
        float sc = checkLabelScale();
        text("Draggable", x + s + 5f * k, y + (s - LumenFont.EM * sc) / 2f, sc,
                Colors.mulAlpha(on || hov ? 0xFFFFFFFF : 0xFFA0A5B3, e));
    }

    private void drawPane(boolean selPane, int mouseX, int mouseY, float t, float dt, float e, int overPane) {
        Theme th = Theme.current();
        float k = k();
        float px = paneX(selPane), px2 = px + paneW();
        float lt = listTop(), lb = listBottom(), rh = rowH();
        int n = rowsIn(selPane);
        float[] hv = selPane ? hoverS : hoverA;
        float sc = scroll(selPane);
        boolean paneHot = dragging && overPane == (selPane ? 1 : 0);
        boolean droppable = paneHot && (selPane || pressSel);

        // header
        String head = selPane ? "Selected" : "Available";
        float hs = 0.78f * k;
        text(head, px + 4f * k, lt - 13f * k, hs, Colors.mulAlpha(0xFF8E94A4, e));
        String count = String.valueOf(selPane ? sel.size() : avail.size());
        text(count, px2 - 4f * k - LumenFont.width(count) * hs, lt - 13f * k, hs, Colors.mulAlpha(0xFF5E6372, e));

        // drop highlight while dragging
        if (droppable) {
            RenderUtil.rect(px, lt - 3f * k, px2, lb, Colors.withAlpha(th.c1, (int) (14 * dragHover)));
        }

        int hoverRow = (!dragging && paneAt(mouseX, mouseY) == (selPane ? 1 : 0)) ? rowAt(selPane, mouseY) : -1;

        if (n == 0 || (!selPane && avail.isEmpty())) {
            String msg = "No more packs";
            float ms = 0.85f * k;
            text(msg, px + (paneW() - LumenFont.width(msg) * ms) / 2f, (lt + lb) / 2f, ms, Colors.mulAlpha(0xFF6A6F7E, e));
        }

        RenderUtil.scissor(px - 2f * k, lt, paneW() + 4f * k, lb - lt);
        for (int i = 0; i < n; i++) {
            float ry = lt + i * rh - sc;
            if (ry + rh < lt || ry > lb) continue;
            boolean isDefault = selPane && i == sel.size();
            float ie = ease((t - 0.2f - Math.min(i, 8) * 0.05f) / 0.55f);
            hv[i] += (((i == hoverRow) ? 1f : 0f) - hv[i]) * Math.min(1f, dt * 14f);
            float h = hv[i];
            boolean beingDragged = dragging && pressSel == selPane && pressIdx == i;
            float yy = ry + (1f - ie) * 10f * k;
            float alpha = beingDragged ? 0.3f : 1f;

            if (th.glass) {
                if (h > 0.02f) GlassFx.pane(px, yy + 1f * k, px2, yy + rh - 1f * k, 7f * k, ie * alpha, h * 0.7f);
            } else if (h > 0.02f) {
                RenderUtil.rect(px, yy + 1f * k, px2, yy + rh - 1f * k, Colors.mulAlpha(Colors.withAlpha(0xFFFFFF, 14), h * ie * alpha));
            }
            if (selPane && !isDefault) {
                RenderUtil.rect(px, yy + 4f * k, px + Math.max(1f, 1.4f * k), yy + rh - 4f * k,
                        Colors.mulAlpha(Colors.opaque(th.c1), ie * alpha));
            }
            ResourcePackRepository.Entry en = isDefault ? null : (selPane ? sel.get(i) : avail.get(i));
            drawEntry(en, isDefault, px, px2, yy, k, ie * alpha, Math.max(h, 0f), 1f);

            // reorder arrows on hover (selected pane only, not on Default)
            if (selPane && !isDefault && h > 0.05f) {
                float ax = px2 - 11f * k, cy = yy + rh / 2f;
                int up = i > 0 ? 0xFFB8BCC6 : 0xFF3E424E, dn = i < sel.size() - 1 ? 0xFFB8BCC6 : 0xFF3E424E;
                RenderUtil.triangle(ax, cy - 5f * k, 3.2f * k, 270f, Colors.mulAlpha(up, h * ie));
                RenderUtil.triangle(ax, cy + 5f * k, 3.2f * k, 90f, Colors.mulAlpha(dn, h * ie));
            }
        }

        // insertion marker while dragging over the selected list
        if (selPane && dragging && overPane == 1) {
            int ins = insertIndex(mouseY);
            float iy = lt + ins * rh - sc;
            RenderUtil.gradientH(px, iy - 1f * k, px2, iy + Math.max(1f, 1.2f * k),
                    Colors.opaque(th.c1), Colors.opaque(th.c3));
        }
        RenderUtil.endScissor();

        // scroll indicator
        if (maxScroll(selPane) > 0f) {
            float trackH = lb - lt;
            float barH = Math.max(14f * k, trackH * trackH / (trackH + maxScroll(selPane)));
            float by = lt + (trackH - barH) * (sc / maxScroll(selPane));
            RenderUtil.roundedRect(px2 + 3f * k, by, px2 + 3f * k + Math.max(1.5f, 1.6f * k), by + barH,
                    1f * k, Colors.mulAlpha(Colors.withAlpha(th.c1, 160), e));
        }
    }

    private void drawEntry(ResourcePackRepository.Entry en, boolean isDefault, float x, float x2, float yy,
                           float k, float alpha, float active, float unused) {
        Theme th = Theme.current();
        float rh = rowH();
        float icon = 22f * k;
        float ix = x + 8f * k, iy = yy + (rh - icon) / 2f;

        if (isDefault) {
            RenderUtil.roundedRectH(ix, iy, ix + icon, iy + icon, 3f * k,
                    Colors.mulAlpha(Colors.withAlpha(th.c1, 120), alpha), Colors.mulAlpha(Colors.withAlpha(th.c3, 120), alpha));
        } else {
            en.bindTexturePackIcon(mc.getTextureManager());
            GlStateManager.enableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.color(1f, 1f, 1f, Math.max(0f, Math.min(1f, alpha)));
            Gui.drawScaledCustomSizeModalRect((int) ix, (int) iy, 0f, 0f, 1, 1, (int) icon, (int) icon, 1f, 1f);
            GlStateManager.color(1f, 1f, 1f, 1f);
        }

        float tx = ix + icon + 8f * k;
        float ns = 0.9f * k, ds = 0.68f * k;
        float room = (x2 - 16f * k) - tx;
        String name = isDefault ? "Default" : en.getResourcePackName();
        String desc = isDefault ? "Vanilla textures (always at the bottom)" : plain(en.getTexturePackDescription());
        int nameCol = Colors.lerp(0xFFC4C8D2, 0xFFFFFFFF, active);
        text(LumenFont.trim(name, room / ns), tx, yy + 5f * k, ns, Colors.mulAlpha(nameCol, alpha));
        text(LumenFont.trim(desc, room / ds), tx, yy + 5f * k + 11f * k, ds, Colors.mulAlpha(0xFF7E8494, alpha));
    }

    /** Where a dragged pack would be inserted in the selected list (0..sel.size()). */
    private int insertIndex(int my) {
        int i = Math.round((my - listTop() + scrollS) / rowH() - 0.0f);
        return Math.max(0, Math.min(sel.size(), i));
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) {
            int mx = Mouse.getEventX() * width / mc.displayWidth;
            int my = height - Mouse.getEventY() * height / mc.displayHeight - 1;
            int p = paneAt(mx, my);
            if (p < 0) p = mx < width / 2 ? 0 : 1;
            float step = d < 0 ? rowH() : -rowH();
            if (p == 1) scrollST = Math.max(0f, Math.min(maxScroll(true), scrollST + step));
            else scrollAT = Math.max(0f, Math.min(maxScroll(false), scrollAT + step));
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        for (int i = 0; i < ACTIONS.length; i++) {
            if (overAction(i, mouseX, mouseY)) {
                Sounds.click();
                runAction(i);
                return;
            }
        }
        if (overCheck(mouseX, mouseY)) {
            Sounds.toggle(!ClientSettings.packDraggable);
            ClientSettings.packDraggable = !ClientSettings.packDraggable;
            ConfigManager.save();
            return;
        }
        int p = paneAt(mouseX, mouseY);
        if (p < 0) return;
        boolean selPane = p == 1;
        int row = rowAt(selPane, mouseY);
        if (row < 0) return;
        boolean isDefault = selPane && row == sel.size();

        // reorder arrows
        if (selPane && !isDefault) {
            float k = k();
            float ax = paneX(true) + paneW() - 11f * k;
            float cy = listTop() + row * rowH() - scrollS + rowH() / 2f;
            if (Math.abs(mouseX - ax) <= 5f * k) {
                if (Math.abs(mouseY - (cy - 5f * k)) <= 5f * k) {
                    move(row, row - 1);
                    Sounds.click();
                    return;
                }
                if (Math.abs(mouseY - (cy + 5f * k)) <= 5f * k) {
                    move(row, row + 1);
                    Sounds.click();
                    return;
                }
            }
        }
        if (isDefault) return;
        pressed = true;
        dragging = false;
        pressSel = selPane;
        pressIdx = row;
        pressX = mouseX;
        pressY = mouseY;
        float rowTop = listTop() + row * rowH() - scroll(selPane);
        grabDX = mouseX - paneX(selPane);
        grabDY = mouseY - rowTop;
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
        if (!pressed || button != 0 || dragging || !ClientSettings.packDraggable) return;
        if (Math.abs(mouseX - pressX) + Math.abs(mouseY - pressY) > 5) {
            dragging = true;
            Sounds.click();
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        if (state != 0 || !pressed) return;
        boolean wasDrag = dragging;
        boolean fromSel = pressSel;
        int idx = pressIdx;
        pressed = false;
        dragging = false;
        pressIdx = -1;
        if (idx < 0) return;
        List<ResourcePackRepository.Entry> src = fromSel ? sel : avail;
        if (idx >= src.size()) return;

        if (!wasDrag) {
            // plain click: move it across
            if (rowAt(fromSel, mouseY) == idx && paneAt(mouseX, mouseY) == (fromSel ? 1 : 0)) {
                Sounds.click();
                ResourcePackRepository.Entry en = src.remove(idx);
                if (fromSel) {
                    rebuildAvail();
                } else {
                    sel.add(0, en);
                    rebuildAvail();
                }
                if (!fromSel) scrollAT = Math.min(scrollAT, maxScroll(false));
            }
            return;
        }

        int over = paneAt(mouseX, mouseY);
        ResourcePackRepository.Entry en = src.get(idx);
        if (over == 1) {
            int ins = insertIndex(mouseY);
            if (fromSel) {
                sel.remove(idx);
                if (ins > idx) ins--;
            }
            sel.add(Math.max(0, Math.min(sel.size(), ins)), en);
            rebuildAvail();
        } else if (over == 0 && fromSel) {
            sel.remove(idx);
            rebuildAvail();
        }
    }

    private void move(int from, int to) {
        if (to < 0 || to >= sel.size() || from < 0 || from >= sel.size()) return;
        ResourcePackRepository.Entry en = sel.remove(from);
        sel.add(to, en);
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) {
            runAction(A_CANCEL);
        } else if (key == Keyboard.KEY_RETURN) {
            runAction(A_DONE);
        }
    }

    private void runAction(int a) {
        switch (a) {
            case A_FOLDER:
                openFolder();
                break;
            case A_DONE:
                apply();
                mc.displayGuiScreen(parent);
                break;
            default:
                mc.displayGuiScreen(parent);
                break;
        }
    }
}
