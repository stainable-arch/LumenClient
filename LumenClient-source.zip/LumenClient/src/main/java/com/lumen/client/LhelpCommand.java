package com.lumen.client;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;

/** Client-side chat command "/lhelp": lists the Lumen commands. */
public class LhelpCommand extends CommandBase {
    @Override
    public String getCommandName() {
        return "lhelp";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/lhelp";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        LumenCommand.sendHelp(sender);
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }
}
