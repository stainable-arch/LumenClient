package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

/** Displays useful movement states as a compact HUD list. */
public class StatusHud extends HudModule {
    public StatusHud() {
        super("Movement Status", "Shows active movement states such as sprint, flying and sneaking.", Category.HUD, 4, 80);
    }

    @Override protected void draw() {
        List<String> lines = new ArrayList<String>();
        if (mc.thePlayer != null) {
            if (mc.thePlayer.isSprinting()) lines.add("sprint (toggled)");
            if (mc.thePlayer.capabilities.isFlying) lines.add("flying");
            if (mc.thePlayer.isSneaking()) lines.add("sneaking");
            if (mc.thePlayer.isInWater()) lines.add("swimming");
            if (mc.thePlayer.isRiding()) lines.add("riding");
        }
        if (lines.isEmpty() && editing()) lines.add("movement status");
        float w = 0;
        for (String line : lines) w = Math.max(w, RenderUtil.width(line));
        box(w + 10, lines.size() * 11 + 4);
        for (int i = 0; i < lines.size(); i++) {
            RenderUtil.string(lines.get(i), 5, 3 + i * 11, 0xFFF1F3FA);
        }
    }
}
