package com.lumen.client.asm;

import java.util.Map;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

/** Coremod entry point: registers the menu-FPS-unlock transformer. */
@IFMLLoadingPlugin.MCVersion("1.8.9")
@IFMLLoadingPlugin.Name("LumenCore")
@IFMLLoadingPlugin.SortingIndex(1001)
@IFMLLoadingPlugin.TransformerExclusions({"com.lumen.client.asm."})
public class LumenCorePlugin implements IFMLLoadingPlugin {
    public String[] getASMTransformerClass() { return new String[] { "com.lumen.client.asm.FramerateTransformer" }; }
    public String getModContainerClass() { return null; }
    public String getSetupClass() { return null; }
    public void injectData(Map<String, Object> data) { }
    public String getAccessTransformerClass() { return null; }
}
