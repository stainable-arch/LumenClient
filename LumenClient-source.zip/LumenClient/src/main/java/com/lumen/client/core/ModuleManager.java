package com.lumen.client.core;

import com.lumen.client.modules.ArmorStatus;
import com.lumen.client.modules.BedVisuals;
import com.lumen.client.modules.ComboCounter;
import com.lumen.client.modules.CpsDisplay;
import com.lumen.client.modules.FpsDisplay;
import com.lumen.client.modules.HitVisuals;
import com.lumen.client.modules.Keystrokes;
import com.lumen.client.modules.MinimalViewBobbing;
import com.lumen.client.modules.NoHurtCam;
import com.lumen.client.modules.PotionStatus;
import com.lumen.client.modules.ReachDisplay;
import com.lumen.client.modules.ToggleSprint;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> modules = new ArrayList<Module>();

    private ModuleManager() {}

    public static void init() {
        // HUD
        modules.add(new CpsDisplay());
        modules.add(new FpsDisplay());
        modules.add(new Keystrokes());
        modules.add(new ArmorStatus());
        modules.add(new PotionStatus());
        // Combat
        modules.add(new HitVisuals());
        modules.add(new ComboCounter());
        modules.add(new ReachDisplay());
        modules.add(new ToggleSprint());
        // Visuals
        modules.add(new BedVisuals());
        modules.add(new NoHurtCam());
        modules.add(new MinimalViewBobbing());
    }

    public static List<Module> byCategory(Category category) {
        List<Module> out = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.category == category) out.add(m);
        }
        return out;
    }
}
