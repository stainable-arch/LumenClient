package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.util.CombatTracker;

public class ComboCounter extends HudModule {
    private final BooleanSetting showBest = add(new BooleanSetting("Show Best", false));

    public ComboCounter() {
        super("Combo Counter", "Counts your consecutive hits until the enemy hits you back.", Category.COMBAT, 4, 58);
    }

    @Override
    protected void draw() {
        String value = CombatTracker.combo + (CombatTracker.combo == 1 ? " hit" : " hits");
        if (showBest.value) {
            value += "  (best " + CombatTracker.bestCombo + ")";
        }
        labelValue("Combo", value);
    }
}
