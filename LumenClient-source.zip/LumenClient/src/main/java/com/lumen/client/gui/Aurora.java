package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

import java.util.Random;

/** Animated northern-lights background for the ClickGUI: twinkling stars plus three drifting ribbons. */
public final class Aurora {
    private static final float[][] STARS = new float[80][4];

    static {
        Random rnd = new Random(1337L);
        for (float[] s : STARS) {
            s[0] = rnd.nextFloat();
            s[1] = rnd.nextFloat() * 0.8f;
            s[2] = rnd.nextFloat() * 6.2831f;
            s[3] = rnd.nextFloat() < 0.15f ? 2f : 1f;
        }
    }

    private Aurora() {}

    public static void draw(int w, int h, float alpha, long ms) {
        Theme th = Theme.current();
        float t = ms / 1000f;

        for (float[] s : STARS) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 1.4f + s[2]);
            int a = (int) (170 * alpha * tw);
            if (a < 6) continue;
            float sx = s[0] * w;
            float sy = s[1] * h;
            RenderUtil.rect(sx, sy, sx + s[3], sy + s[3], Colors.withAlpha(0xFFFFFF, a));
        }

        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.shadeModel(7425);
        GlStateManager.blendFunc(770, 1); // additive glow

        ribbon(w, h, t, alpha, th.c1, 0.30f, 0.07f, 0.011f, 0.55f, 0.0f, 0.30f);
        ribbon(w, h, t, alpha, th.c2, 0.42f, 0.09f, 0.008f, -0.38f, 2.0f, 0.34f);
        ribbon(w, h, t, alpha, th.c3, 0.55f, 0.06f, 0.013f, 0.27f, 4.1f, 0.24f);

        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7424);
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void ribbon(int w, int h, float t, float alpha, int rgb, float base, float amp,
                               float freq, float speed, float phase, float height) {
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int b = rgb & 255;
        float step = 4f;
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        for (float x = 0; x < w; x += step) {
            float x2 = x + step;
            float c1 = center(h, x, t, base, amp, freq, speed, phase);
            float c2 = center(h, x2, t, base, amp, freq, speed, phase);
            float up1 = height * h * (0.75f + 0.25f * (float) Math.sin(x * 0.03f + t * 0.7f + phase));
            float up2 = height * h * (0.75f + 0.25f * (float) Math.sin(x2 * 0.03f + t * 0.7f + phase));
            int a1 = alphaAt(x, t, phase, alpha);
            int a2 = alphaAt(x2, t, phase, alpha);

            // upper half: transparent at the top, bright at the centre line
            wr.pos(x, c1 - up1, 0).color(r, g, b, 0).endVertex();
            wr.pos(x, c1, 0).color(r, g, b, a1).endVertex();
            wr.pos(x2, c2, 0).color(r, g, b, a2).endVertex();
            wr.pos(x2, c2 - up2, 0).color(r, g, b, 0).endVertex();

            // short soft fade below the centre line
            wr.pos(x, c1, 0).color(r, g, b, a1).endVertex();
            wr.pos(x, c1 + up1 * 0.25f, 0).color(r, g, b, 0).endVertex();
            wr.pos(x2, c2 + up2 * 0.25f, 0).color(r, g, b, 0).endVertex();
            wr.pos(x2, c2, 0).color(r, g, b, a2).endVertex();
        }
        tess.draw();
    }

    private static float center(int h, float x, float t, float base, float amp, float freq, float speed, float phase) {
        return h * base
                + (float) Math.sin(x * freq + t * speed + phase) * h * amp
                + (float) Math.sin(x * freq * 2.3f - t * speed * 0.6f) * h * amp * 0.35f;
    }

    private static int alphaAt(float x, float t, float phase, float alpha) {
        float ray = 0.55f + 0.45f * (float) Math.sin(x * 0.045f + t * 0.9f + phase);
        return (int) Math.max(0, Math.min(255, 95 * ray * alpha));
    }
}
