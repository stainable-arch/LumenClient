package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/** Sprint helper. Sneak is deliberately opt-in and off by default. */
public class ToggleSprint extends Module {
    private final BooleanSetting holdSneak = add(new BooleanSetting("Toggle Sneak", false));

    public ToggleSprint() {
        super("Toggle Sprint", "Keeps sprint active while moving; optional sneak is disabled by default.", Category.COMBAT);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.START || mc.thePlayer == null || mc.gameSettings == null) return;
        if (mc.currentScreen != null) return;
        int sprint = mc.gameSettings.keyBindSprint.getKeyCode();
        KeyBinding.setKeyBindState(sprint, true);
        if (holdSneak.value) {
            int sneak = mc.gameSettings.keyBindSneak.getKeyCode();
            KeyBinding.setKeyBindState(sneak, true);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.gameSettings == null) return;
        int sprint = mc.gameSettings.keyBindSprint.getKeyCode();
        KeyBinding.setKeyBindState(sprint, sprint > 0 && Keyboard.isKeyDown(sprint));
        int sneak = mc.gameSettings.keyBindSneak.getKeyCode();
        KeyBinding.setKeyBindState(sneak, holdSneak.value && sneak > 0 && Keyboard.isKeyDown(sneak));
    }
}
