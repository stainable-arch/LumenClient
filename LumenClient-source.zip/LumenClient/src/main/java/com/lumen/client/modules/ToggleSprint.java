package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/** Keeps the sprint key held for you: just hold W and you sprint. */
public class ToggleSprint extends Module {
    public ToggleSprint() {
        super("Toggle Sprint", "Always sprint while moving forward, no need to hold the sprint key.", Category.COMBAT);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.START || mc.thePlayer == null || mc.currentScreen != null) return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
    }

    @Override
    protected void onDisable() {
        if (mc.gameSettings == null) return;
        int code = mc.gameSettings.keyBindSprint.getKeyCode();
        KeyBinding.setKeyBindState(code, code > 0 && Keyboard.isKeyDown(code));
    }
}
