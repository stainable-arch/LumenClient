package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.util.ClickCounter;

public class CpsDisplay extends HudModule {
    private final BooleanSetting showRight = add(new BooleanSetting("Show Right CPS", true));

    public CpsDisplay() {
        super("CPS Display", "Shows how many times per second you click.", Category.HUD, 4, 4);
    }

    @Override
    protected void draw() {
        int left = ClickCounter.cps(true);
        int right = ClickCounter.cps(false);
        labelValue("CPS", showRight.value ? left + " | " + right : String.valueOf(left));
    }
}
