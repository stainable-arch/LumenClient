package com.lumen.client.modules;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Backs Settings > Performance > Entity Culling: skips drawing living entities beyond a distance. Visual only. */
public final class EntityCulling {
    public static final EntityCulling INSTANCE = new EntityCulling();

    private final Minecraft mc = Minecraft.getMinecraft();

    private EntityCulling() {}

    @SubscribeEvent
    public void onLiving(RenderLivingEvent.Pre e) {
        if (!ClientSettings.entityCulling.value) return;
        Entity view = mc.getRenderViewEntity();
        if (view == null || e.entity == view || e.entity == mc.thePlayer) return;
        if (e.entity instanceof EntityPlayer && !ClientSettings.cullPlayers.value) return;
        double max = ClientSettings.cullDistance.value;
        if (e.entity.getDistanceSqToEntity(view) > max * max) e.setCanceled(true);
    }
}
