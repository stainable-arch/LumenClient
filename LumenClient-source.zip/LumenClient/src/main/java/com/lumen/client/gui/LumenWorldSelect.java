package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiCreateWorld;
import net.minecraft.client.gui.GuiRenameWorld;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.AnvilConverterException;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.SaveFormatComparator;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Singleplayer world list in the same look as {@link LumenMainMenu}: themed near-black background,
 * drifting stripes, text-only entries and text-only actions.
 */
public class LumenWorldSelect extends GuiScreen implements GuiYesNoCallback {
    private static final String[] ACTIONS = { "Play Selected World", "Create New World", "Edit", "Delete", "Back" };
    private static final int A_PLAY = 0, A_CREATE = 1, A_EDIT = 2, A_DELETE = 3, A_BACK = 4;

    private final GuiScreen parent;
    private final List<SaveFormatComparator> saves = new ArrayList<SaveFormatComparator>();
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private final float[] actionHover = new float[ACTIONS.length];
    private float[] rowHover = new float[0];

    private int selected = -1;
    private float scroll, scrollTarget;

    // cursor scrolling: drag the scrollbar, or drag the list itself
    private boolean barDrag, listPress, listDragging;
    private float barGrab, pressY, pressScroll;
    private int pressSelected, pressLastRow;
    private long pressLastTime;
    private boolean loadingWorld;
    private String error;

    private long start = System.currentTimeMillis();
    private long last = start;
    private float fade;
    private float parX, parY;
    private long lastClickTime;
    private int lastClickRow = -1;

    public LumenWorldSelect(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        loadingWorld = false;
        reload();
    }

    private void reload() {
        saves.clear();
        error = null;
        try {
            ISaveFormat fmt = mc.getSaveLoader();
            List<SaveFormatComparator> list = fmt.getSaveList();
            Collections.sort(list);
            saves.addAll(list);
        } catch (AnvilConverterException ex) {
            error = "Unable to load worlds";
        }
        rowHover = new float[saves.size()];
        if (selected >= saves.size()) selected = saves.isEmpty() ? -1 : saves.size() - 1;
        if (selected < 0 && !saves.isEmpty()) selected = 0;
    }

    // ------------------------------------------------------------------------------------------
    // layout (everything scales with the screen height, like the main menu)
    // ------------------------------------------------------------------------------------------

    /**
     * Fixed layout factor, so these screens follow the GUI scale setting (a size in GUI units
     * grows/shrinks with it). 0.85 is 0.8x the old height-based size at 1080p / GUI scale 4.
     */
    private float k() {
        return 0.85f;
    }

    private float listTop() {
        return height * 0.27f;
    }

    private float listBottom() {
        return height * 0.80f;
    }

    private float rowH() {
        return 27f * k();
    }

    private float listW() {
        return Math.min(width * 0.7f, 330f * k());
    }

    private float maxScroll() {
        return Math.max(0f, saves.size() * rowH() - (listBottom() - listTop()));
    }

    private float actionX(int i, float[] outW) {
        float sc = 0.9f * k();
        float gap = 16f * k();
        float total = 0f;
        for (int n = 0; n < ACTIONS.length; n++) {
            outW[n] = LumenFont.width(ACTIONS[n]) * sc;
            total += outW[n] + (n > 0 ? gap : 0f);
        }
        float x = (width - total) / 2f;
        for (int n = 0; n < i; n++) x += outW[n] + gap;
        return x;
    }

    private float actionY() {
        return height * 0.90f;
    }

    private boolean actionEnabled(int i) {
        if (i == A_PLAY || i == A_EDIT || i == A_DELETE) {
            if (selected < 0 || selected >= saves.size()) return false;
            if (i == A_PLAY && saves.get(selected).requiresConversion()) return false;
        }
        return true;
    }

    private boolean overAction(int i, int mx, int my) {
        float[] w = new float[ACTIONS.length];
        float x = actionX(i, w);
        float pad = 6f * k();
        float cy = actionY();
        return mx >= x - pad && mx <= x + w[i] + pad && my >= cy - 9f * k() && my <= cy + 9f * k();
    }

    private int rowAt(int mx, int my) {
        if (my < listTop() || my > listBottom()) return -1;
        if (mx < (width - listW()) / 2f || mx > (width + listW()) / 2f) return -1;
        int i = (int) ((my - listTop() + scroll) / rowH());
        return i >= 0 && i < saves.size() ? i : -1;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (float) Math.pow(1f - x, 3);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now - start) / 1000f;
        fade = Math.min(1f, fade + dt * 2.2f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        float pk = Math.min(1f, dt * 3f);
        parX += (((float) mouseX / Math.max(1, width) - 0.5f) * 2f - parX) * pk;
        parY += (((float) mouseY / Math.max(1, height) - 0.5f) * 2f - parY) * pk;
        float pox = -parX * width * 0.03f, poy = -parY * height * 0.03f;

        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);

        Theme th = Theme.current();
        int tint = Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
        float k = k();

        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // same background as the title screen
        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, true, pox, poy);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.11f));
        }
        GlStateManager.pushMatrix();
        GlStateManager.translate(pox * 0.5f, poy * 0.5f, 0f);
        Stripes.draw(width, height, t, e);
        GlStateManager.popMatrix();
        if (!th.glass) GlassFx.ambient(width, height, e, now, pox, poy);

        // ---- title ----
        float tScale = 1.5f * k;
        String first = "\u00a7oSingle";
        String rest = "player";
        float tw = (LumenFont.width(first) + LumenFont.width(rest)) * tScale;
        float tx = (width - tw) / 2f;
        float te = ease((t - 0.05f) / 0.6f);
        float ty = height * 0.12f + (1f - te) * 10f * k;
        if (th.glass) {
            GlassFx.pane(tx - 14f * k, ty - 6f * k, tx + tw + 14f * k, ty + LumenFont.EM * tScale + 5f * k, 9f * k, te, 0f);
        }
        text(first, tx, ty, tScale, Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f), te));
        text(rest, tx + LumenFont.width(first) * tScale, ty, tScale, Colors.mulAlpha(0xFFFFFFFF, te));

        // ---- world list ----
        float lx = (width - listW()) / 2f, lx2 = lx + listW();
        float lt = listTop(), lb = listBottom(), rh = rowH();
        int hoverRow = rowAt(mouseX, mouseY);

        if (saves.isEmpty()) {
            String msg = error != null ? error : "No worlds yet \u2013 create one below";
            float sc = 0.95f * k;
            text(msg, (width - LumenFont.width(msg) * sc) / 2f, (lt + lb) / 2f - LumenFont.EM * sc / 2f, sc,
                    Colors.mulAlpha(0xFFB8BCC6, e));
        } else {
            RenderUtil.scissor(0, lt, width, lb - lt);
            for (int i = 0; i < saves.size(); i++) {
                float ry = lt + i * rh - scroll;
                if (ry + rh < lt || ry > lb) continue;
                float ie = ease((t - 0.2f - Math.min(i, 8) * 0.06f) / 0.55f);
                boolean sel = i == selected;
                rowHover[i] += (((i == hoverRow) ? 1f : 0f) - rowHover[i]) * Math.min(1f, dt * 14f);
                float h = rowHover[i];
                float lit = Math.max(sel ? 1f : 0f, h * 0.7f);
                float yy = ry + (1f - ie) * 10f * k;

                if (th.glass) {
                    if (lit > 0.02f) GlassFx.pane(lx, yy + 1f * k, lx2, yy + rh - 1f * k, 7f * k, ie, lit);
                } else if (sel) {
                    RenderUtil.gradientH(lx, yy + 1f * k, lx2, yy + rh - 1f * k,
                            Colors.mulAlpha(Colors.withAlpha(th.c1, 34), ie), Colors.mulAlpha(Colors.withAlpha(th.c3, 8), ie));
                } else if (h > 0.02f) {
                    RenderUtil.rect(lx, yy + 1f * k, lx2, yy + rh - 1f * k, Colors.mulAlpha(Colors.withAlpha(0xFFFFFF, 12), h * ie));
                }
                if (sel) {
                    RenderUtil.rect(lx, yy + 3f * k, lx + Math.max(1f, 1.4f * k), yy + rh - 3f * k,
                            Colors.mulAlpha(Colors.opaque(th.c1), ie));
                }

                SaveFormatComparator s = saves.get(i);
                String name = s.getDisplayName();
                if (name == null || name.length() == 0) name = I18n.format("selectWorld.world") + " " + (i + 1);
                float ns = 0.95f * k, ds = 0.7f * k;
                float pad = 10f * k;
                int nameCol = Colors.lerp(0xFFC4C8D2, 0xFFFFFFFF, Math.max(h, sel ? 1f : 0f));
                text(LumenFont.trim(name, (listW() - pad * 2f) / ns), lx + pad, yy + 4f * k, ns, Colors.mulAlpha(nameCol, ie));

                String info = s.getFileName() + "  \u00b7  " + dateFormat.format(new Date(s.getLastTimePlayed()));
                info += "  \u00b7  " + modeName(s);
                if (s.requiresConversion()) info += "  \u00b7  needs conversion";
                text(LumenFont.trim(info, (listW() - pad * 2f) / ds), lx + pad, yy + 4f * k + 11.5f * k, ds,
                        Colors.mulAlpha(0xFF7E8494, ie));
            }
            RenderUtil.endScissor();

            // soft fade at list edges + slim scroll indicator
            RenderUtil.gradientV(0, lt - 1f * k, width, lt + 10f * k, Colors.lerp(0xFF000000, tint, 0.05f) & 0x00FFFFFF | 0x66000000, 0x00000000);
            if (maxScroll() > 0f) {
                float trackH = lb - lt;
                float barH = Math.max(14f * k, trackH * trackH / (trackH + maxScroll()));
                float by = lt + (trackH - barH) * (scroll / maxScroll());
                RenderUtil.roundedRect(lx2 + 6f * k, by, lx2 + 6f * k + Math.max(1.5f, 1.6f * k), by + barH,
                        1f * k, Colors.mulAlpha(Colors.withAlpha(th.c1, 160), e));
            }
        }

        // ---- actions (text only) ----
        float asc = 0.9f * k;
        float[] w = new float[ACTIONS.length];
        for (int i = 0; i < ACTIONS.length; i++) {
            float x = actionX(i, w);
            float ae = ease((t - 0.45f - i * 0.06f) / 0.5f);
            boolean en = actionEnabled(i);
            boolean hov = en && overAction(i, mouseX, mouseY);
            actionHover[i] += ((hov ? 1f : 0f) - actionHover[i]) * Math.min(1f, dt * 14f);
            float h = actionHover[i];
            int base = !en ? 0xFF4A4E5A : (i == A_PLAY ? 0xFFFFFFFF : 0xFFB8BCC6);
            int col = Colors.lerp(base, 0xFFFFFFFF, h);
            float sc = asc * (1f + 0.05f * h);
            float sw = LumenFont.width(ACTIONS[i]) * sc;
            float cy = actionY() + (1f - ae) * 8f * k;
            text(ACTIONS[i], x + (w[i] - sw) / 2f, cy - LumenFont.EM * sc / 2f, sc, Colors.mulAlpha(col, ae));
            if (h > 0.02f && !th.glass) {
                float lw = sw * h;
                float ly = cy + LumenFont.EM * sc / 2f + 2f * k;
                float mid = x + w[i] / 2f;
                RenderUtil.gradientH(mid - lw / 2f, ly, mid + lw / 2f, ly + Math.max(1f, k * 0.9f),
                        Colors.mulAlpha(Colors.opaque(th.c1), ae), Colors.mulAlpha(Colors.opaque(th.c3), ae));
            }
        }

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static String modeName(SaveFormatComparator s) {
        if (s.isHardcoreModeEnabled()) return "Hardcore";
        switch (s.getEnumGameType()) {
            case SURVIVAL: return "Survival";
            case CREATIVE: return "Creative";
            case ADVENTURE: return "Adventure";
            case SPECTATOR: return "Spectator";
            default: return "Unknown";
        }
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    private boolean inList(int mx, int my) {
        return my >= listTop() && my <= listBottom()
                && mx >= (width - listW()) / 2f && mx <= (width + listW()) / 2f;
    }

    private float barH() {
        float trackH = listBottom() - listTop();
        return Math.max(14f * k(), trackH * trackH / (trackH + maxScroll()));
    }

    private float barY() {
        float trackH = listBottom() - listTop();
        return listTop() + (trackH - barH()) * (scroll / maxScroll());
    }

    /** the scrollbar plus a comfortable grab margin around it */
    private boolean overBar(int mx, int my) {
        if (maxScroll() <= 0f) return false;
        float bx = (width + listW()) / 2f + 6f * k();
        return mx >= bx - 6f * k() && mx <= bx + 9f * k() && my >= listTop() && my <= listBottom();
    }

    private void setScroll(float v) {
        scrollTarget = scroll = Math.max(0f, Math.min(maxScroll(), v));
    }

    private void dragBarTo(int my) {
        float range = (listBottom() - listTop()) - barH();
        if (range <= 0f) return;
        setScroll((my - barGrab - listTop()) / range * maxScroll());
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, button, timeSinceLastClick);
        if (barDrag) {
            dragBarTo(mouseY);
        } else if (listPress) {
            if (!listDragging && Math.abs(mouseY - pressY) > 3f) {
                listDragging = true;
                // it was a drag, not a click: undo the selection the press made
                selected = pressSelected;
                lastClickRow = pressLastRow;
                lastClickTime = pressLastTime;
            }
            if (listDragging) setScroll(pressScroll - (mouseY - pressY));
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        barDrag = false;
        listPress = false;
        listDragging = false;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) {
            scrollTarget += d < 0 ? rowH() : -rowH();
            scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        for (int i = 0; i < ACTIONS.length; i++) {
            if (actionEnabled(i) && overAction(i, mouseX, mouseY)) {
                Sounds.click();
                runAction(i);
                return;
            }
        }
        if (maxScroll() > 0f && overBar(mouseX, mouseY)) {
            float by = barY(), bh = barH();
            barGrab = (mouseY >= by && mouseY <= by + bh) ? mouseY - by : bh / 2f; // click track = jump there
            barDrag = true;
            dragBarTo(mouseY);
            return;
        }
        pressSelected = selected;
        pressLastRow = lastClickRow;
        pressLastTime = lastClickTime;
        if (inList(mouseX, mouseY) && maxScroll() > 0f) {
            listPress = true;
            listDragging = false;
            pressY = mouseY;
            pressScroll = scroll;
        }
        int row = rowAt(mouseX, mouseY);
        if (row >= 0) {
            long now = System.currentTimeMillis();
            Sounds.click();
            if (row == lastClickRow && now - lastClickTime < 400L) {
                selected = row;
                runAction(A_PLAY);
                return;
            }
            selected = row;
            lastClickRow = row;
            lastClickTime = now;
        }
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) {
            runAction(A_BACK);
        } else if (key == Keyboard.KEY_RETURN) {
            if (actionEnabled(A_PLAY)) runAction(A_PLAY);
        } else if (key == Keyboard.KEY_UP && !saves.isEmpty()) {
            selected = Math.max(0, selected - 1);
            ensureVisible();
        } else if (key == Keyboard.KEY_DOWN && !saves.isEmpty()) {
            selected = Math.min(saves.size() - 1, selected + 1);
            ensureVisible();
        }
    }

    private void ensureVisible() {
        float top = selected * rowH(), bottom = top + rowH(), view = listBottom() - listTop();
        if (top < scrollTarget) scrollTarget = top;
        else if (bottom > scrollTarget + view) scrollTarget = bottom - view;
    }

    private void runAction(int action) {
        switch (action) {
            case A_PLAY:
                playSelected();
                break;
            case A_CREATE:
                mc.displayGuiScreen(new GuiCreateWorld(this));
                break;
            case A_EDIT:
                mc.displayGuiScreen(new GuiRenameWorld(this, saves.get(selected).getFileName()));
                break;
            case A_DELETE: {
                String name = saves.get(selected).getDisplayName();
                mc.displayGuiScreen(new GuiYesNo(this, I18n.format("selectWorld.deleteQuestion"),
                        "'" + name + "' " + I18n.format("selectWorld.deleteWarning"),
                        I18n.format("selectWorld.deleteButton"), I18n.format("gui.cancel"), selected));
                break;
            }
            default:
                mc.displayGuiScreen(parent);
                break;
        }
    }

    private void playSelected() {
        if (loadingWorld || selected < 0 || selected >= saves.size()) return;
        SaveFormatComparator s = saves.get(selected);
        String folder = s.getFileName();
        String name = s.getDisplayName();
        if (name == null || name.length() == 0) name = "World" + selected;
        loadingWorld = true;
        mc.displayGuiScreen(null);
        if (mc.getSaveLoader().canLoadWorld(folder)) {
            mc.launchIntegratedServer(folder, name, null);
        }
    }

    /** Result of the delete confirmation. */
    @Override
    public void confirmClicked(boolean result, int id) {
        if (result && id >= 0 && id < saves.size()) {
            ISaveFormat fmt = mc.getSaveLoader();
            fmt.flushCache();
            fmt.deleteWorldDirectory(saves.get(id).getFileName());
        }
        mc.displayGuiScreen(this); // initGui() reloads the list
    }
}
