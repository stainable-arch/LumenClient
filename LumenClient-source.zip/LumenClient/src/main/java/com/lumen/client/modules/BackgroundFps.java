package com.lumen.client.modules;

import com.lumen.client.ClientSettings;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.Display;

/** Backs Settings > Performance > Background FPS Limit: caps the frame rate while the window is not focused. */
public final class BackgroundFps {
    public static final BackgroundFps INSTANCE = new BackgroundFps();

    private BackgroundFps() {}

    @SubscribeEvent
    public void onRender(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.END && ClientSettings.backgroundFps.value && !Display.isActive()) {
            Display.sync(ClientSettings.backgroundFpsValue.getInt());
        }
    }
}
