package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.LumenUsers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Takes over the name tags of players: the dark background plate can be removed, and the small
 * themed "Lumen" badge (shown next to the name of Lumen Client users) lives here too.
 * "Render Self" also draws your own tag in third person.
 */
public class Nametags extends Module {
    private final BooleanSetting removeBackground = add(new BooleanSetting("Remove Background", true));
    private final BooleanSetting indicator = add(new BooleanSetting("Lumen Indicator", true));
    private final BooleanSetting renderSelf = add(new BooleanSetting("Render Self", true));
    private final NumberSetting indicatorScale = add(new NumberSetting("Indicator Scale", 1.0, 0.6, 2.0, 0.1));

    private static final String LABEL = "Lumen";
    private static final float SCALE = 0.016666668f * 1.6f;

    public Nametags() {
        super("Nametags", "Removes the name tag backgrounds and shows a badge on Lumen Client users.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onSpecialsPre(RenderLivingEvent.Specials.Pre e) {
        EntityLivingBase ent = e.entity;
        if (!(ent instanceof EntityPlayer) || mc.thePlayer == null) return;
        EntityPlayer p = (EntityPlayer) ent;
        if (!shouldRender(p)) {
            if (p == mc.thePlayer) e.setCanceled(true);
            return;
        }
        e.setCanceled(true); // replace the vanilla tag with ours
        double d0 = p.getDistanceSqToEntity(mc.thePlayer);
        float range = p.isSneaking() ? 32f : 64f;
        if (d0 >= range * range) return;

        FontRenderer fr = mc.fontRendererObj;
        double y = e.y;
        if (!p.isSneaking() && d0 < 100.0) {
            Scoreboard sb = p.getWorldScoreboard();
            ScoreObjective obj = sb.getObjectiveInDisplaySlot(2);
            if (obj != null) {
                Score score = sb.getValueFromObjective(p.getName(), obj);
                drawLabel(p, score.getScorePoints() + " " + obj.getDisplayName(), e.x, y, e.z, false);
                y += fr.FONT_HEIGHT * 1.15f * SCALE;
            }
        }
        drawLabel(p, p.getDisplayName().getFormattedText(), e.x, y, e.z, true);
    }

    /** Mirrors vanilla's canRenderName for players. */
    private boolean shouldRender(EntityPlayer p) {
        if (!Minecraft.isGuiEnabled()) return false;
        if (p == mc.thePlayer) {
            return renderSelf.value && mc.gameSettings.thirdPersonView != 0 && p.riddenByEntity == null;
        }
        Team team = p.getTeam();
        Team mine = mc.thePlayer.getTeam();
        if (team != null) {
            switch (team.getNameTagVisibility()) {
                case ALWAYS:
                    return true;
                case NEVER:
                    return false;
                case HIDE_FOR_OTHER_TEAMS:
                    return mine == null || team.isSameTeam(mine);
                case HIDE_FOR_OWN_TEAM:
                    return mine == null || !team.isSameTeam(mine);
                default:
                    return true;
            }
        }
        return !p.isInvisibleToPlayer(mc.thePlayer) && p.riddenByEntity == null;
    }

    private void drawLabel(EntityPlayer p, String text, double x, double y, double z, boolean nameLine) {
        FontRenderer fr = mc.fontRendererObj;
        RenderManager rm = mc.getRenderManager();
        boolean sneak = p.isSneaking();
        int w = fr.getStringWidth(text);
        boolean badge = nameLine && indicator.value && LumenUsers.isLumenUser(p.getUniqueID());

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y + p.height + 0.5f, (float) z);
        GL11.glNormal3f(0f, 1f, 0f);
        GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
        GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
        GlStateManager.scale(-SCALE, -SCALE, SCALE);
        if (sneak) GlStateManager.translate(0f, 9.374999f, 0f);
        GlStateManager.disableLighting();
        GlStateManager.depthMask(false);
        if (!sneak) GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (!removeBackground.value) {
            GlStateManager.disableTexture2D();
            Tessellator t = Tessellator.getInstance();
            WorldRenderer wr = t.getWorldRenderer();
            int hw = w / 2;
            wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
            wr.pos(-hw - 1, -1, 0).color(0f, 0f, 0f, 0.25f).endVertex();
            wr.pos(-hw - 1, 8, 0).color(0f, 0f, 0f, 0.25f).endVertex();
            wr.pos(hw + 1, 8, 0).color(0f, 0f, 0f, 0.25f).endVertex();
            wr.pos(hw + 1, -1, 0).color(0f, 0f, 0f, 0.25f).endVertex();
            t.draw();
            GlStateManager.enableTexture2D();
        }

        fr.drawString(text, -w / 2, 0, 553648127); // see-through-walls pass
        if (!sneak) {
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            fr.drawString(text, -w / 2, 0, -1);
            GlStateManager.disableDepth();
            GlStateManager.depthMask(false);
        }
        if (badge) drawBadge(fr, w);

        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    /** The themed plate, to the left of the name; it scales around its own centre. */
    private void drawBadge(FontRenderer fr, int nameW) {
        float sc = indicatorScale.getFloat();
        int badgeW = fr.getStringWidth(LABEL) + 6;
        int c1 = 0xFF000000 | Theme.current().c1;
        int c3 = 0xFF000000 | Theme.current().c3;
        float bx = -nameW / 2f - 3 - badgeW;

        GlStateManager.pushMatrix();
        GlStateManager.translate(bx + badgeW / 2f, 4f, 0f);
        GlStateManager.scale(sc, sc, 1f);
        GlStateManager.translate(-badgeW / 2f, -4f, 0f);

        GlStateManager.disableTexture2D();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(0, -1, 0).color(r(c1), g(c1), b(c1), 220).endVertex();
        wr.pos(0, 9, 0).color(r(c1), g(c1), b(c1), 220).endVertex();
        wr.pos(badgeW, 9, 0).color(r(c3), g(c3), b(c3), 220).endVertex();
        wr.pos(badgeW, -1, 0).color(r(c3), g(c3), b(c3), 220).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableTexture2D();
        fr.drawString(LABEL, 3, 0, 0xFF0B1020);
        GlStateManager.popMatrix();
    }

    private static int r(int c) { return (c >> 16) & 255; }
    private static int g(int c) { return (c >> 8) & 255; }
    private static int b(int c) { return c & 255; }
}
