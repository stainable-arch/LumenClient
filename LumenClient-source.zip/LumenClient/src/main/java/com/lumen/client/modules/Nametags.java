package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.LumenFont;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import com.lumen.client.util.LumenUsers;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Takes over the name tags of players: the dark background plate can be removed, and the small
 * themed "Lumen" badge (shown next to the name of Lumen Client users) lives here too.
 * "Render Self" also draws your own tag in third person.
 */
public class Nametags extends Module {
    private final BooleanSetting removeBackground = add(new BooleanSetting("Remove Background", true));
    private final BooleanSetting indicator = add(new BooleanSetting("Lumen Indicator", true));
    private final BooleanSetting renderSelf = add(new BooleanSetting("Render Self", true));
    private final NumberSetting indicatorScale = add(new NumberSetting("Indicator Scale", 1.0, 0.6, 2.0, 0.1));

    private static final String LABEL = "LUMEN";
    private static final float SCALE = 0.016666668f * 1.6f;

    public Nametags() {
        super("Nametags", "Removes the name tag backgrounds and shows a badge on Lumen Client users.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onSpecialsPre(RenderLivingEvent.Specials.Pre e) {
        EntityLivingBase ent = e.entity;
        if (!(ent instanceof EntityPlayer) || mc.thePlayer == null) return;
        EntityPlayer p = (EntityPlayer) ent;
        if (p == mc.thePlayer) {
            // Vanilla never asks for your own tag, so it is drawn from onSelfPost instead.
            e.setCanceled(true);
            return;
        }
        if (broken || !shouldRender(p)) return;
        e.setCanceled(true); // replace the vanilla tag with ours
        renderTag(p, e.x, e.y, e.z);
    }

    /** Your own tag: vanilla skips it, so it is drawn right after your model in third person. */
    @SubscribeEvent
    public void onSelfPost(RenderPlayerEvent.Post e) {
        if (mc.thePlayer == null || e.entityPlayer != mc.thePlayer) return;
        if (mc.currentScreen != null) return; // not in the inventory preview etc.
        if (!shouldRender(mc.thePlayer)) return;
        renderTag(mc.thePlayer, e.x, e.y, e.z);
    }

    /** Set when drawing a tag threw: tags are switched off for the rest of the session instead of crashing the game. */
    private static boolean broken;

    private void renderTag(EntityPlayer p, double ex, double ey, double ez) {
        if (broken) return;
        try {
            renderTagUnsafe(p, ex, ey, ez);
        } catch (Throwable t) {
            broken = true;
            t.printStackTrace();
        }
    }

    private void renderTagUnsafe(EntityPlayer p, double ex, double ey, double ez) {
        double d0 = p.getDistanceSqToEntity(mc.thePlayer);
        float range = p.isSneaking() ? 32f : 64f;
        if (d0 >= range * range) return;

        FontRenderer fr = mc.fontRendererObj;
        double y = ey;
        if (!p.isSneaking() && d0 < 100.0) {
            Scoreboard sb = p.getWorldScoreboard();
            ScoreObjective obj = sb.getObjectiveInDisplaySlot(2);
            if (obj != null) {
                Score score = sb.getValueFromObjective(p.getName(), obj);
                drawLabel(p, score.getScorePoints() + " " + obj.getDisplayName(), ex, y, ez, false);
                y += fr.FONT_HEIGHT * 1.15f * SCALE;
            }
        }
        drawLabel(p, p.getDisplayName().getFormattedText(), ex, y, ez, true);
    }

    /** Mirrors vanilla's canRenderName for players. */
    private boolean shouldRender(EntityPlayer p) {
        if (!Minecraft.isGuiEnabled()) return false;
        if (p == mc.thePlayer) {
            return renderSelf.value && mc.gameSettings.thirdPersonView != 0 && p.riddenByEntity == null;
        }
        Team team = p.getTeam();
        Team mine = mc.thePlayer.getTeam();
        if (team != null) {
            switch (team.getNameTagVisibility()) {
                case ALWAYS:
                    return true;
                case NEVER:
                    return false;
                case HIDE_FOR_OTHER_TEAMS:
                    return mine == null || team.isSameTeam(mine);
                case HIDE_FOR_OWN_TEAM:
                    return mine == null || !team.isSameTeam(mine);
                default:
                    return true;
            }
        }
        return !p.isInvisibleToPlayer(mc.thePlayer) && p.riddenByEntity == null;
    }

    private static final java.nio.FloatBuffer MATRIX = org.lwjgl.BufferUtils.createFloatBuffer(16);

    /**
     * Turns the tag to face the camera whatever the camera is doing (normal view, third person, front
     * view or Freelook): the rotation part of the current modelview matrix is cancelled, keeping only
     * the position, so the tag is always flat on the screen.
     */
    private static void faceCamera() {
        MATRIX.clear();
        GL11.glGetFloat(GL11.GL_MODELVIEW_MATRIX, MATRIX);
        MATRIX.put(0, 1f).put(1, 0f).put(2, 0f);
        MATRIX.put(4, 0f).put(5, 1f).put(6, 0f);
        MATRIX.put(8, 0f).put(9, 0f).put(10, 1f);
        MATRIX.position(0);
        GL11.glLoadMatrix(MATRIX);
    }

    private void drawLabel(EntityPlayer p, String text, double x, double y, double z, boolean nameLine) {
        FontRenderer fr = mc.fontRendererObj;
        boolean sneak = p.isSneaking();
        int w = fr.getStringWidth(text);
        boolean badge = nameLine && indicator.value && LumenUsers.isLumenUser(p.getUniqueID());

        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate((float) x, (float) y + p.height + 0.5f, (float) z);
            GL11.glNormal3f(0f, 1f, 0f);
            faceCamera();
            GlStateManager.scale(SCALE, -SCALE, -SCALE);
            if (sneak) GlStateManager.translate(0f, 9.374999f, 0f);
            GlStateManager.disableLighting();
            GlStateManager.depthMask(false);
            if (!sneak) GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

            if (!removeBackground.value) {
                GlStateManager.disableTexture2D();
                Tessellator t = Tessellator.getInstance();
                WorldRenderer wr = t.getWorldRenderer();
                int hw = w / 2;
                wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
                wr.pos(-hw - 1, -1, 0).color(0f, 0f, 0f, 0.25f).endVertex();
                wr.pos(-hw - 1, 8, 0).color(0f, 0f, 0f, 0.25f).endVertex();
                wr.pos(hw + 1, 8, 0).color(0f, 0f, 0f, 0.25f).endVertex();
                wr.pos(hw + 1, -1, 0).color(0f, 0f, 0f, 0.25f).endVertex();
                t.draw();
                GlStateManager.enableTexture2D();
            }

            fr.drawString(text, -w / 2, 0, 553648127); // see-through-walls pass
            if (!sneak) {
                GlStateManager.enableDepth();
                GlStateManager.depthMask(true);
                fr.drawString(text, -w / 2, 0, -1);
                GlStateManager.disableDepth();
                GlStateManager.depthMask(false);
            }
            if (badge) drawBadge(fr, w);

            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1f, 1f, 1f, 1f);
        } finally {
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1f, 1f, 1f, 1f);
            GlStateManager.popMatrix();
        }
    }

    /** Modern pill to the left of the name (Winkle font), sized tightly around the text. */
    private void drawBadge(FontRenderer fr, int nameW) {
        float sc = indicatorScale.getFloat();
        Theme th = Theme.current();
        int c1 = 0xFF000000 | th.c1;
        int c2 = 0xFF000000 | th.c2;
        int c3 = 0xFF000000 | th.c3;
        String label = LABEL;

        // Measured from the Winkle atlas for "LUMEN" at scale 1: the glyph ink spans x -0.71..24.91 and
        // y 0.28..8.31 (caps), so the pill is sized and the text offset from the real ink, not the advance width
        float inkL = -0.71f, inkR = 24.91f;
        float textW = inkR - inkL;
        float inkTop = 0.28f, inkBottom = 8.31f;
        float cy = (inkTop + inkBottom) / 2f;
        float padL = 2.8f, dot = 1.4f, gap = 2.2f, padR = 4.6f, padV = 1.3f;
        float badgeW = padL + dot * 2 + gap + textW + padR;
        float top = inkTop - padV, bottom = inkBottom + padV;
        float radius = (bottom - top) / 2f;
        float bx = -nameW / 2f - 3f - badgeW;

        GlStateManager.pushMatrix();
        GlStateManager.translate(bx + badgeW / 2f, cy, 0f);
        GlStateManager.scale(sc, sc, 1f);
        GlStateManager.translate(-badgeW / 2f, -cy, 0f);

        // soft outer glow, dark glass body, theme tint, gradient rim
        RenderUtil.glow(badgeW / 2f, cy, badgeW * 0.62f, Colors.withAlpha(c2, 34));
        RenderUtil.roundedRect(0f, top, badgeW, bottom, radius, 0xC00A0F1C);
        RenderUtil.roundedRectH(0f, top, badgeW, bottom, radius, Colors.withAlpha(c1, 70), Colors.withAlpha(c3, 70));
        RenderUtil.roundedOutline(0f, top, badgeW, bottom, radius, 0.7f, Colors.withAlpha(c1, 235), Colors.withAlpha(c3, 235));

        // glowing status dot
        float dx = padL + dot, dy = cy;
        RenderUtil.glow(dx, dy, 4f, Colors.withAlpha(c1, 150));
        RenderUtil.circle(dx, dy, dot, 0xFFFFFFFF);
        RenderUtil.circle(dx, dy, dot * 0.62f, c1);

        // label, tinted towards white so it stays readable on every theme
        LumenFont.draw(label, padL + dot * 2 + gap - inkL, 0f, Colors.lerp(c1, 0xFFFFFFFF, 0.65f), false);
        GlStateManager.popMatrix();
    }
}
