package com.lumen.client.cosmetics;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Cosmetic pet: a little Tung Tung Tung Sahur (wooden log with a face, thin limbs and a baseball bat) that follows
 * the player and walks beside them. Purely client-side and not a real entity: it is simulated every tick and drawn
 * in RenderWorldLastEvent with a small hand-built model (assets/lumen/textures/sahur.png, baked by
 * tools/gen_sahur.py). Forge events only, no mixins.
 */
public final class SahurPet {
    private static final ResourceLocation TEX = new ResourceLocation("lumen", "textures/sahur.png");
    /** The model is 1.5 blocks tall; the pet is drawn a bit smaller than the player. */
    private static final float SCALE = 0.7f;

    private final Minecraft mc = Minecraft.getMinecraft();
    private final Model model = new Model();

    private boolean init;
    private World lastWorld;
    private double x, y, z, prevX, prevY, prevZ;
    private float yaw, prevYaw, swing, prevSwing, amount, prevAmount;
    private int ticks;

    private static boolean enabled() {
        return ClientSettings.cosmetics && ClientSettings.sahurPet.value;
    }

    // ------------------------------------------------------------------------------------------
    // simulation
    // ------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        EntityPlayerSP p = mc.thePlayer;
        if (p == null || mc.theWorld == null || !enabled()) {
            init = false;
            return;
        }

        // spot beside the player: 1.3 blocks to their right, a little behind
        double rad = Math.toRadians(p.renderYawOffset);
        double fx = -Math.sin(rad), fz = Math.cos(rad);   // forward
        double rx = -Math.cos(rad), rz = -Math.sin(rad);  // right
        double ax = p.posX + rx * 1.3 - fx * 0.3;
        double az = p.posZ + rz * 1.3 - fz * 0.3;

        double far = Math.sqrt((p.posX - x) * (p.posX - x) + (p.posZ - z) * (p.posZ - z));
        if (!init || mc.theWorld != lastWorld || far > 16.0 || Math.abs(p.posY - y) > 8.0) {
            init = true;
            lastWorld = mc.theWorld;
            x = prevX = ax;
            y = prevY = p.posY;
            z = prevZ = az;
            yaw = prevYaw = p.renderYawOffset;
            swing = prevSwing = 0f;
            amount = prevAmount = 0f;
        }

        prevX = x;
        prevY = y;
        prevZ = z;
        double dx = ax - x, dz = az - z;
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d > 0.5) {
            double sp = Math.min(0.5, (d - 0.3) * 0.3);
            x += dx / d * sp;
            z += dz / d * sp;
        }
        y += (p.posY - y) * 0.35;

        // face where it walks; when standing still, face where the player faces
        double moved = Math.sqrt((x - prevX) * (x - prevX) + (z - prevZ) * (z - prevZ));
        float target = moved > 0.02 ? (float) Math.toDegrees(Math.atan2(-(x - prevX), z - prevZ)) : p.renderYawOffset;
        prevYaw = yaw;
        yaw += MathHelper.wrapAngleTo180_float(target - yaw) * 0.3f;

        prevSwing = swing;
        prevAmount = amount;
        amount += (Math.min((float) moved * 4f, 1f) - amount) * 0.4f;
        swing += amount;
        ticks++;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent e) {
        if (!init || !enabled()) return;
        Entity view = mc.getRenderViewEntity();
        if (view == null || mc.theWorld == null) return;
        float pt = e.partialTicks;
        double cx = view.lastTickPosX + (view.posX - view.lastTickPosX) * pt;
        double cy = view.lastTickPosY + (view.posY - view.lastTickPosY) * pt;
        double cz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * pt;
        double px = prevX + (x - prevX) * pt, py = prevY + (y - prevY) * pt, pz = prevZ + (z - prevZ) * pt;
        float yw = prevYaw + (yaw - prevYaw) * pt;
        float sw = prevSwing + (swing - prevSwing) * pt;
        float am = prevAmount + (amount - prevAmount) * pt;

        int light = mc.theWorld.getCombinedLight(new BlockPos(px, py + 0.5, pz), 0);

        GlStateManager.pushMatrix();
        RenderHelper.enableStandardItemLighting();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.depthMask(true);
        GlStateManager.disableCull();
        GlStateManager.enableRescaleNormal();
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (light & 65535), (float) (light >> 16));
        GlStateManager.color(1f, 1f, 1f, 1f);

        GlStateManager.translate(px - cx, py - cy, pz - cz);
        GlStateManager.rotate(180f - yw, 0f, 1f, 0f);
        GlStateManager.scale(SCALE, SCALE, SCALE);
        GlStateManager.scale(-1f, -1f, 1f);          // model space is y-down, like vanilla entity models
        GlStateManager.translate(0f, -1.5078125f, 0f);
        mc.getTextureManager().bindTexture(TEX);
        model.draw(sw, am, ticks + pt, 0.0625f);

        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Log body, two stick legs, two stick arms and a bat in the right hand. Feet are at y = 24 (model units). */
    private static final class Model extends ModelBase {
        private final ModelRenderer body, armL, armR, legL, legR, bat;

        Model() {
            textureWidth = 64;
            textureHeight = 64;
            body = new ModelRenderer(this, 0, 0);
            body.addBox(-4f, 0f, -3f, 8, 16, 6);
            body.setRotationPoint(0f, 0f, 0f);
            armL = new ModelRenderer(this, 32, 0);
            armL.addBox(-1f, -1f, -1f, 2, 10, 2);
            armL.setRotationPoint(5f, 3f, 0f);
            armR = new ModelRenderer(this, 32, 0);
            armR.addBox(-1f, -1f, -1f, 2, 10, 2);
            armR.setRotationPoint(-5f, 3f, 0f);
            legL = new ModelRenderer(this, 44, 0);
            legL.addBox(-1f, 0f, -1f, 2, 8, 2);
            legL.setRotationPoint(2f, 16f, 0f);
            legR = new ModelRenderer(this, 44, 0);
            legR.addBox(-1f, 0f, -1f, 2, 8, 2);
            legR.setRotationPoint(-2f, 16f, 0f);
            bat = new ModelRenderer(this, 0, 24);
            bat.addBox(-1.5f, -2f, -1.5f, 3, 16, 3);
            bat.setRotationPoint(0f, 8f, 0f);        // at the end of the arm, i.e. in the hand
            bat.rotateAngleX = -2.1f;                // points up, a bit forward
            armR.addChild(bat);
        }

        void draw(float limbSwing, float limbAmount, float age, float scale) {
            float a = (float) Math.cos(limbSwing * 0.6662f) * 1.4f * limbAmount;
            legL.rotateAngleX = a;
            legR.rotateAngleX = -a;
            armL.rotateAngleX = -a * 0.7f;
            armL.rotateAngleZ = -0.06f;
            // the bat arm is held up and taps along: "tung tung tung"
            armR.rotateAngleX = -0.9f - a * 0.2f + (float) Math.sin(age * 0.45f) * 0.14f;
            armR.rotateAngleZ = 0.06f;
            body.render(scale);
            armL.render(scale);
            armR.render(scale);
            legL.render(scale);
            legR.render(scale);
        }
    }
}
