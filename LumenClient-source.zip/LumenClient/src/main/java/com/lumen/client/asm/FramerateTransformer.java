package com.lumen.client.asm;

import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Removes the vanilla 30 FPS cap while no world is loaded (main menu etc.).
 *
 * Vanilla: return theWorld == null && currentScreen != null ? 30 : gameSettings.limitFramerate;
 * Patch:   the constant 30 is replaced by "this.gameSettings.limitFramerate" (copied from the
 *          else-branch), so the user's own FPS limit always applies. Stack effect and control
 *          flow are unchanged, so no frame recomputation is needed.
 */
public class FramerateTransformer implements IClassTransformer {
    @Override
    public byte[] transform(String name, String transformedName, byte[] bytes) {
        if (bytes == null || !"net.minecraft.client.Minecraft".equals(transformedName)) return bytes;
        try {
            ClassNode cn = new ClassNode();
            new ClassReader(bytes).accept(cn, 0);
            boolean patched = false;
            for (MethodNode mn : cn.methods) {
                if (!"()I".equals(mn.desc)) continue;
                boolean named = "func_90020_K".equals(mn.name) || "getLimitFramerate".equals(mn.name);
                if (patch(mn, named)) { patched = true; break; }
            }
            if (!patched) {
                System.err.println("[LumenCore] getLimitFramerate not found; menu FPS cap left untouched");
                return bytes;
            }
            ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            cn.accept(cw);
            System.out.println("[LumenCore] Menu 30 FPS limit removed");
            return cw.toByteArray();
        } catch (Throwable t) {
            t.printStackTrace();
            return bytes;
        }
    }

    private static boolean patch(MethodNode mn, boolean named) {
        InsnList insns = mn.instructions;
        AbstractInsnNode bipush30 = null;
        for (AbstractInsnNode i = insns.getFirst(); i != null; i = i.getNext()) {
            if (i.getOpcode() == Opcodes.BIPUSH && ((IntInsnNode) i).operand == 30) { bipush30 = i; break; }
        }
        if (bipush30 == null) return false;

        // Locate "aload_0; getfield gameSettings; getfield limitFramerate; ireturn"
        AbstractInsnNode ret = null;
        for (AbstractInsnNode i = insns.getLast(); i != null; i = i.getPrevious()) {
            if (i.getOpcode() == Opcodes.IRETURN) { ret = i; break; }
        }
        if (ret == null) return false;
        AbstractInsnNode f2 = prev(ret), f1 = prev(f2), a0 = prev(f1);
        if (a0 == null || a0.getOpcode() != Opcodes.ALOAD || ((VarInsnNode) a0).var != 0
                || f1.getOpcode() != Opcodes.GETFIELD || f2.getOpcode() != Opcodes.GETFIELD) return false;
        FieldInsnNode g1 = (FieldInsnNode) f1, g2 = (FieldInsnNode) f2;
        if (!"I".equals(g2.desc)) return false;
        if (!named && !(g2.name.equals("field_74350_i") || g2.name.equals("limitFramerate"))) return false;

        insns.insertBefore(bipush30, new VarInsnNode(Opcodes.ALOAD, 0));
        insns.insertBefore(bipush30, new FieldInsnNode(Opcodes.GETFIELD, g1.owner, g1.name, g1.desc));
        insns.insertBefore(bipush30, new FieldInsnNode(Opcodes.GETFIELD, g2.owner, g2.name, g2.desc));
        insns.remove(bipush30);
        return true;
    }

    private static AbstractInsnNode prev(AbstractInsnNode n) {
        AbstractInsnNode p = n == null ? null : n.getPrevious();
        while (p != null && p.getOpcode() < 0) p = p.getPrevious(); // skip labels/lines/frames
        return p;
    }
}
