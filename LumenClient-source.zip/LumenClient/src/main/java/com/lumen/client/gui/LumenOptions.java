package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLockIconButton;
import net.minecraft.client.gui.GuiOptionSlider;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.input.Keyboard;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * The vanilla options screen in the look of {@link LumenMainMenu}. It extends {@link GuiOptions}
 * and keeps its real buttons (read for their labels, "clicked" through actionPerformed), so every
 * entry behaves exactly like vanilla: difficulty, lock, video / controls / language / chat /
 * resource packs / snooper / skin settings and so on. Only the drawing and the FOV slider are new.
 * The sub-screens it opens (video settings, controls ...) are still the vanilla ones.
 */
public class LumenOptions extends GuiOptions {
    private final List<GuiButton> entries = new ArrayList<GuiButton>();
    private GuiButton done;
    private float[] hover = new float[0];
    private float doneHover, fovHover;
    private boolean draggingFov;

    private long start = System.currentTimeMillis();
    private long last = start;
    private float fade;
    private float parX, parY;

    public LumenOptions(GuiScreen parent, GameSettings settings) {
        super(parent, settings);
    }

    @Override
    public void initGui() {
        super.initGui(); // builds the vanilla buttons
        entries.clear();
        done = null;
        List<GuiButton> sorted = new ArrayList<GuiButton>(buttonList);
        Collections.sort(sorted, new Comparator<GuiButton>() {
            @Override
            public int compare(GuiButton a, GuiButton b) {
                if (a.yPosition != b.yPosition) return a.yPosition < b.yPosition ? -1 : 1;
                return a.xPosition < b.xPosition ? -1 : (a.xPosition == b.xPosition ? 0 : 1);
            }
        });
        for (GuiButton b : sorted) {
            if (b.id == 200) done = b;
            else if (!(b instanceof GuiOptionSlider)) entries.add(b); // the FOV slider is drawn separately
        }
        hover = new float[entries.size()];
    }

    // ------------------------------------------------------------------------------------------
    // layout
    // ------------------------------------------------------------------------------------------

    private float k() {
        return height / 254f;
    }

    private float sliderCy() {
        return height * 0.285f;
    }

    private float sliderW() {
        return Math.min(width * 0.6f, 150f * k());
    }

    private float entryTop() {
        return height * 0.375f;
    }

    private float entryStep() {
        float span = height * 0.50f;
        return Math.min(height * 0.056f, span / Math.max(1, entries.size()));
    }

    private float entryY(int i) {
        return entryTop() + i * entryStep();
    }

    private float doneY() {
        return height * 0.92f;
    }

    private String label(GuiButton b) {
        if (b instanceof GuiLockIconButton) return b.enabled ? "Lock Difficulty" : "Difficulty Locked";
        String s = b.displayString == null ? "" : b.displayString;
        return s.replace("...", "").trim();
    }

    private boolean overEntry(int i, int mx, int my) {
        String s = label(entries.get(i));
        float w = LumenFont.width(s) * 1.0f * k();
        float pad = 12f * k();
        float half = Math.max(5f * k(), entryStep() / 2f);
        return mx >= (width - w) / 2f - pad && mx <= (width + w) / 2f + pad
                && my >= entryY(i) - half && my <= entryY(i) + half;
    }

    private boolean overDone(int mx, int my) {
        float w = LumenFont.width("Done") * 1.1f * k();
        float pad = 14f * k();
        return mx >= (width - w) / 2f - pad && mx <= (width + w) / 2f + pad
                && my >= doneY() - 9f * k() && my <= doneY() + 9f * k();
    }

    private boolean overSlider(int mx, int my) {
        float w = sliderW(), cy = sliderCy();
        return mx >= (width - w) / 2f - 8f * k() && mx <= (width + w) / 2f + 8f * k()
                && my >= cy - 6f * k() && my <= cy + 16f * k();
    }

    private void setFovFromMouse(int mx) {
        float w = sliderW();
        float f = Math.max(0f, Math.min(1f, (mx - (width - w) / 2f) / w));
        mc.gameSettings.fovSetting = 30f + Math.round(f * 80f);
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (float) Math.pow(1f - x, 3);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now - start) / 1000f;
        fade = Math.min(1f, fade + dt * 2.2f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        float pk = Math.min(1f, dt * 3f);
        parX += (((float) mouseX / Math.max(1, width) - 0.5f) * 2f - parX) * pk;
        parY += (((float) mouseY / Math.max(1, height) - 0.5f) * 2f - parY) * pk;
        float pox = -parX * width * 0.03f, poy = -parY * height * 0.03f;

        boolean inWorld = mc.theWorld != null;
        Theme th = Theme.current();
        int tint = Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
        float k = k();

        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // title-screen background; over a running world it stays see-through
        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, !inWorld, pox, poy);
        } else {
            float a = inWorld ? 0.78f : 1f;
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.mulAlpha(Colors.lerp(0xFF000000, tint, 0.05f), a),
                    Colors.mulAlpha(Colors.lerp(0xFF000000, tint, 0.11f), a));
        }
        GlStateManager.pushMatrix();
        GlStateManager.translate(pox * 0.5f, poy * 0.5f, 0f);
        Stripes.draw(width, height, t, e);
        GlStateManager.popMatrix();
        if (!th.glass) GlassFx.ambient(width, height, e, now, pox, poy);

        // ---- title ----
        float tScale = 1.5f * k;
        String first = "\u00a7oMinecraft";
        String rest = " Settings";
        float tw = (LumenFont.width(first) + LumenFont.width(rest)) * tScale;
        float tx = (width - tw) / 2f;
        float te = ease((t - 0.05f) / 0.6f);
        float ty = height * 0.12f + (1f - te) * 10f * k;
        RenderUtil.glow(width / 2f, ty + LumenFont.EM * tScale / 2f, tw * 0.75f,
                Colors.withAlpha(th.c1, (int) ((24f + 10f * (float) Math.sin(t * 1.6f)) * te)));
        if (th.glass) {
            GlassFx.pane(tx - 14f * k, ty - 6f * k, tx + tw + 14f * k, ty + LumenFont.EM * tScale + 5f * k, 9f * k, te, 0f);
        }
        text(first, tx, ty, tScale, Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f), te));
        text(rest, tx + LumenFont.width(first) * tScale, ty, tScale, Colors.mulAlpha(0xFFFFFFFF, te));

        // ---- FOV slider ----
        float se = ease((t - 0.2f) / 0.55f);
        boolean sh = draggingFov || overSlider(mouseX, mouseY);
        fovHover += ((sh ? 1f : 0f) - fovHover) * Math.min(1f, dt * 14f);
        float fov = mc.gameSettings.fovSetting;
        String fl = "FOV  " + Math.round(fov);
        float fs = 1.0f * k;
        float sw = sliderW();
        float sx = (width - sw) / 2f;
        float cy = sliderCy() + (1f - se) * 8f * k;
        text(fl, (width - LumenFont.width(fl) * fs) / 2f, cy - 6f * k, fs,
                Colors.mulAlpha(Colors.lerp(0xFFC4C8D2, 0xFFFFFFFF, fovHover), se));
        float ty2 = cy + 9f * k, th2 = Math.max(2f, 2.4f * k);
        float frac = (fov - 30f) / 80f;
        RenderUtil.roundedRect(sx, ty2, sx + sw, ty2 + th2, th2 / 2f, Colors.mulAlpha(0x33FFFFFF, se));
        RenderUtil.roundedRectH(sx, ty2, sx + Math.max(th2, sw * frac), ty2 + th2, th2 / 2f,
                Colors.mulAlpha(Colors.opaque(th.c1), se), Colors.mulAlpha(Colors.opaque(th.c3), se));
        RenderUtil.circle(sx + sw * frac, ty2 + th2 / 2f, (3.2f + 0.8f * fovHover) * k, Colors.mulAlpha(0xFFFFFFFF, se));

        // ---- entries (text only) ----
        float iScale = 1.0f * k;
        for (int i = 0; i < entries.size(); i++) {
            GuiButton b = entries.get(i);
            String s = label(b);
            float ie = ease((t - 0.3f - i * 0.05f) / 0.5f);
            boolean hov = b.enabled && overEntry(i, mouseX, mouseY);
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * Math.min(1f, dt * 14f);
            float h = hover[i];
            int dim = b.enabled ? 0xFFC4C8D2 : 0xFF4A4E5A;
            int col = Colors.lerp(dim, 0xFFFFFFFF, h);
            float sc = iScale * (1f + 0.05f * h);
            float w = LumenFont.width(s) * sc;
            float cyy = entryY(i) + (1f - ie) * 8f * k;
            text(s, (width - w) / 2f, cyy - LumenFont.EM * sc / 2f, sc, Colors.mulAlpha(col, ie));
            if (h > 0.02f && !th.glass) {
                float lw = w * h;
                float ly = cyy + LumenFont.EM * sc / 2f + 2f * k;
                RenderUtil.gradientH((width - lw) / 2f, ly, (width + lw) / 2f, ly + Math.max(1f, k * 0.9f),
                        Colors.mulAlpha(Colors.opaque(th.c1), ie), Colors.mulAlpha(Colors.opaque(th.c3), ie));
            }
        }

        // ---- Done ----
        float de = ease((t - 0.55f) / 0.5f);
        boolean dh = overDone(mouseX, mouseY);
        doneHover += ((dh ? 1f : 0f) - doneHover) * Math.min(1f, dt * 14f);
        float dsc = 1.1f * k * (1f + 0.05f * doneHover);
        float dw = LumenFont.width("Done") * dsc;
        float dcy = doneY() + (1f - de) * 8f * k;
        text("Done", (width - dw) / 2f, dcy - LumenFont.EM * dsc / 2f, dsc, Colors.mulAlpha(0xFFFFFFFF, de));
        if (doneHover > 0.02f && !th.glass) {
            float lw = dw * doneHover;
            float ly = dcy + LumenFont.EM * dsc / 2f + 2f * k;
            RenderUtil.gradientH((width - lw) / 2f, ly, (width + lw) / 2f, ly + Math.max(1f, k * 0.9f),
                    Colors.mulAlpha(Colors.opaque(th.c1), de), Colors.mulAlpha(Colors.opaque(th.c3), de));
        }

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        if (overSlider(mouseX, mouseY)) {
            draggingFov = true;
            setFovFromMouse(mouseX);
            Sounds.click();
            return;
        }
        if (done != null && overDone(mouseX, mouseY)) {
            Sounds.click();
            actionPerformed(done);
            return;
        }
        for (int i = 0; i < entries.size(); i++) {
            GuiButton b = entries.get(i);
            if (b.enabled && overEntry(i, mouseX, mouseY)) {
                Sounds.click();
                actionPerformed(b); // exactly what the vanilla button does
                return;
            }
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
        if (draggingFov) setFovFromMouse(mouseX);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        if (draggingFov) {
            draggingFov = false;
            mc.gameSettings.saveOptions();
        }
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE && done != null) {
            actionPerformed(done);
        }
    }
}
