package com.lumen.client;

import com.lumen.client.core.ConfigManager;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.fx.ParticleSystem;
import com.lumen.client.util.ClickCounter;
import com.lumen.client.util.CombatTracker;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientCommandHandler;
import com.lumen.client.util.Events;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.input.Keyboard;

/**
 * Lumen Client: a client-side PvP utility mod for Minecraft 1.8.9 (Forge 11.15.1.2318).
 * It uses only Forge events (no coremod / no mixins) so it runs next to OptiFine.
 */
@Mod(modid = LumenClient.MODID, name = LumenClient.NAME, version = LumenClient.VERSION,
        clientSideOnly = true, acceptableRemoteVersions = "*", acceptedMinecraftVersions = "[1.8.9]")
public class LumenClient {
    public static final String MODID = "lumenclient";
    public static final String NAME = "Lumen Client";
    public static final String VERSION = "1.0.0";

    /** Opens the ClickGUI. Defaults to Right Shift and can be changed in Options > Controls. */
    public static KeyBinding openGuiKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        openGuiKey = new KeyBinding("Open ClickGUI", Keyboard.KEY_RSHIFT, NAME);
        ClientRegistry.registerKeyBinding(openGuiKey);
        com.lumen.client.modules.Freelook.key = new KeyBinding("Freelook", Keyboard.KEY_LMENU, NAME);
        ClientRegistry.registerKeyBinding(com.lumen.client.modules.Freelook.key);

        ClientCommandHandler.instance.registerCommand(new LumenCommand());
        ClientCommandHandler.instance.registerCommand(new LhelpCommand());

        ModuleManager.init();
        ConfigManager.load();
        com.lumen.client.util.FoliageFilter.install();

        Events.register(new ClientEvents());
        Events.register(new com.lumen.client.modules.MinimalViewBobbing());
        Events.register(new com.lumen.client.modules.NoHurtCam());
        Events.register(com.lumen.client.util.FpsUncap.INSTANCE);
        Events.register(ClickCounter.INSTANCE);
        Events.register(CombatTracker.INSTANCE);
        Events.register(ParticleSystem.INSTANCE);
        Events.register(com.lumen.client.gui.MouseTrail.INSTANCE);
        Events.register(new com.lumen.client.cosmetics.CapeRenderer());
        Events.register(new com.lumen.client.cosmetics.SahurPet());

        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                ConfigManager.save();
            }
        }));
    }
}
