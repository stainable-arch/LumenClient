package com.lumen.client.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting {
    public final String[] modes;
    public int index;

    public ModeSetting(String name, String def, String... modes) {
        super(name);
        this.modes = modes;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(def)) {
                index = i;
            }
        }
    }

    public String get() {
        return modes[index];
    }

    public boolean is(String mode) {
        return modes[index].equalsIgnoreCase(mode);
    }

    public void cycle(int dir) {
        index = (index + dir + modes.length) % modes.length;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(modes[index]);
    }

    @Override
    public void load(JsonElement e) {
        if (e != null && e.isJsonPrimitive()) {
            String s = e.getAsString();
            for (int i = 0; i < modes.length; i++) {
                if (modes[i].equalsIgnoreCase(s)) {
                    index = i;
                    return;
                }
            }
        }
    }
}
