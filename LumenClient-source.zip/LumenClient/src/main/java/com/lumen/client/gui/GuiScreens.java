package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import net.minecraft.client.gui.GuiScreen;

/** Creates the ClickGUI layout picked in General > Settings > Gui. */
public final class GuiScreens {
    private GuiScreens() {}

    public static GuiScreen clickGui() {
        return ClientSettings.gui.is("v4") ? new ClickGuiV4() : new ClickGui();
    }

    /** True for any of the ClickGUI layouts. */
    public static boolean isClickGui(GuiScreen s) {
        return s instanceof ClickGui || s instanceof ClickGuiV4;
    }
}
