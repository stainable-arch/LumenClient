package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;

/** UI clicks use the closest soft, low-pitched vanilla sounds available without external assets. */
public final class Sounds {
    private Sounds() {}

    public static void play(String name, float pitch) {
        Minecraft.getMinecraft().getSoundHandler()
                .playSound(PositionedSoundRecord.create(new ResourceLocation(name), pitch));
    }

    private static void ui(String name, float pitch) {
        if (ClientSettings.sounds) play(name, pitch);
    }

    public static void open() { ui("random.click", 0.72f); }
    public static void close() { ui("random.click", 0.58f); }
    public static void toggle(boolean on) { ui("random.click", on ? 0.82f : 0.64f); }
    public static void expand(boolean open) { ui("random.click", open ? 0.90f : 0.68f); }
    public static void click() { ui("random.click", 0.76f); }
    public static void theme(int index) { ui("random.click", 0.70f + 0.035f * index); }
}
