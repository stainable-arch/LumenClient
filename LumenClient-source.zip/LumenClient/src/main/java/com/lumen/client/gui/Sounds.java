package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;

/** UI click sounds (all built from vanilla sounds, no extra assets needed). */
public final class Sounds {
    private Sounds() {}

    /** Plays a vanilla sound at the given pitch, ignoring the "Sounds" toggle. */
    public static void play(String name, float pitch) {
        Minecraft.getMinecraft().getSoundHandler()
                .playSound(PositionedSoundRecord.create(new ResourceLocation(name), pitch));
    }

    private static void ui(String name, float pitch) {
        if (ClientSettings.sounds) {
            play(name, pitch);
        }
    }

    public static void open() {
        ui("gui.button.press", 0.8f);
    }

    public static void close() {
        ui("gui.button.press", 0.6f);
    }

    /** A module was switched on or off. */
    public static void toggle(boolean on) {
        ui("gui.button.press", on ? 1.25f : 0.85f);
    }

    /** A module's settings were expanded or collapsed. */
    public static void expand(boolean open) {
        ui("random.click", open ? 1.45f : 1.0f);
    }

    public static void click() {
        ui("random.click", 1.1f);
    }

    public static void theme(int index) {
        ui("note.pling", 0.7f + 0.12f * index);
    }
}
