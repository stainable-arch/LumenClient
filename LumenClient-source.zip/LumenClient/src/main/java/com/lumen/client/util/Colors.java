package com.lumen.client.util;

import com.lumen.client.gui.Theme;

import java.awt.Color;

public final class Colors {
    private Colors() {}

    private static float clamp01(float f) {
        return f < 0f ? 0f : (f > 1f ? 1f : f);
    }

    public static int withAlpha(int color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    /** Multiplies the alpha channel of an ARGB colour by f (0..1). */
    public static int mulAlpha(int color, float f) {
        int a = (int) (((color >>> 24) & 255) * clamp01(f));
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public static int lerp(int c1, int c2, float t) {
        t = clamp01(t);
        int a = (int) (((c1 >>> 24) & 255) + (((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Extracts one 0..255 channel: shift 24 = alpha, 16 = red, 8 = green, 0 = blue. */
    public static int channel(int color, int shift) {
        return (color >> shift) & 255;
    }

    public static int opaque(int rgb) {
        return 0xFF000000 | rgb;
    }

    public static int hsb(float h, float s, float b) {
        return 0xFF000000 | Color.HSBtoRGB(h, s, b);
    }

    /** Smoothly samples c1 -> c2 -> c3 -> c1 for t in any range (wraps around). */
    public static int gradient(Theme theme, float t) {
        t = t - (float) Math.floor(t);
        float scaled = t * 3f;
        int seg = (int) scaled;
        float f = scaled - seg;
        if (seg > 2) {
            seg = 2;
            f = 1f;
        }
        int[] c = { opaque(theme.c1), opaque(theme.c2), opaque(theme.c3), opaque(theme.c1) };
        return lerp(c[seg], c[seg + 1], f);
    }
}
