package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

/** Small vector icons drawn with plain shapes (no textures). */
public final class Icons {
    private Icons() {}

    /**
     * Themed pencil pointing to the bottom-left, centred on (cx, cy). size = about the icon's
     * length in GUI units. Body uses the theme's first colour, the tip the third, plus a light eraser.
     */
    public static void pencil(float cx, float cy, float size, Theme th, float alpha) {
        float k = size / 14f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.rotate(45f, 0f, 0f, 1f);
        GlStateManager.scale(k, k, 1f);

        int body = Colors.mulAlpha(Colors.opaque(th.c1), alpha);
        int tip = Colors.mulAlpha(Colors.opaque(th.c3), alpha);
        int wood = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.7f), alpha);
        int eraser = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c2), 0xFFFFFFFF, 0.35f), alpha);

        RenderUtil.rect(-2.2f, -7f, 2.2f, -5.2f, eraser);   // eraser
        RenderUtil.rect(-2.2f, -5.2f, 2.2f, 2.5f, body);    // body
        RenderUtil.rect(-0.7f, -5.2f, 0.7f, 2.5f, Colors.mulAlpha(wood, 0.35f)); // highlight stripe
        // sharpened wood + lead
        triangle(-2.2f, 2.5f, 2.2f, 2.5f, 0f, 7f, wood);
        triangle(-0.9f, 5.2f, 0.9f, 5.2f, 0f, 7f, tip);

        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void triangle(float x1, float y1, float x2, float y2, float x3, float y3, int color) {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(Colors.channel(color, 16) / 255f, Colors.channel(color, 8) / 255f,
                Colors.channel(color, 0) / 255f, Colors.channel(color, 24) / 255f);
        GL11.glBegin(GL11.GL_TRIANGLES);
        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x3, y3);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
