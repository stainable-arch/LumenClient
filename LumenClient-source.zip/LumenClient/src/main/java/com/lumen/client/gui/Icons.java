package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

/** Small vector icons drawn with plain shapes (no textures). */
public final class Icons {
    private Icons() {}

    /**
     * Themed pencil pointing to the bottom-left, centred on (cx, cy). size = about the icon's
     * length in GUI units. Body uses the theme's first colour, the tip the third, plus a light eraser.
     */
    public static void pencil(float cx, float cy, float size, Theme th, float alpha) {
        float k = size / 14f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.rotate(45f, 0f, 0f, 1f);
        GlStateManager.scale(k, k, 1f);

        int body = Colors.mulAlpha(Colors.opaque(th.c1), alpha);
        int tip = Colors.mulAlpha(Colors.opaque(th.c3), alpha);
        int wood = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.7f), alpha);
        int eraser = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c2), 0xFFFFFFFF, 0.35f), alpha);

        RenderUtil.rect(-2.2f, -7f, 2.2f, -5.2f, eraser);   // eraser
        RenderUtil.rect(-2.2f, -5.2f, 2.2f, 2.5f, body);    // body
        RenderUtil.rect(-0.7f, -5.2f, 0.7f, 2.5f, Colors.mulAlpha(wood, 0.35f)); // highlight stripe
        // sharpened wood + lead
        triangle(-2.2f, 2.5f, 2.2f, 2.5f, 0f, 7f, wood);
        triangle(-0.9f, 5.2f, 0.9f, 5.2f, 0f, 7f, tip);

        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Themed gear (8 teeth, hollow centre) centred on (cx, cy); size = about its diameter in GUI units. */
    public static void gear(float cx, float cy, float size, Theme th, float alpha) {
        float k = size / 14f;
        int a = Colors.mulAlpha(Colors.opaque(th.c1), alpha);
        int b = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), Colors.opaque(th.c3), 0.6f), alpha);
        int hole = Colors.mulAlpha(Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), 0.07f), alpha);
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        for (int i = 0; i < 4; i++) { // 4 bars cross = 8 teeth
            GlStateManager.pushMatrix();
            GlStateManager.rotate(45f * i, 0f, 0f, 1f);
            RenderUtil.rect(-1.7f, -7f, 1.7f, 7f, b);
            GlStateManager.popMatrix();
        }
        RenderUtil.circle(0f, 0f, 5.2f, a);
        RenderUtil.circle(0f, 0f, 2.3f, hole);
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Themed T-shirt centred on (cx, cy); size = about its width in GUI units. */
    public static void shirt(float cx, float cy, float size, Theme th, float alpha) {
        float k = size / 17f;
        int a = Colors.mulAlpha(Colors.opaque(th.c1), alpha);
        int b = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), Colors.opaque(th.c3), 0.6f), alpha);
        int hole = Colors.mulAlpha(Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), 0.07f), alpha);
        int hi = Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.55f), alpha * 0.45f);
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        RenderUtil.rect(-4.5f, -4.5f, 4.5f, 7f, a);                                  // body
        triangle(-4.5f, -5.5f, -8.8f, -2.6f, -6.8f, 0.6f, b);                        // left sleeve
        triangle(-4.5f, -5.5f, -6.8f, 0.6f, -4.5f, -1.2f, b);
        triangle(4.5f, -5.5f, 6.8f, 0.6f, 8.8f, -2.6f, b);                           // right sleeve
        triangle(4.5f, -5.5f, 4.5f, -1.2f, 6.8f, 0.6f, b);
        RenderUtil.rect(-4.5f, -5.5f, 4.5f, -4.5f, b);                               // shoulders
        triangle(-2.3f, -5.5f, 2.3f, -5.5f, 0f, -3f, hole);                          // neck
        RenderUtil.rect(-3f, 2.5f, 3f, 3.2f, hi);                                    // fold highlight
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Cape / cloak silhouette centred on (cx, cy); size = about its height. Plain ARGB colour. */
    public static void cape(float cx, float cy, float size, int color) {
        float k = size / 16f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        triangle(-3f, -7.5f, 3f, -7.5f, 6.5f, 7.5f, color);
        triangle(-3f, -7.5f, 6.5f, 7.5f, -6.5f, 7.5f, color);
        RenderUtil.circle(0f, -6.8f, 2.2f, color);
        RenderUtil.circle(0f, -6.8f, 1f, Colors.mulAlpha(0xFF000000, ((color >>> 24) & 255) / 255f * 0.55f));
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Paw print (pets) centred on (cx, cy); size = about its width. */
    public static void paw(float cx, float cy, float size, int color) {
        float k = size / 14f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        RenderUtil.circle(0f, 3f, 4.2f, color);
        RenderUtil.circle(-5f, -1.6f, 2.1f, color);
        RenderUtil.circle(-1.9f, -5.2f, 2.2f, color);
        RenderUtil.circle(1.9f, -5.2f, 2.2f, color);
        RenderUtil.circle(5f, -1.6f, 2.1f, color);
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Arrow pointing left (back button) centred on (cx, cy). */
    public static void back(float cx, float cy, float size, int color) {
        float k = size / 14f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        triangle(-7f, 0f, -0.5f, -6f, -0.5f, 6f, color);
        RenderUtil.rect(-1f, -2f, 7f, 2f, color);
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Magnifying glass (search bar) centred on (cx, cy). */
    public static void magnifier(float cx, float cy, float size, int color) {
        float k = size / 12f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        RenderUtil.ring(-1.5f, -1.5f, 4f, 1.4f, color);
        GlStateManager.pushMatrix();
        GlStateManager.translate(2.6f, 2.6f, 0f);
        GlStateManager.rotate(-45f, 0f, 0f, 1f);
        RenderUtil.rect(-0.2f, -0.8f, 4.2f, 0.8f, color);
        GlStateManager.popMatrix();
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Tick mark (on = true) or cross (on = false) centred on (cx, cy). */
    public static void tick(float cx, float cy, float size, boolean on, int color) {
        float k = size / 10f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0f);
        GlStateManager.scale(k, k, 1f);
        if (on) {
            GlStateManager.rotate(45f, 0f, 0f, 1f);
            RenderUtil.rect(-2.6f, -0.6f, -1.2f, 3.4f, color);
            RenderUtil.rect(-2.6f, 2.0f, 3.6f, 3.4f, color);
        } else {
            for (int i = 0; i < 2; i++) {
                GlStateManager.pushMatrix();
                GlStateManager.rotate(i == 0 ? 45f : -45f, 0f, 0f, 1f);
                RenderUtil.rect(-4f, -0.7f, 4f, 0.7f, color);
                GlStateManager.popMatrix();
            }
        }
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void triangle(float x1, float y1, float x2, float y2, float x3, float y3, int color) {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(Colors.channel(color, 16) / 255f, Colors.channel(color, 8) / 255f,
                Colors.channel(color, 0) / 255f, Colors.channel(color, 24) / 255f);
        GL11.glBegin(GL11.GL_TRIANGLES);
        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x3, y3);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
