package com.lumen.client.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.awt.Color;

/** A colour stored as hue / saturation / brightness (what the colour wheel in the ClickGUI edits). */
public class ColorSetting extends Setting {
    /** All three are 0..1. */
    public float hue, sat, val;

    /** Height of the row in the ClickGUI: label line + the colour wheel. */
    public static final int HEIGHT = 98;

    public ColorSetting(String name, int defRgb) {
        super(name);
        set(defRgb);
    }

    /** The colour as 0xRRGGBB. */
    public int rgb() {
        return Color.HSBtoRGB(hue, sat, val) & 0xFFFFFF;
    }

    public void set(int rgb) {
        float[] hsb = Color.RGBtoHSB((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, null);
        // a grey has no hue of its own: keep the one the wheel already shows
        if (hsb[1] > 0.001f && hsb[2] > 0.001f) hue = hsb[0];
        sat = hsb[1];
        val = hsb[2];
    }

    @Override
    public int height() {
        return HEIGHT;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(Integer.valueOf(rgb()));
    }

    @Override
    public void load(JsonElement e) {
        if (e != null && e.isJsonPrimitive()) {
            try {
                set(e.getAsInt());
            } catch (Exception ignored) {
                // keep the current colour
            }
        }
    }
}
