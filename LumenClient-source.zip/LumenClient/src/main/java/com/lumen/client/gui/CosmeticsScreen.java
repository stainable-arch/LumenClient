package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

/**
 * Cosmetics screen opened by the shirt button of the main menu: the Cosmetics master switch plus the
 * cape and the pet. Same settings as Settings > Cosmetics in the ClickGUI. Esc or a click outside goes back.
 */
public class CosmeticsScreen extends GuiScreen {
    private static final float PANEL_W = 220f, ROW_H = 18f, PAD = 10f, TITLE_H = 22f, BOX = 10f;

    private final GuiScreen parent;
    private float fade;
    private float masterAnim = ClientSettings.cosmetics ? 1f : 0f;
    private long lastFrame = System.currentTimeMillis();

    public CosmeticsScreen(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
    }

    @Override
    public void onGuiClosed() {
        ConfigManager.save();
    }

    private static final int ROWS = 3;

    private float panelH() { return TITLE_H + PAD + ROWS * ROW_H + PAD; }

    private float panelX() { return (width - PANEL_W) / 2f; }

    private float panelY() { return (height - panelH()) / 2f; }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);
        float step = Math.min(1f, dt * 14f);

        Theme th = Theme.current();
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (th.glass) {
            GlassFx.backdrop(width, height, e * 0.55f, now, false);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.bg), 110), e),
                    Colors.mulAlpha(Colors.withAlpha(Colors.lerp(Colors.opaque(th.bg), Colors.opaque(th.c3), 0.18f), 140), e));
        }

        float px = panelX(), py = panelY(), pw = PANEL_W, ph = panelH();
        if (th.glass) {
            GlassFx.pane(px, py, px + pw, py + ph, 8f, e, 0f);
        } else {
            RenderUtil.roundedRect(px - 1f, py - 1f, px + pw + 1f, py + ph + 1f, 9f,
                    Colors.mulAlpha(Colors.opaque(Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), e));
            RenderUtil.roundedRect(px, py, px + pw, py + ph, 8f, Colors.mulAlpha(Colors.withAlpha(0xFF0C0E24, 245), e));
        }
        Icons.shirt(px + PAD + 6f, py + 11f, 13f, th, e);
        LumenFont.draw("Cosmetics", px + PAD + 18f, py + 6f, Colors.mulAlpha(0xFFFFFFFF, e), true);

        masterAnim += ((ClientSettings.cosmetics ? 1f : 0f) - masterAnim) * step;
        ClientSettings.cape.anim += ((ClientSettings.cape.value ? 1f : 0f) - ClientSettings.cape.anim) * step;
        ClientSettings.sahurPet.anim += ((ClientSettings.sahurPet.value ? 1f : 0f) - ClientSettings.sahurPet.anim) * step;

        float ry = py + TITLE_H + PAD;
        for (int i = 0; i < ROWS; i++) {
            String name = i == 0 ? "Cosmetics" : i == 1 ? ClientSettings.cape.name : ClientSettings.sahurPet.name;
            float on = i == 0 ? masterAnim : i == 1 ? ClientSettings.cape.anim : ClientSettings.sahurPet.anim;
            boolean hover = overRow(i, mouseX, mouseY);
            if (hover) RenderUtil.roundedRect(px + 4f, ry, px + pw - 4f, ry + ROW_H, 5f,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.c1), 34), e));
            LumenFont.draw(name, px + PAD, ry + 4f, Colors.mulAlpha(Colors.lerp(0xFFD5D9E8, 0xFFFFFFFF, on), e), true);
            drawBox(px + pw - PAD - BOX, ry + (ROW_H - BOX) / 2f, on, th, e);
            ry += ROW_H;
        }

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private boolean overRow(int i, int mx, int my) {
        float px = panelX(), ry = panelY() + TITLE_H + PAD + i * ROW_H;
        return mx >= px + 4f && mx <= px + PANEL_W - 4f && my >= ry && my < ry + ROW_H;
    }

    /** Checkbox: outlined square that fills with the theme colour and shows a tick when on (on = 0..1). */
    private void drawBox(float x, float y, float on, Theme th, float alpha) {
        int c = Colors.opaque(th.c1);
        RenderUtil.roundedRect(x - 1f, y - 1f, x + BOX + 1f, y + BOX + 1f, 3.5f,
                Colors.mulAlpha(Colors.lerp(Colors.lerp(c, 0xFF1E2247, 0.55f), c, on), alpha));
        RenderUtil.roundedRect(x, y, x + BOX, y + BOX, 3f,
                Colors.mulAlpha(Colors.lerp(0xFF0C0E24, c, on), alpha));
        if (on > 0.02f) {
            int white = Colors.mulAlpha(0xFFFFFFFF, alpha * on);
            GlStateManager.pushMatrix();
            GlStateManager.translate(x + BOX / 2f, y + BOX / 2f, 0f);
            GlStateManager.rotate(45f, 0f, 0f, 1f);
            RenderUtil.rect(-2.6f, 0.2f, -1.4f, 3.2f, white);
            RenderUtil.rect(-2.6f, 2.0f, 3.4f, 3.2f, white);
            GlStateManager.popMatrix();
            GlStateManager.color(1f, 1f, 1f, 1f);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        for (int i = 0; i < ROWS; i++) {
            if (!overRow(i, mouseX, mouseY)) continue;
            if (i == 0) {
                ClientSettings.cosmetics = !ClientSettings.cosmetics;
                Sounds.toggle(ClientSettings.cosmetics);
            } else {
                BooleanSetting s = i == 1 ? ClientSettings.cape : ClientSettings.sahurPet;
                s.toggle();
                Sounds.toggle(s.value);
            }
            return;
        }
        float px = panelX(), py = panelY();
        if (mouseX < px || mouseX > px + PANEL_W || mouseY < py || mouseY > py + panelH()) back();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) back();
    }

    private void back() {
        Sounds.click();
        mc.displayGuiScreen(parent);
    }
}
