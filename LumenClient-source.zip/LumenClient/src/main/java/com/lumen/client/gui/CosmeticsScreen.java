package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.cosmetics.CapeRenderer;
import com.lumen.client.cosmetics.SahurPet;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Cosmetics screen (shirt button of the main menu), laid out like Lunar Client's: a category rail on the left,
 * a search bar over a grid of item tiles, and a draggable preview of your player on the right. Clicking a tile
 * equips / unequips the item (green outline = equipped). The round button bottom-right is the Cosmetics master
 * switch, the arrow bottom-left goes back. Same settings as Settings > Cosmetics in the ClickGUI.
 */
public class CosmeticsScreen extends GuiScreen {
    // ---- layout, in "design units" (a 254 high screen at k = 1; everything is multiplied by k) ----
    private static final float SIDE_W = 34f, GRID_X = 51f, TILE_W = 34f, TILE_H = 46f, GAP = 4.5f;
    private static final float BAR_Y = 10.5f, BAR_H = 15f, GRID_Y = 41f, BTN = 16f;
    private static final int COLS = 5;

    private static final int GREEN = 0xFF3FD958;
    private static final String[] CAT_NAMES = { "Capes", "Pets" };

    /** One equippable item. The thumbnail is a rectangle (u, v, w, h) of a texture that is tw x th "texels" big. */
    private static final class Item {
        final int cat;
        final String name;
        final BooleanSetting setting;
        final ResourceLocation tex;
        final float u, v, w, h, tw, th;

        Item(int cat, String name, BooleanSetting setting, ResourceLocation tex, float u, float v, float w, float h, float tw, float th) {
            this.cat = cat;
            this.name = name;
            this.setting = setting;
            this.tex = tex;
            this.u = u;
            this.v = v;
            this.w = w;
            this.h = h;
            this.tw = tw;
            this.th = th;
        }
    }

    private static int lastCat;

    private final GuiScreen parent;
    private final List<Item> all = new ArrayList<Item>();
    private final List<Item> shown = new ArrayList<Item>();
    private Item sel;
    private int cat = lastCat;

    private String query = "";
    private boolean searchFocus;

    private float fade, scroll, scrollTarget;
    private float masterAnim = ClientSettings.cosmetics ? 1f : 0f;
    private long lastFrame = System.currentTimeMillis();

    // player preview
    private float yaw = 160f, yawTarget = 160f;
    private boolean autoYaw = true, dragging;
    private int lastDragX;
    private float petAnim = ClientSettings.sahurPet.value ? 1f : 0f;
    private final ModelPlayer wide = new ModelPlayer(0f, false), slimModel = new ModelPlayer(0f, true);
    private ResourceLocation skin;
    private boolean slim;
    private boolean skinRequested;

    public CosmeticsScreen(GuiScreen parent) {
        this.parent = parent;
        // Capes: face of the cape texture (1,1,10,16 of 64x32). Pets: front of the log body (6,6,8,16 of 64x64).
        all.add(new Item(0, "Lumen Cape (Black & White)", ClientSettings.cape, CapeRenderer.texture(), 1f, 1f, 10f, 16f, 64f, 32f));
        all.add(new Item(1, "Tung Tung Sahur", ClientSettings.sahurPet, SahurPet.texture(), 6f, 6f, 8f, 16f, 64f, 64f));
        refilter();
        selectDefault();
    }

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
    }

    @Override
    public void onGuiClosed() {
        lastCat = cat;
        ConfigManager.save();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    // ------------------------------------------------------------------------------------------
    // model
    // ------------------------------------------------------------------------------------------

    private void refilter() {
        shown.clear();
        String q = query.trim().toLowerCase(Locale.ROOT);
        for (Item it : all) {
            if (q.isEmpty() ? it.cat == cat : it.name.toLowerCase(Locale.ROOT).contains(q)) shown.add(it);
        }
        scrollTarget = 0f;
    }

    private void selectDefault() {
        sel = null;
        for (Item it : shown) {
            if (it.setting.value) {
                sel = it;
                break;
            }
        }
        if (sel == null && !shown.isEmpty()) sel = shown.get(0);
        retarget();
    }

    private void retarget() {
        autoYaw = true;
        yawTarget = sel != null && sel.cat == 0 ? 160f : -25f; // capes are shown from behind
    }

    private float k() {
        return Math.max(0.5f, Math.min(height / 254f, width / 360f));
    }

    private float gridX() { return GRID_X * k(); }

    private float gridY() { return GRID_Y * k(); }

    private float gridBottom() { return height - 12f * k(); }

    private float gridW() { return (COLS * TILE_W + (COLS - 1) * GAP) * k(); }

    private float previewLeft() { return gridX() + gridW() + 16f * k(); }

    private float scrollMax() {
        int rows = (shown.size() + COLS - 1) / COLS;
        float content = rows * (TILE_H + GAP) * k() - GAP * k();
        return Math.max(0f, content - (gridBottom() - gridY()));
    }

    private float tileX(int i) { return gridX() + (i % COLS) * (TILE_W + GAP) * k(); }

    private float tileY(int i) { return gridY() - scroll + (i / COLS) * (TILE_H + GAP) * k(); }

    private int tileAt(int mx, int my) {
        float k = k();
        if (my < gridY() || my > gridBottom()) return -1;
        for (int i = 0; i < shown.size(); i++) {
            float x = tileX(i), y = tileY(i);
            if (mx >= x && mx <= x + TILE_W * k && my >= y && my <= y + TILE_H * k) return i;
        }
        return -1;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);
        float step = Math.min(1f, dt * 14f);
        float k = k();
        Theme th = Theme.current();

        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (th.glass) {
            GlassFx.backdrop(width, height, e * 0.7f, now, false);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.bg), 170), e),
                    Colors.mulAlpha(Colors.withAlpha(Colors.lerp(Colors.opaque(th.bg), Colors.opaque(th.c3), 0.18f), 190), e));
        }

        // animations
        masterAnim += ((ClientSettings.cosmetics ? 1f : 0f) - masterAnim) * step;
        petAnim += ((ClientSettings.sahurPet.value && ClientSettings.cosmetics ? 1f : 0f) - petAnim) * step;
        for (Item it : all) it.setting.anim += ((it.setting.value ? 1f : 0f) - it.setting.anim) * step;
        scroll += (scrollTarget - scroll) * step;
        scrollTarget = MathHelper.clamp_float(scrollTarget, 0f, scrollMax());
        scroll = MathHelper.clamp_float(scroll, 0f, scrollMax() + 1f);
        if (autoYaw && !dragging) yaw += MathHelper.wrapAngleTo180_float(yawTarget - yaw) * step * 0.6f;

        drawRail(mouseX, mouseY, e, k, th);
        drawSearch(e, k, now);
        drawGrid(mouseX, mouseY, e, k, th);
        drawPreview(e, k, now, th);
        drawBottomButtons(mouseX, mouseY, e, k, th);

        int hover = tileAt(mouseX, mouseY);
        if (hover >= 0) tooltip(shown.get(hover).name, mouseX + 8f, mouseY + 10f, e);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawRail(int mx, int my, float e, float k, Theme th) {
        RenderUtil.rect(0f, 0f, SIDE_W * k, height, Colors.mulAlpha(0x88000000, e));
        RenderUtil.rect(SIDE_W * k - 0.6f, 0f, SIDE_W * k, height, Colors.mulAlpha(0x22FFFFFF, e));
        for (int i = 0; i < CAT_NAMES.length; i++) {
            float cx = SIDE_W * k / 2f, cy = (22f + i * 25.5f) * k;
            boolean on = i == cat, over = overRailIcon(i, mx, my);
            if (on) {
                RenderUtil.roundedRect(0f, cy - 9f * k, 2.4f * k, cy + 9f * k, 1.2f * k, Colors.mulAlpha(Colors.opaque(th.c1), e));
            }
            int col = Colors.mulAlpha(on ? 0xFFFFFFFF : over ? 0xFFD0D3DD : 0xFF7E8396, e);
            if (i == 0) Icons.cape(cx, cy, 15f * k, col);
            else Icons.paw(cx, cy, 15f * k, col);
        }
    }

    private boolean overRailIcon(int i, int mx, int my) {
        float k = k(), cy = (22f + i * 25.5f) * k;
        return mx >= 0 && mx <= SIDE_W * k && my >= cy - 12f * k && my <= cy + 12f * k;
    }

    private void drawSearch(float e, float k, long now) {
        float x = gridX(), y = BAR_Y * k, w = gridW(), h = BAR_H * k;
        RenderUtil.roundedRect(x - 0.7f, y - 0.7f, x + w + 0.7f, y + h + 0.7f, 4f * k + 0.7f,
                Colors.mulAlpha(searchFocus ? 0x80FFFFFF : 0x30FFFFFF, e));
        RenderUtil.roundedRect(x, y, x + w, y + h, 4f * k, Colors.mulAlpha(0xA02A2C33, e));
        Icons.magnifier(x + 7f * k, y + h / 2f, 8f * k, Colors.mulAlpha(0xFFB4B8C6, e));
        float sc = 0.95f * k;
        float tx = x + 14f * k, ty = y + h / 2f - 5f * sc;
        if (query.isEmpty() && !searchFocus) {
            text("Search", tx, ty, sc, Colors.mulAlpha(0xFF7E8396, e));
        } else {
            text(query, tx, ty, sc, Colors.mulAlpha(0xFFFFFFFF, e));
            if (searchFocus && (now / 500) % 2 == 0) {
                float cx = tx + LumenFont.width(query) * sc + 0.5f * k;
                RenderUtil.rect(cx, ty, cx + 0.8f * k, ty + 10f * sc, Colors.mulAlpha(0xFFFFFFFF, e));
            }
        }
    }

    private void drawGrid(int mx, int my, float e, float k, Theme th) {
        float x0 = gridX(), y0 = gridY(), w = gridW();
        RenderUtil.scissor(x0 - 2f, y0, w + 4f, gridBottom() - y0);
        int hover = tileAt(mx, my);
        float dim = 0.35f + 0.65f * masterAnim;
        for (int i = 0; i < shown.size(); i++) {
            Item it = shown.get(i);
            float x = tileX(i), y = tileY(i), x2 = x + TILE_W * k, y2 = y + TILE_H * k;
            if (y2 < y0 || y > gridBottom()) continue;
            boolean eq = it.setting.value, over = i == hover;
            int border = eq ? GREEN : over ? 0xA0FFFFFF : 0x38FFFFFF;
            RenderUtil.roundedRect(x - 0.8f, y - 0.8f, x2 + 0.8f, y2 + 0.8f, 4.5f * k + 0.8f, Colors.mulAlpha(border, e));
            RenderUtil.roundedRect(x, y, x2, y2, 4.5f * k, Colors.mulAlpha(over ? 0xC8262831 : 0xC8191A20, e));
            float tw = 22f * k, thh = tw * it.h / it.w;
            float tx = x + (TILE_W * k - tw) / 2f, ty = y + (TILE_H * k - thh) / 2f;
            RenderUtil.rectOutline(tx - 0.5f, ty - 0.5f, tx + tw + 0.5f, ty + thh + 0.5f, 0.8f, Colors.mulAlpha(0x66FFFFFF, e * dim));
            quad(it.tex, tx, ty, tw, thh, it.u, it.v, it.w, it.h, it.tw, it.th, e * dim);
        }
        RenderUtil.endScissor();

        // scrollbar
        float max = scrollMax();
        if (max > 0.5f) {
            float tx = x0 + w + 6f * k, ty = y0, th2 = gridBottom() - y0;
            RenderUtil.roundedRect(tx, ty, tx + 2.4f * k, ty + th2, 1.2f * k, Colors.mulAlpha(0x30FFFFFF, e));
            float frac = th2 / (th2 + max), bar = Math.max(14f * k, th2 * frac);
            float by = ty + (th2 - bar) * (scroll / max);
            RenderUtil.roundedRect(tx, by, tx + 2.4f * k, by + bar, 1.2f * k, Colors.mulAlpha(0xB0FFFFFF, e));
        }
        if (shown.isEmpty()) {
            text("No cosmetics found", x0, y0 + 4f * k, 0.9f * k, Colors.mulAlpha(0xFF7E8396, e));
        }
    }

    // ---- preview ----

    private void resolveSkin() {
        if (mc.thePlayer != null) {
            skin = mc.thePlayer.getLocationSkin();
            slim = "slim".equals(mc.thePlayer.getSkinType());
            return;
        }
        if (skinRequested) return;
        skinRequested = true;
        GameProfile gp = mc.getSession().getProfile();
        UUID id = EntityPlayer.getUUID(gp);
        skin = DefaultPlayerSkin.getDefaultSkin(id);
        slim = "slim".equals(DefaultPlayerSkin.getSkinType(id));
        mc.getSkinManager().loadProfileTextures(gp, new SkinManager.SkinAvailableCallback() {
            @Override
            public void skinAvailable(MinecraftProfileTexture.Type type, ResourceLocation loc, MinecraftProfileTexture tex) {
                if (type == MinecraftProfileTexture.Type.SKIN) {
                    skin = loc;
                    slim = "slim".equals(tex.getMetadata("model"));
                }
            }
        }, true);
    }

    private void drawPreview(float e, float k, long now, Theme th) {
        float left = previewLeft();
        float cx = (left + width) / 2f;
        float bottom = height;
        float s = 86f * k;                      // pixels per block
        float feetY = bottom - 56f * k;

        // texts under the player
        float mid = cx;
        text("HINT: CLICK TO DRAG", mid - LumenFont.width("HINT: CLICK TO DRAG") * 0.5f * 0.5f * k, bottom - 35f * k, 0.5f * k,
                Colors.mulAlpha(0xFF6F7385, e));
        if (sel != null) {
            String n = sel.name.toUpperCase(Locale.ROOT);
            float sc = 0.78f * k;
            text(n, mid - LumenFont.width(n) * sc / 2f, bottom - 27f * k, sc, Colors.mulAlpha(0xFFB9BDCB, e));
            float rowW = 10f * k + 5f * k + LumenFont.width("Equipped") * 0.9f * k;
            float rx = mid - rowW / 2f, ry = bottom - 15f * k;
            drawBox(rx, ry, 10f * k, sel.setting.anim, th, e);
            text("Equipped", rx + 15f * k, ry + 0.5f * k, 0.9f * k, Colors.mulAlpha(0xFFE6E8F0, e));
        }

        resolveSkin();
        if (skin == null) return;

        float petShift = petAnim * 0.55f;       // blocks: make room for the pet
        GlStateManager.clear(256);
        GlStateManager.enableColorMaterial();
        GlStateManager.enableDepth();
        GlStateManager.enableRescaleNormal();
        GlStateManager.disableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);

        // player
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx - petShift * s, feetY, 100f);
        GlStateManager.scale(-s, s, s);
        GlStateManager.rotate(180f, 0f, 0f, 1f);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.enableLighting();
        GlStateManager.rotate(180f - yaw, 0f, 1f, 0f);
        GlStateManager.pushMatrix();
        GlStateManager.scale(-1f, -1f, 1f);
        GlStateManager.scale(0.9375f, 0.9375f, 0.9375f);
        GlStateManager.translate(0f, -1.5078125f, 0f);
        mc.getTextureManager().bindTexture(skin);
        ModelPlayer m = slim ? slimModel : wide;
        float f = 0.0625f;
        m.bipedHead.render(f);
        m.bipedHeadwear.render(f);
        m.bipedBody.render(f);
        m.bipedBodyWear.render(f);
        m.bipedRightArm.render(f);
        m.bipedRightArmwear.render(f);
        m.bipedLeftArm.render(f);
        m.bipedLeftArmwear.render(f);
        m.bipedRightLeg.render(f);
        m.bipedRightLegwear.render(f);
        m.bipedLeftLeg.render(f);
        m.bipedLeftLegwear.render(f);
        if (ClientSettings.cosmetics && ClientSettings.cape.value) {
            mc.getTextureManager().bindTexture(CapeRenderer.texture());
            GlStateManager.pushMatrix();
            GlStateManager.translate(0f, 0f, 0.125f);
            GlStateManager.rotate(6f + (float) Math.sin(now / 700.0) * 2.2f, 1f, 0f, 0f);
            GlStateManager.rotate(180f, 0f, 1f, 0f);
            m.renderCape(f);
            GlStateManager.popMatrix();
        }
        GlStateManager.popMatrix();
        GlStateManager.popMatrix();

        // pet, standing next to the player and facing the viewer (it does not turn with the drag)
        if (petAnim > 0.02f) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(cx + 0.62f * s * petAnim, feetY, 100f);
            GlStateManager.scale(-s, s, s);
            GlStateManager.rotate(180f, 0f, 0f, 1f);
            RenderHelper.enableStandardItemLighting();
            GlStateManager.enableLighting();
            GlStateManager.rotate(180f + 18f, 0f, 1f, 0f);
            SahurPet.drawPreview(now / 50f);
            GlStateManager.popMatrix();
        }

        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.disableColorMaterial();
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private boolean overPreview(int mx, int my) {
        return mx >= previewLeft() && my >= 24f * k() && my <= height - 40f * k();
    }

    // ---- buttons ----

    private float backX() { return (SIDE_W - BTN) / 2f * k(); }

    private float btnY() { return height - (BTN + 6f) * k(); }

    private float masterX() { return width - (BTN + 4f) * k(); }

    private boolean overBack(int mx, int my) {
        float k = k();
        return mx >= backX() && mx <= backX() + BTN * k && my >= btnY() && my <= btnY() + BTN * k;
    }

    private boolean overMaster(int mx, int my) {
        float k = k();
        return mx >= masterX() && mx <= masterX() + BTN * k && my >= btnY() && my <= btnY() + BTN * k;
    }

    private void squareButton(float x, float y, float size, boolean hover, int accent, float e) {
        RenderUtil.roundedRect(x - 0.8f, y - 0.8f, x + size + 0.8f, y + size + 0.8f, 4f * k() + 0.8f,
                Colors.mulAlpha(hover ? Colors.withAlpha(accent, 255) : Colors.withAlpha(accent, 150), e));
        RenderUtil.roundedRect(x, y, x + size, y + size, 4f * k(), Colors.mulAlpha(hover ? 0xE0343741 : 0xE01F2026, e));
    }

    private void drawBottomButtons(int mx, int my, float e, float k, Theme th) {
        float s = BTN * k, y = btnY();
        boolean ob = overBack(mx, my);
        squareButton(backX(), y, s, ob, 0xFFB4B8C6, e);
        Icons.back(backX() + s / 2f, y + s / 2f, 9f * k, Colors.mulAlpha(ob ? 0xFFFFFFFF : 0xFFD0D3DD, e));

        boolean om = overMaster(mx, my);
        int accent = Colors.lerp(0xFFE0566A, GREEN, masterAnim);
        float x = masterX();
        squareButton(x, y, s, om, accent, e);
        Icons.tick(x + s / 2f, y + s / 2f, 9f * k, ClientSettings.cosmetics, Colors.mulAlpha(accent, e));
        if (om) {
            String t = ClientSettings.cosmetics ? "Cosmetics: ON" : "Cosmetics: OFF";
            float sc = 0.8f * k, w = LumenFont.width(t) * sc;
            tooltip(t, x - w - 14f * k, y + 2f * k, e);
        }
    }

    // ---- small helpers ----

    private void text(String s, float x, float y, float sc, int color) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(sc, sc, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void tooltip(String s, float x, float y, float e) {
        float k = k(), sc = 0.8f * k, w = LumenFont.width(s) * sc, pad = 4f * k, h = 10f * sc + pad * 2f - 2f * k;
        x = Math.min(x, width - w - pad * 2f - 2f);
        RenderUtil.roundedRect(x, y, x + w + pad * 2f, y + h, 3f * k, Colors.mulAlpha(0xF012131A, e));
        RenderUtil.roundedOutline(x, y, x + w + pad * 2f, y + h, 3f * k, 0.8f, Colors.mulAlpha(0x66FFFFFF, e), Colors.mulAlpha(0x33FFFFFF, e));
        text(s, x + pad, y + pad - 1f * k, sc, Colors.mulAlpha(0xFFFFFFFF, e));
    }

    /** Textured rectangle from the (u, v, w, h) part of a tw x th texel texture. */
    private void quad(ResourceLocation r, float x, float y, float w, float h, float u, float v, float uw, float vh,
                      float tw, float th, float alpha) {
        mc.getTextureManager().bindTexture(r);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.color(1f, 1f, 1f, alpha);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        wr.pos(x, y + h, 0).tex(u / tw, (v + vh) / th).endVertex();
        wr.pos(x + w, y + h, 0).tex((u + uw) / tw, (v + vh) / th).endVertex();
        wr.pos(x + w, y, 0).tex((u + uw) / tw, v / th).endVertex();
        wr.pos(x, y, 0).tex(u / tw, v / th).endVertex();
        t.draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Checkbox: outlined square that fills with the theme colour and shows a tick when on (on = 0..1). */
    private void drawBox(float x, float y, float size, float on, Theme th, float alpha) {
        int c = Colors.opaque(th.c1);
        float r = size * 0.3f;
        RenderUtil.roundedRect(x - 1f, y - 1f, x + size + 1f, y + size + 1f, r + 1f,
                Colors.mulAlpha(Colors.lerp(Colors.lerp(c, 0xFF1E2247, 0.55f), c, on), alpha));
        RenderUtil.roundedRect(x, y, x + size, y + size, r, Colors.mulAlpha(Colors.lerp(0xFF0C0E24, c, on), alpha));
        if (on > 0.02f) {
            Icons.tick(x + size / 2f, y + size / 2f, size * 0.9f, true, Colors.mulAlpha(0xFFFFFFFF, alpha * on));
        }
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scrollTarget = MathHelper.clamp_float(scrollTarget - Integer.signum(d) * 30f * k(), 0f, scrollMax());
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        float k = k();

        if (overBack(mouseX, mouseY)) {
            back();
            return;
        }
        if (overMaster(mouseX, mouseY)) {
            ClientSettings.cosmetics = !ClientSettings.cosmetics;
            Sounds.toggle(ClientSettings.cosmetics);
            return;
        }
        for (int i = 0; i < CAT_NAMES.length; i++) {
            if (overRailIcon(i, mouseX, mouseY)) {
                if (cat != i || !query.isEmpty()) {
                    cat = i;
                    query = "";
                    searchFocus = false;
                    refilter();
                    selectDefault();
                    Sounds.click();
                }
                return;
            }
        }
        float bx = gridX(), by = BAR_Y * k, bw = gridW(), bh = BAR_H * k;
        searchFocus = mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh;
        if (searchFocus) return;

        int t = tileAt(mouseX, mouseY);
        if (t >= 0) {
            Item it = shown.get(t);
            sel = it;
            it.setting.toggle();
            Sounds.toggle(it.setting.value);
            retarget();
            return;
        }
        if (sel != null) {
            float rowW = 10f * k + 5f * k + LumenFont.width("Equipped") * 0.9f * k;
            float rx = (previewLeft() + width) / 2f - rowW / 2f, ry = height - 15f * k;
            if (mouseX >= rx - 2f && mouseX <= rx + rowW + 2f && mouseY >= ry - 2f && mouseY <= ry + 12f * k) {
                sel.setting.toggle();
                Sounds.toggle(sel.setting.value);
                return;
            }
        }
        if (overPreview(mouseX, mouseY)) {
            dragging = true;
            autoYaw = false;
            lastDragX = mouseX;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long time) {
        if (dragging) {
            yaw += (mouseX - lastDragX) * 1.1f;
            lastDragX = mouseX;
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = false;
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            back();
            return;
        }
        if (keyCode == Keyboard.KEY_RETURN) {
            searchFocus = false;
            return;
        }
        if (keyCode == Keyboard.KEY_BACK) {
            if (!query.isEmpty()) {
                query = query.substring(0, query.length() - 1);
                searchFocus = true;
                refilter();
                selectDefault();
            }
            return;
        }
        if (ChatAllowedCharacters.isAllowedCharacter(typedChar) && query.length() < 24) {
            query += typedChar;
            searchFocus = true;
            refilter();
            selectDefault();
        }
    }

    private void back() {
        Sounds.click();
        mc.displayGuiScreen(parent);
    }
}
