package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;

/**
 * Toggles the blurry swaying aurora ribbons behind the main menu. The menu reads this module's
 * state and intensity when drawing; the module itself has no event handlers.
 */
public class AuroraBackground extends Module {
    public final NumberSetting intensity = add(new NumberSetting("Intensity %", 100, 20, 300, 10));

    public AuroraBackground() {
        super("Aurora Background", "Blurry swaying aurora stripes behind the main menu.", Category.VISUALS);
    }
}
