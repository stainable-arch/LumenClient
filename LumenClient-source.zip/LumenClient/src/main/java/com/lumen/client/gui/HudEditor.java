package com.lumen.client.gui;

import com.lumen.client.core.ConfigManager;
import com.lumen.client.core.HudModule;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;

/**
 * Full-screen HUD editor: the ClickGUI is hidden and every enabled HUD element can be dragged
 * around. The pencil button in the bottom-left corner (or Esc) goes back to the ClickGUI.
 */
public class HudEditor extends GuiScreen {
    static final float BTN = 22f, BTN_MARGIN = 8f;

    private HudModule dragging;
    private float offX, offY;
    private float fade;
    private long lastFrame = System.currentTimeMillis();

    /** Bottom-left button rectangle in GUI units (shared with the ClickGUI). */
    static float btnX() { return BTN_MARGIN; }

    static float btnY(int screenHeight) { return screenHeight - BTN_MARGIN - BTN; }

    /** Draws the pencil button; active = the editor is open (button stays lit). */
    static void drawButton(int screenHeight, int mouseX, int mouseY, float alpha, boolean active) {
        Theme th = Theme.current();
        float x = btnX(), y = btnY(screenHeight);
        boolean hover = mouseX >= x && mouseX <= x + BTN && mouseY >= y && mouseY <= y + BTN;
        int border = Colors.mulAlpha(Colors.opaque(active || hover ? th.c1 : Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), alpha);
        if (th.glass) {
            GlassFx.pane(x, y, x + BTN, y + BTN, 6f, alpha, active ? 1f : (hover ? 0.45f : 0f));
        } else {
            int fill = Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), active ? 0.30f : (hover ? 0.18f : 0.07f));
            GlassFx.classicPane(x, y, x + BTN, y + BTN, 6f, Colors.withAlpha(fill, 245), th.c1, th.c2,
                    active ? 1f : (hover ? 0.45f : 0f), alpha);
        }
        Icons.pencil(x + BTN / 2f, y + BTN / 2f, 13f, th, alpha);
    }

    static boolean overButton(int screenHeight, int mx, int my) {
        float x = btnX(), y = btnY(screenHeight);
        return mx >= x && mx <= x + BTN && my >= y && my <= y + BTN;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
    }

    @Override
    public void onGuiClosed() {
        ConfigManager.save();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        Theme th = Theme.current();
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // light dim so the HUD stays easy to read, with a faint theme tint at the bottom
        if (th.glass) {
            GlassFx.backdrop(width, height, e * 0.55f, now, false);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.bg), 110), e),
                    Colors.mulAlpha(Colors.withAlpha(Colors.lerp(Colors.opaque(th.bg), Colors.opaque(th.c3), 0.18f), 140), e));
        }

        if (!Mouse.isButtonDown(0)) {
            dragging = null;
        } else if (dragging != null) {
            dragging.x = Math.max(0, Math.min(width - dragging.scaledWidth(), mouseX - offX));
            dragging.y = Math.max(0, Math.min(height - dragging.scaledHeight(), mouseY - offY));
        }

        ScaledResolution sr = new ScaledResolution(mc);
        int count = 0;
        float pulse = 0.55f + 0.45f * (float) Math.sin(now / 350.0);
        for (Module m : ModuleManager.modules) {
            if (!m.isEnabled() || !(m instanceof HudModule)) continue;
            count++;
            ((HudModule) m).renderHud(sr);
        }
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        for (Module m : ModuleManager.modules) {
            if (!m.isEnabled() || !(m instanceof HudModule)) continue;
            HudModule h = (HudModule) m;
            float w = h.scaledWidth(), hh = h.scaledHeight();
            boolean inside = mouseX >= h.x && mouseX <= h.x + w && mouseY >= h.y && mouseY <= h.y + hh;
            boolean drag = dragging == h;
            int col = Colors.mulAlpha(Colors.withAlpha(th.c1, drag ? 255 : (inside ? (int) (255 * pulse) : 130)), e);
            RenderUtil.rectOutline(h.x - 1.5f, h.y - 1.5f, h.x + w + 1.5f, h.y + hh + 1.5f, 1f, col);
            if (inside || drag) {
                RenderUtil.string(h.name, h.x, h.y - 10f, Colors.mulAlpha(0xFFE8ECF4, e));
            }
        }

        String hint = count == 0
                ? "No HUD modules are enabled. Turn some on in the ClickGUI first."
                : "Drag the elements to move them";
        float hw = RenderUtil.width(hint);
        float hx = (width - hw) / 2f, hy = 10f;
        RenderUtil.roundedRect(hx - 8f, hy - 4f, hx + hw + 8f, hy + 14f, 6f, Colors.mulAlpha(0xB0000000, e));
        RenderUtil.string(hint, hx, hy, Colors.mulAlpha(0xFFFFFFFF, e));

        drawButton(height, mouseX, mouseY, e, true);
        RenderUtil.string("Click the pencil or press Esc to go back",
                btnX() + BTN + 8f, btnY(height) + (BTN - 8f) / 2f, Colors.mulAlpha(0xFFC8CEE6, e));

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button == 0 && overButton(height, mouseX, mouseY)) {
            back();
            return;
        }
        if (button != 0) return;
        for (int i = ModuleManager.modules.size() - 1; i >= 0; i--) {
            Module m = ModuleManager.modules.get(i);
            if (!(m instanceof HudModule) || !m.isEnabled()) continue;
            HudModule h = (HudModule) m;
            if (mouseX >= h.x && mouseX <= h.x + h.scaledWidth() && mouseY >= h.y && mouseY <= h.y + h.scaledHeight()) {
                dragging = h;
                offX = mouseX - h.x;
                offY = mouseY - h.y;
                return;
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            back();
        }
    }

    private void back() {
        Sounds.click();
        mc.displayGuiScreen(new ClickGui());
    }
}
