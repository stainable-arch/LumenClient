package com.lumen.client.fx;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

/**
 * Draws the custom particle sprites at runtime (so the jar needs no image files).
 * Cells are 64x64. Cells 0-3 are crisp white outlines (heart, star, sparkle, bubble; transparent
 * inside) and cells 4-7 are the matching soft glow versions. They are white so they can be tinted.
 * Each shape is drawn in the middle 32x32 of its cell, leaving a margin for the glow.
 */
public final class SpriteSheet {
    public static final int CELL = 64;
    public static final int SHAPES = 4;
    /** Total number of cells; sprite i has its glow at i + GLOW_OFFSET. */
    public static final int COUNT = SHAPES * 2;
    public static final int GLOW_OFFSET = SHAPES;

    private static final float MARGIN = 16f;

    private SpriteSheet() {}

    public static BufferedImage generate() {
        BufferedImage img = new BufferedImage(CELL * COUNT, CELL, BufferedImage.TYPE_INT_ARGB);
        Shape[] shapes = { heart(), star(), sparkle(), bubble() };

        for (int i = 0; i < SHAPES; i++) {
            // crisp outline
            Graphics2D g = img.createGraphics();
            hints(g);
            g.translate(i * CELL + MARGIN, MARGIN);
            g.setPaint(new Color(255, 255, 255));
            g.setStroke(new BasicStroke(2.3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(shapes[i]);
            g.dispose();

            // glow: a fat stroke, blurred a lot, over a faint radial haze
            BufferedImage cell = new BufferedImage(CELL, CELL, BufferedImage.TYPE_INT_ARGB);
            Graphics2D gg = cell.createGraphics();
            hints(gg);
            gg.setPaint(new RadialGradientPaint(new Point2D.Float(CELL / 2f, CELL / 2f), CELL * 0.46f,
                    new float[] { 0f, 1f },
                    new Color[] { new Color(255, 255, 255, 70), new Color(255, 255, 255, 0) }));
            gg.fill(new Ellipse2D.Float(0, 0, CELL, CELL));
            gg.translate(MARGIN, MARGIN);
            gg.setPaint(new Color(255, 255, 255));
            gg.setStroke(new BasicStroke(4.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            gg.draw(shapes[i]);
            gg.dispose();
            blurAlpha(cell, 5, 3);
            img.getGraphics().drawImage(cell, (GLOW_OFFSET + i) * CELL, 0, null);
        }

        // fully transparent pixels become white-transparent so linear filtering never darkens the edges
        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {
                int a = img.getRGB(x, y) >>> 24;
                img.setRGB(x, y, (a << 24) | 0xFFFFFF);
            }
        }
        return img;
    }

    private static void hints(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    /** Box-blurs only the alpha channel (the sprites are white), several passes = smooth falloff. */
    private static void blurAlpha(BufferedImage im, int radius, int passes) {
        int w = im.getWidth(), h = im.getHeight();
        float[] a = new float[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) a[y * w + x] = (im.getRGB(x, y) >>> 24) / 255f;
        }
        float[] tmp = new float[w * h];
        for (int pass = 0; pass < passes; pass++) {
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    float sum = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int xx = Math.max(0, Math.min(w - 1, x + k));
                        sum += a[y * w + xx];
                    }
                    tmp[y * w + x] = sum / (radius * 2 + 1);
                }
            }
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    float sum = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int yy = Math.max(0, Math.min(h - 1, y + k));
                        sum += tmp[yy * w + x];
                    }
                    a[y * w + x] = sum / (radius * 2 + 1);
                }
            }
        }
        // the blur spreads the stroke thin, so boost it back up
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int al = Math.min(255, Math.round(a[y * w + x] * 255f * 3.2f));
                im.setRGB(x, y, (al << 24) | 0xFFFFFF);
            }
        }
    }

    private static Shape heart() {
        Path2D.Float p = new Path2D.Float();
        p.moveTo(16, 28.5);
        p.curveTo(4, 20, 1.5, 11, 6.5, 7);
        p.curveTo(10.5, 3.4, 15, 5.5, 16, 9.8);
        p.curveTo(17, 5.5, 21.5, 3.4, 25.5, 7);
        p.curveTo(30.5, 11, 28, 20, 16, 28.5);
        p.closePath();
        return p;
    }

    private static Shape star() {
        Path2D.Float p = new Path2D.Float();
        double cx = 16, cy = 17, outer = 12.5, inner = 5.6;
        for (int i = 0; i < 10; i++) {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            double rad = (i % 2 == 0) ? outer : inner;
            float x = (float) (cx + Math.cos(ang) * rad);
            float y = (float) (cy + Math.sin(ang) * rad);
            if (i == 0) p.moveTo(x, y);
            else p.lineTo(x, y);
        }
        p.closePath();
        return p;
    }

    private static Shape sparkle() {
        Path2D.Float p = new Path2D.Float();
        p.moveTo(16, 3);
        p.quadTo(17.4, 14.6, 29, 16);
        p.quadTo(17.4, 17.4, 16, 29);
        p.quadTo(14.6, 17.4, 3, 16);
        p.quadTo(14.6, 14.6, 16, 3);
        p.closePath();
        return p;
    }

    private static Shape bubble() {
        return new Ellipse2D.Float(4.5f, 4.5f, 23, 23);
    }
}
