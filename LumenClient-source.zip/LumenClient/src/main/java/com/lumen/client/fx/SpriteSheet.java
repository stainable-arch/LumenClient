package com.lumen.client.fx;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.BasicStroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

/**
 * Draws the custom particle sprites at runtime (so the jar needs no image files).
 * Four 32x32 cells: heart, star, sparkle, bubble. They are whitish so they can be tinted.
 */
public final class SpriteSheet {
    public static final int CELL = 32;
    public static final int COUNT = 4;

    private SpriteSheet() {}

    public static BufferedImage generate() {
        BufferedImage img = new BufferedImage(CELL * COUNT, CELL, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        g.translate(0, 0);
        heart(g);
        g.translate(CELL, 0);
        star(g);
        g.translate(CELL, 0);
        sparkle(g);
        g.translate(CELL, 0);
        bubble(g);
        g.dispose();

        // fully transparent pixels become white-transparent so linear filtering never darkens the edges
        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {
                if ((img.getRGB(x, y) >>> 24) == 0) {
                    img.setRGB(x, y, 0x00FFFFFF);
                }
            }
        }
        return img;
    }

    private static RadialGradientPaint shade(float cx, float cy, float radius) {
        return new RadialGradientPaint(new Point2D.Float(cx, cy), radius,
                new float[] { 0f, 1f },
                new Color[] { new Color(255, 255, 255), new Color(222, 222, 230) });
    }

    private static void heart(Graphics2D g) {
        Path2D.Float p = new Path2D.Float();
        p.moveTo(16, 28.5);
        p.curveTo(4, 20, 1.5, 11, 6.5, 7);
        p.curveTo(10.5, 3.4, 15, 5.5, 16, 9.8);
        p.curveTo(17, 5.5, 21.5, 3.4, 25.5, 7);
        p.curveTo(30.5, 11, 28, 20, 16, 28.5);
        p.closePath();

        g.setPaint(new Color(206, 206, 216));
        g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(p);
        g.setPaint(shade(12, 11, 20));
        g.fill(p);

        g.setPaint(new Color(255, 255, 255, 235));
        g.fill(new Ellipse2D.Float(7.5f, 8f, 5.5f, 3.4f));
    }

    private static void star(Graphics2D g) {
        Path2D.Float p = new Path2D.Float();
        double cx = 16, cy = 17, outer = 12.5, inner = 5.6;
        for (int i = 0; i < 10; i++) {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            double rad = (i % 2 == 0) ? outer : inner;
            float x = (float) (cx + Math.cos(ang) * rad);
            float y = (float) (cy + Math.sin(ang) * rad);
            if (i == 0) p.moveTo(x, y);
            else p.lineTo(x, y);
        }
        p.closePath();

        g.setPaint(new Color(210, 210, 220));
        g.setStroke(new BasicStroke(3.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(p);
        g.setPaint(shade(14, 13, 16));
        g.fill(p);
        g.setPaint(new Color(255, 255, 255, 230));
        g.fill(new Ellipse2D.Float(12f, 10f, 4.5f, 3f));
    }

    private static void sparkle(Graphics2D g) {
        g.setPaint(new RadialGradientPaint(new Point2D.Float(16, 16), 10f,
                new float[] { 0f, 1f },
                new Color[] { new Color(255, 255, 255, 170), new Color(255, 255, 255, 0) }));
        g.fill(new Ellipse2D.Float(6, 6, 20, 20));

        Path2D.Float p = new Path2D.Float();
        p.moveTo(16, 1.5);
        p.quadTo(17.4, 14.6, 30.5, 16);
        p.quadTo(17.4, 17.4, 16, 30.5);
        p.quadTo(14.6, 17.4, 1.5, 16);
        p.quadTo(14.6, 14.6, 16, 1.5);
        p.closePath();
        g.setPaint(new Color(255, 255, 255));
        g.fill(p);
    }

    private static void bubble(Graphics2D g) {
        g.setPaint(new RadialGradientPaint(new Point2D.Float(16, 16), 12f,
                new float[] { 0f, 0.72f, 1f },
                new Color[] { new Color(255, 255, 255, 40), new Color(255, 255, 255, 95), new Color(255, 255, 255, 235) }));
        g.fill(new Ellipse2D.Float(4, 4, 24, 24));
        g.setPaint(new Color(255, 255, 255, 255));
        g.fill(new Ellipse2D.Float(9.5f, 8.5f, 6f, 3.8f));
    }
}
