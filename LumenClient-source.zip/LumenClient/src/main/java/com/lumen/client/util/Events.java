package com.lumen.client.util;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;

/**
 * Registers an object on both Forge event buses. On some 1.8.9-era Forge builds tick/input
 * events (net.minecraftforge.fml.common.gameevent.*) are posted on FMLCommonHandler's bus,
 * on others the two buses are the same object. Forge ignores a second register() of the same
 * object on the same bus, so doing both is safe either way.
 */
public final class Events {
    private Events() {}

    public static void register(Object o) {
        MinecraftForge.EVENT_BUS.register(o);
        FMLCommonHandler.instance().bus().register(o);
    }

    public static void unregister(Object o) {
        MinecraftForge.EVENT_BUS.unregister(o);
        FMLCommonHandler.instance().bus().unregister(o);
    }
}
