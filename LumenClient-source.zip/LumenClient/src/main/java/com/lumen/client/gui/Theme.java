package com.lumen.client.gui;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A colour theme used by the ClickGUI, the aurora background and HUD accents. */
public final class Theme {
    public final String name;
    /** Three accent colours (RGB, no alpha) used for gradients and the aurora ribbons. */
    public final int c1, c2, c3;
    /** Base colour of the dimmed GUI background. */
    public final int bg;
    /** Frosted "liquid glass" look: the ClickGUI draws translucent panels with rims and soft light. */
    public final boolean glass;

    private Theme(String name, int c1, int c2, int c3, int bg) {
        this(name, c1, c2, c3, bg, false);
    }

    private Theme(String name, int c1, int c2, int c3, int bg, boolean glass) {
        this.glass = glass;
        this.name = name;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.bg = bg;
    }

    public static final List<Theme> ALL = Collections.unmodifiableList(Arrays.asList(
            new Theme("Aurora", 0x3DFFB0, 0x38C8FF, 0xA070FF, 0x050A1A),
            new Theme("Sunset", 0xFFB070, 0xFF5E8E, 0x9A6CFF, 0x160812),
            new Theme("Ocean", 0x3FE4FF, 0x3A8CFF, 0x7C6CFF, 0x04101C),
            new Theme("Sakura", 0xFFD2E4, 0xFF8EC2, 0xCBA8FF, 0x180A14),
            new Theme("Toxic", 0xD6FF4A, 0x3AE68A, 0x18C4B2, 0x06120C),
            new Theme("Ember", 0xFFDA52, 0xFF8A20, 0xFF3C5C, 0x160A06),
            new Theme("Mono", 0xFFFFFF, 0xC4CBD6, 0x8A94A6, 0x0A0A0C),
            new Theme("Midnight", 0x7C9BFF, 0x9C7CFF, 0xFF7CDC, 0x070914),
            new Theme("Rose Gold", 0xFFCBAA, 0xF29EA0, 0xDDA6FF, 0x160C0F),
            new Theme("Crimson", 0xFF5C70, 0xFF2E7C, 0xB22EFF, 0x14060A),
            new Theme("Liquid Glass", 0xEDEFF5, 0xFFFFFF, 0xCFC9E4, 0x101115, true)
    ));

    private static int index = 0;

    public static Theme current() {
        return ALL.get(index);
    }

    public static int index() {
        return index;
    }

    public static void set(int i) {
        index = Math.max(0, Math.min(ALL.size() - 1, i));
    }

    public static void setByName(String name) {
        for (int i = 0; i < ALL.size(); i++) {
            if (ALL.get(i).name.equalsIgnoreCase(name)) {
                index = i;
                return;
            }
        }
    }
}
