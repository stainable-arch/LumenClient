package com.lumen.client.gui;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A colour theme used by the ClickGUI, the aurora background and HUD accents. */
public final class Theme {
    public final String name;
    /** Three accent colours (RGB, no alpha) used for gradients and the aurora ribbons. */
    public final int c1, c2, c3;
    /** Base colour of the dimmed GUI background. */
    public final int bg;

    private Theme(String name, int c1, int c2, int c3, int bg) {
        this.name = name;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.bg = bg;
    }

    public static final List<Theme> ALL = Collections.unmodifiableList(Arrays.asList(
            new Theme("Aurora", 0x3DFFB0, 0x38C8FF, 0xA070FF, 0x050A1A),
            new Theme("Sunset", 0xFF8A5C, 0xFF4F9A, 0x8A5CFF, 0x160812),
            new Theme("Ocean", 0x2EE6FF, 0x3A7BFF, 0x6A5CFF, 0x04101C),
            new Theme("Sakura", 0xFFC2DB, 0xFF7EB6, 0xC9A6FF, 0x180A14),
            new Theme("Toxic", 0xC8FF3B, 0x2DE17B, 0x14B8A6, 0x06120C),
            new Theme("Ember", 0xFFD23F, 0xFF7A18, 0xFF2D55, 0x160A06),
            new Theme("Mono", 0xFFFFFF, 0xB8C0CC, 0x7A8494, 0x0A0A0C)
    ));

    private static int index = 0;

    public static Theme current() {
        return ALL.get(index);
    }

    public static int index() {
        return index;
    }

    public static void set(int i) {
        index = Math.max(0, Math.min(ALL.size() - 1, i));
    }

    public static void setByName(String name) {
        for (int i = 0; i < ALL.size(); i++) {
            if (ALL.get(i).name.equalsIgnoreCase(name)) {
                index = i;
                return;
            }
        }
    }
}
