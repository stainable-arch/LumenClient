package com.lumen.client.util;

import com.lumen.client.ClientSettings;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.resources.IReloadableResourceManager;
import net.minecraft.util.BlockPos;
import net.minecraft.world.IBlockAccess;

import java.lang.reflect.Field;

/**
 * Backs the "Render Foliage" option: while it is off, grass, ferns, flowers and double plants are skipped when
 * chunks are built. It swaps the client's block render dispatcher for a subclass that skips those blocks.
 * If that swap is not possible the option simply does nothing.
 */
public final class FoliageFilter extends BlockRendererDispatcher {
    private FoliageFilter(BlockRendererDispatcher orig, Minecraft mc) {
        super(orig.getBlockModelShapes(), mc.gameSettings);
    }

    /** Installs the filter (once). Call after the client has finished loading. */
    public static void install() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.getBlockRendererDispatcher() instanceof FoliageFilter) return;
            Field target = null;
            for (Field f : Minecraft.class.getDeclaredFields()) { // found by type, so it works with any mappings
                if (f.getType() == BlockRendererDispatcher.class) {
                    target = f;
                    break;
                }
            }
            if (target == null) return;
            target.setAccessible(true);
            FoliageFilter filter = new FoliageFilter(mc.getBlockRendererDispatcher(), mc);
            filter.onResourceManagerReload(mc.getResourceManager());
            target.set(mc, filter);
            if (mc.getResourceManager() instanceof IReloadableResourceManager) {
                ((IReloadableResourceManager) mc.getResourceManager()).registerReloadListener(filter);
            }
        } catch (Throwable ignored) {
            // option stays without effect
        }
    }

    /** Rebuilds all loaded chunks so a change of the option shows up right away. */
    public static void refresh() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.renderGlobal != null && mc.theWorld != null) mc.renderGlobal.loadRenderers();
    }

    private static boolean isFoliage(Block b) {
        return b instanceof BlockTallGrass || b instanceof BlockFlower || b instanceof BlockDoublePlant;
    }

    @Override
    public boolean renderBlock(IBlockState state, BlockPos pos, IBlockAccess world, WorldRenderer renderer) {
        if (!ClientSettings.renderFoliage.value && isFoliage(state.getBlock())) return false;
        return super.renderBlock(state, pos, world, renderer);
    }
}
