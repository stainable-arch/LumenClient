package com.lumen.client.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.util.CloudClient;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Config cloud: browse public configs from everyone, keep your own (public or private), load one
 * with a click and upload your current setup. Styled like the rest of Lumen (themed, text in the Lumen font).
 */
public class CloudScreen extends GuiScreen {
    private static final float ROW_H = 26f;
    private static final float BTN = 22f, BTN_MARGIN = 8f;

    // ---- the bottom-right cloud button used by the ClickGUI ----
    static float btnX(int screenWidth) { return screenWidth - BTN_MARGIN - BTN; }

    static float btnY(int screenHeight) { return screenHeight - BTN_MARGIN - BTN; }

    static void drawButton(int sw, int sh, int mouseX, int mouseY, float alpha) {
        Theme th = Theme.current();
        float x = btnX(sw), y = btnY(sh);
        boolean hover = overButton(sw, sh, mouseX, mouseY);
        int border = Colors.mulAlpha(Colors.opaque(hover ? th.c1 : Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), alpha);
        if (th.glass) {
            GlassFx.pane(x, y, x + BTN, y + BTN, 6f, alpha, hover ? 0.45f : 0f);
        } else {
            RenderUtil.roundedRect(x - 1f, y - 1f, x + BTN + 1f, y + BTN + 1f, 7f, border);
            int fill = Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), hover ? 0.18f : 0.07f);
            RenderUtil.roundedRect(x, y, x + BTN, y + BTN, 6f, Colors.mulAlpha(Colors.withAlpha(fill, 245), alpha));
        }
        Icons.cloud(x + BTN / 2f, y + BTN / 2f + 0.5f, 14f, th, alpha);
    }

    static boolean overButton(int sw, int sh, int mx, int my) {
        float x = btnX(sw), y = btnY(sh);
        return mx >= x && mx <= x + BTN && my >= y && my <= y + BTN;
    }

    // ---- data ----
    private static final class Row {
        String id, name, author, description, visibility;
        int downloads;
    }

    /** A clickable rectangle registered while drawing. */
    private static final class Btn {
        final int id;
        final float x, y, w, h;

        Btn(int id, float x, float y, float w, float h) {
            this.id = id;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        boolean contains(float mx, float my) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h;
        }
    }

    private static final int A_BROWSE = 1, A_MINE = 2, A_REFRESH = 3, A_LOAD = 4, A_DELETE = 5, A_VIS = 6,
            A_UPLOAD = 7, A_CLOSE = 8;

    private final GuiScreen parent;
    private final List<Row> rows = new ArrayList<Row>();
    private final List<Btn> btns = new ArrayList<Btn>();
    private boolean mine;
    private boolean loading;
    private boolean uploadPublic = true;
    private int selected = -1;
    private int scroll;
    private String status = "";
    private int statusColor = 0xFF9AA3BD;
    private float fade;
    private long last = System.currentTimeMillis();

    private GuiTextField search, nameField, descField;

    // layout (recomputed each frame)
    private float px, py, pw, ph, lx, ly, lw, lh;

    public CloudScreen(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        String s = search == null ? "" : search.getText();
        String n = nameField == null ? "" : nameField.getText();
        String d = descField == null ? "" : descField.getText();
        search = field(40, s);
        nameField = field(32, n);
        descField = field(80, d);
        if (rows.isEmpty() && !loading) refresh();
    }

    private GuiTextField field(int max, String text) {
        GuiTextField f = new GuiTextField(0, fontRendererObj, 0, 0, 10, 10);
        f.setEnableBackgroundDrawing(false);
        f.setMaxStringLength(max);
        f.setText(text);
        return f;
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void setStatus(String s, boolean error) {
        status = s;
        statusColor = error ? 0xFFFF7B7B : 0xFF8FE3A0;
    }

    private void info(String s) {
        status = s;
        statusColor = 0xFF9AA3BD;
    }

    private void refresh() {
        if (!CloudClient.configured()) {
            setStatus("No cloud server set. Type /lumen cloud url <address> in chat.", true);
            return;
        }
        loading = true;
        selected = -1;
        scroll = 0;
        info("Loading...");
        CloudClient.list(search.getText().trim(), mine, new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                loading = false;
                rows.clear();
                if (error != null) {
                    setStatus(error, true);
                    return;
                }
                JsonArray arr = result.isJsonArray() ? result.getAsJsonArray()
                        : (result.isJsonObject() && result.getAsJsonObject().has("configs")
                        ? result.getAsJsonObject().getAsJsonArray("configs") : new JsonArray());
                for (JsonElement el : arr) {
                    if (!el.isJsonObject()) continue;
                    JsonObject o = el.getAsJsonObject();
                    Row r = new Row();
                    r.id = str(o, "id");
                    r.name = str(o, "name");
                    r.author = str(o, "author");
                    r.description = str(o, "description");
                    r.visibility = str(o, "visibility");
                    r.downloads = o.has("downloads") ? o.get("downloads").getAsInt() : 0;
                    rows.add(r);
                }
                info(rows.size() + (rows.size() == 1 ? " config" : " configs"));
            }
        });
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    private void act(int id) {
        switch (id) {
            case A_BROWSE:
                if (mine) {
                    mine = false;
                    rows.clear();
                    refresh();
                }
                break;
            case A_MINE:
                if (!mine) {
                    mine = true;
                    rows.clear();
                    refresh();
                }
                break;
            case A_REFRESH:
                refresh();
                break;
            case A_VIS:
                uploadPublic = !uploadPublic;
                break;
            case A_CLOSE:
                mc.displayGuiScreen(parent);
                break;
            case A_LOAD:
                loadSelected();
                break;
            case A_DELETE:
                deleteSelected();
                break;
            case A_UPLOAD:
                upload();
                break;
            default:
                break;
        }
    }

    private void loadSelected() {
        if (selected < 0 || selected >= rows.size()) return;
        final Row r = rows.get(selected);
        info("Downloading " + r.name + "...");
        CloudClient.get(r.id, new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (error != null) {
                    setStatus(error, true);
                    return;
                }
                try {
                    JsonObject o = result.getAsJsonObject();
                    JsonObject data = o.has("data") ? o.getAsJsonObject("data") : o;
                    ConfigManager.importShared(data);
                    setStatus("Loaded \"" + r.name + "\"", false);
                } catch (Exception ex) {
                    setStatus("That config is invalid", true);
                }
            }
        });
    }

    private void deleteSelected() {
        if (selected < 0 || selected >= rows.size() || !mine) return;
        final Row r = rows.get(selected);
        CloudClient.delete(r.id, new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (error != null) {
                    setStatus(error, true);
                } else {
                    refresh();
                    setStatus("Deleted \"" + r.name + "\"", false);
                }
            }
        });
    }

    private void upload() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            setStatus("Give your config a name first", true);
            return;
        }
        info("Uploading...");
        final boolean pub = uploadPublic;
        CloudClient.upload(name, descField.getText().trim(), pub, ConfigManager.buildJson(true), new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (error != null) {
                    setStatus(error, true);
                } else {
                    if (mine) refresh();
                    setStatus("Uploaded (" + (pub ? "public" : "private") + ")", false);
                }
            }
        });
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static float tw(String s, float sc) {
        return LumenFont.width(s) * sc;
    }

    private static void text(String s, float x, float y, float sc, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(sc, sc, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    /** Text vertically centred in a box of the given height. */
    private static void textMid(String s, float x, float y, float h, float sc, int color) {
        text(s, x, y + (h - LumenFont.EM * sc) / 2f - 0.5f, sc, color);
    }

    private Btn button(int id, float x, float y, float w, float h, String label, boolean active, boolean enabled, int mx, int my, float e) {
        Theme th = Theme.current();
        Btn b = new Btn(id, x, y, w, h);
        boolean hov = enabled && b.contains(mx, my);
        if (enabled) btns.add(b);
        int c1 = Colors.opaque(th.c1), c3 = Colors.opaque(th.c3);
        int base = Colors.lerp(0xFF10132B, c3, active ? 0.35f : hov ? 0.22f : 0.08f);
        int edge = active || hov ? c1 : Colors.lerp(c1, 0xFF1E2247, 0.7f);
        if (th.glass) {
            GlassFx.pane(x, y, x + w, y + h, 4f, enabled ? e : e * 0.45f, active ? 1f : hov ? 0.4f : 0f);
        } else {
            RenderUtil.roundedRect(x - 1, y - 1, x + w + 1, y + h + 1, 5f, Colors.mulAlpha(Colors.withAlpha(edge, enabled ? 255 : 90), e));
            RenderUtil.roundedRect(x, y, x + w, y + h, 4f, Colors.mulAlpha(Colors.withAlpha(base, 250), e));
        }
        float sc = 0.85f;
        int col = enabled ? 0xFFFFFFFF : 0xFF626A85;
        textMid(label, x + (w - tw(label, sc)) / 2f, y, h, sc, Colors.mulAlpha(col, e));
        return b;
    }

    private void box(GuiTextField f, float x, float y, float w, float h, String placeholder, float e) {
        Theme th = Theme.current();
        int c1 = Colors.opaque(th.c1);
        boolean foc = f.isFocused();
        if (th.glass) {
            RenderUtil.roundedRect(x, y, x + w, y + h, 4f, Colors.mulAlpha(0x66050B18, e));
            GlassFx.pane(x, y, x + w, y + h, 4f, e, foc ? 0.7f : 0f);
        } else {
            RenderUtil.roundedRect(x - 1, y - 1, x + w + 1, y + h + 1, 5f,
                    Colors.mulAlpha(foc ? c1 : Colors.lerp(c1, 0xFF1E2247, 0.75f), e));
            RenderUtil.roundedRect(x, y, x + w, y + h, 4f, Colors.mulAlpha(0xF2080A1A, e));
        }
        f.xPosition = (int) (x + 6);
        f.yPosition = (int) y;
        f.width = (int) (w - 12);
        f.height = (int) h;
        if (f.getText().isEmpty() && !foc) {
            textMid(placeholder, x + 6, y, h, 0.85f, Colors.mulAlpha(0xFF566080, e));
        }
        f.drawTextBox();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        Theme th = Theme.current();
        int c1 = Colors.opaque(th.c1), c3 = Colors.opaque(th.c3);
        btns.clear();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // backdrop
        int tint = Colors.lerp(c3, c1, 0.4f);
        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, true);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.12f));
        }

        // panel
        pw = Math.min(width - 20f, 440f);
        ph = Math.min(height - 16f, 330f);
        px = (width - pw) / 2f;
        py = (height - ph) / 2f + (1f - e) * 6f;
        if (th.glass) {
            RenderUtil.roundedRect(px - 4f, py - 2f, px + pw + 4f, py + ph + 5f, 12f, Colors.mulAlpha(0x22000000, e));
            GlassFx.pane(px, py, px + pw, py + ph, 8f, e, 0f);
        } else {
            RenderUtil.roundedRectH(px - 1, py - 1, px + pw + 1, py + ph + 1, 8f,
                    Colors.mulAlpha(Colors.withAlpha(c1, 150), e), Colors.mulAlpha(Colors.withAlpha(c3, 150), e));
            RenderUtil.roundedRect(px, py, px + pw, py + ph, 7f, Colors.mulAlpha(0xF40A0C1E, e));
        }

        // header
        Icons.cloud(px + 22, py + 18, 16f, th, e);
        text("Config Cloud", px + 38, py + 9, 1.25f, Colors.mulAlpha(0xFFFFFFFF, e));
        float cx2 = px + pw - 20;
        button(A_CLOSE, cx2, py + 8, 12, 12, "x", false, true, mx, my, e);
        RenderUtil.gradientH(px + 14, py + 28, px + pw - 14, py + 29, Colors.mulAlpha(Colors.withAlpha(c1, 200), e), Colors.mulAlpha(Colors.withAlpha(c3, 40), e));

        // tabs + refresh + search
        float ty = py + 36;
        button(A_BROWSE, px + 14, ty, 64, 18, "Browse", !mine, true, mx, my, e);
        button(A_MINE, px + 82, ty, 84, 18, "My Configs", mine, true, mx, my, e);
        button(A_REFRESH, px + pw - 14 - 58, ty, 58, 18, "Refresh", false, !loading, mx, my, e);
        if (!mine) {
            float sx = px + 174;
            box(search, sx, ty, px + pw - 14 - 58 - 6 - sx, 18, "Search configs", e);
        }

        // list
        lx = px + 14;
        ly = py + 62;
        lw = pw - 28;
        lh = ph - 62 - 92;
        RenderUtil.roundedRect(lx, ly, lx + lw, ly + lh, 5f, Colors.mulAlpha(th.glass ? 0x40050B18 : 0x66000000, e));
        int visible = Math.max(1, (int) (lh / ROW_H));
        int max = Math.max(0, rows.size() - visible);
        scroll = Math.max(0, Math.min(max, scroll));
        RenderUtil.scissor(lx, ly, lw, lh);
        for (int n = 0; n < visible && n + scroll < rows.size(); n++) {
            int i = n + scroll;
            Row r = rows.get(i);
            float y = ly + n * ROW_H;
            boolean sel = i == selected;
            boolean hov = mx >= lx && mx <= lx + lw && my >= y && my < y + ROW_H && my >= ly && my < ly + lh;
            if (sel) {
                RenderUtil.roundedRectH(lx + 2, y + 1, lx + lw - 8, y + ROW_H - 1, 4f,
                        Colors.mulAlpha(Colors.withAlpha(c1, 80), e), Colors.mulAlpha(Colors.withAlpha(c3, 45), e));
            } else if (hov) {
                RenderUtil.roundedRect(lx + 2, y + 1, lx + lw - 8, y + ROW_H - 1, 4f, Colors.mulAlpha(0x22FFFFFF, e));
            }
            float right = lx + lw - 14;
            String meta = mine ? ("private".equals(r.visibility) ? "Private" : "Public") : "by " + r.author;
            int metaCol = mine ? ("private".equals(r.visibility) ? 0xFFF2C46B : 0xFF8FE3A0) : 0xFFAAB3CC;
            text(meta, right - tw(meta, 0.8f), y + 3, 0.8f, Colors.mulAlpha(metaCol, e));
            text(LumenFont.trim(r.name, (lw - 40 - tw(meta, 0.8f)) / 0.95f), lx + 9, y + 3, 0.95f, Colors.mulAlpha(0xFFFFFFFF, e));
            String loads = r.downloads + (r.downloads == 1 ? " load" : " loads");
            text(loads, right - tw(loads, 0.72f), y + 14, 0.72f, Colors.mulAlpha(0xFF6C7692, e));
            String sub = r.description.isEmpty() ? "No description" : r.description;
            text(LumenFont.trim(sub, (lw - 50 - tw(loads, 0.72f)) / 0.72f), lx + 9, y + 14, 0.72f, Colors.mulAlpha(0xFF8C96B4, e));
        }
        RenderUtil.endScissor();
        if (rows.isEmpty()) {
            String msg = loading ? "Loading..." : (mine ? "You have no saved configs yet" : "No configs found");
            text(msg, px + (pw - tw(msg, 0.9f)) / 2f, ly + lh / 2f - 4, 0.9f, Colors.mulAlpha(0xFF7A84A0, e));
        }
        if (max > 0) {
            float th2 = Math.max(14f, lh * visible / rows.size());
            float ty2 = ly + (lh - th2) * scroll / max;
            RenderUtil.roundedRect(lx + lw - 6, ty2, lx + lw - 3, ty2 + th2, 1.5f, Colors.mulAlpha(Colors.withAlpha(c1, 190), e));
        }

        // actions + status
        float by = ly + lh + 8;
        button(A_LOAD, lx, by, 64, 18, "Load", false, selected >= 0, mx, my, e);
        if (mine) button(A_DELETE, lx + 68, by, 64, 18, "Delete", false, selected >= 0, mx, my, e);
        float sx = lx + (mine ? 140 : 72);
        textMid(LumenFont.trim(status, (lx + lw - sx) / 0.8f), sx, by, 18, 0.8f, Colors.mulAlpha(statusColor, e));

        // upload
        float uy = by + 24;
        text("Upload your current setup", lx, uy, 0.75f, Colors.mulAlpha(0xFF8C96B4, e));
        float fy = uy + 12;
        float nameW = 104;
        float upW = 88, visW = 58;
        float descX = lx + nameW + 6;
        float descW = lw - nameW - 6 - upW - visW - 12;
        box(nameField, lx, fy, nameW, 18, "Name", e);
        box(descField, descX, fy, descW, 18, "Description", e);
        button(A_VIS, descX + descW + 6, fy, visW, 18, uploadPublic ? "Public" : "Private", false, true, mx, my, e);
        button(A_UPLOAD, lx + lw - upW, fy, upW, 18, "Upload", true, true, mx, my, e);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    @Override
    public void updateScreen() {
        search.updateCursorCounter();
        nameField.updateCursorCounter();
        descField.updateCursorCounter();
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) {
            mc.displayGuiScreen(parent);
            return;
        }
        if (search.isFocused()) {
            if (key == Keyboard.KEY_RETURN) {
                refresh();
            } else {
                search.textboxKeyTyped(c, key);
            }
            return;
        }
        if (nameField.isFocused()) {
            nameField.textboxKeyTyped(c, key);
        } else if (descField.isFocused()) {
            if (key == Keyboard.KEY_RETURN) upload();
            else descField.textboxKeyTyped(c, key);
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        if (!mine) search.mouseClicked(mx, my, button);
        nameField.mouseClicked(mx, my, button);
        descField.mouseClicked(mx, my, button);
        if (button != 0) return;
        for (Btn b : btns) {
            if (b.contains(mx, my)) {
                Sounds.click();
                act(b.id);
                return;
            }
        }
        if (mx >= lx && mx <= lx + lw && my >= ly && my < ly + lh) {
            int i = (int) ((my - ly) / ROW_H) + scroll;
            if (i >= 0 && i < rows.size()) selected = i;
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scroll += d < 0 ? 1 : -1;
    }
}
