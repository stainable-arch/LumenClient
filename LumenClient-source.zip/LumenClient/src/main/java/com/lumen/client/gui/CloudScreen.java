package com.lumen.client.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.lumen.client.ClientSettings;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.util.CloudClient;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Config cloud. Three simple views:
 * <ul>
 * <li>LIST: browse everyone's configs or your own; every row has its own Load button (and Delete in "My Configs").</li>
 * <li>SHARE: a small form to upload your current setup (name, optional description, public/private).</li>
 * <li>SETUP: paste the server address once, right in the GUI (no chat command needed).</li>
 * </ul>
 */
public class CloudScreen extends GuiScreen {
    private static final float ROW_H = 30f;
    private static final float BTN = 22f, BTN_MARGIN = 8f;
    private static final long SEARCH_DELAY_MS = 450L;
    private static final long CONFIRM_MS = 3000L;

    // ---- the bottom-right cloud button used by the ClickGUI ----
    static float btnX(int screenWidth) { return screenWidth - BTN_MARGIN - BTN; }

    static float btnY(int screenHeight) { return screenHeight - BTN_MARGIN - BTN; }

    static void drawButton(int sw, int sh, int mouseX, int mouseY, float alpha) {
        Theme th = Theme.current();
        float x = btnX(sw), y = btnY(sh);
        boolean hover = overButton(sw, sh, mouseX, mouseY);
        int border = Colors.mulAlpha(Colors.opaque(hover ? th.c1 : Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), alpha);
        if (th.glass) {
            GlassFx.pane(x, y, x + BTN, y + BTN, 6f, alpha, hover ? 0.45f : 0f);
        } else {
            RenderUtil.roundedRect(x - 1f, y - 1f, x + BTN + 1f, y + BTN + 1f, 7f, border);
            int fill = Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), hover ? 0.18f : 0.07f);
            RenderUtil.roundedRect(x, y, x + BTN, y + BTN, 6f, Colors.mulAlpha(Colors.withAlpha(fill, 245), alpha));
        }
        Icons.cloud(x + BTN / 2f, y + BTN / 2f + 0.5f, 14f, th, alpha);
    }

    static boolean overButton(int sw, int sh, int mx, int my) {
        float x = btnX(sw), y = btnY(sh);
        return mx >= x && mx <= x + BTN && my >= y && my <= y + BTN;
    }

    // ---- data ----
    private static final class Row {
        String id, name, author, description, visibility;
        int downloads;
    }

    /** A clickable rectangle registered while drawing. {@code arg} carries the row index for row buttons. */
    private static final class Btn {
        final int id, arg;
        final float x, y, w, h;

        Btn(int id, int arg, float x, float y, float w, float h) {
            this.id = id;
            this.arg = arg;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        boolean contains(float mx, float my) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h;
        }
    }

    private enum Mode { LIST, SHARE, SETUP }

    private static final int A_BROWSE = 1, A_MINE = 2, A_RETRY = 3, A_LOAD = 4, A_DELETE = 5, A_PUBLIC = 6,
            A_PRIVATE = 7, A_UPLOAD = 8, A_CLOSE = 9, A_SHARE = 10, A_BACK = 11, A_SERVER = 12, A_CONNECT = 13;

    private static final int GRAY = 0xFF9AA3BD, GREEN = 0xFF8FE3A0, RED = 0xFFFF7B7B, AMBER = 0xFFF2C46B;

    private final GuiScreen parent;
    private final List<Row> rows = new ArrayList<Row>();
    private final List<Btn> btns = new ArrayList<Btn>();
    private Mode mode = Mode.LIST;
    private boolean mine;
    private boolean loading;
    private String listError;
    private int reqId;
    private boolean uploadPublic = true;
    private int scroll;
    private int confirmDelete = -1;
    private long confirmAt;
    private boolean searchDirty;
    private long searchAt;
    private String status = "";
    private int statusColor = GRAY;
    private float fade;
    private long last = System.currentTimeMillis();

    private GuiTextField search, nameField, descField, urlField;

    // layout (recomputed each frame)
    private float px, py, pw, ph, lx, ly, lw, lh;

    public CloudScreen(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        search = field(40, search == null ? "" : search.getText());
        nameField = field(32, nameField == null ? "" : nameField.getText());
        descField = field(80, descField == null ? "" : descField.getText());
        urlField = field(120, urlField == null ? ClientSettings.cloudUrl : urlField.getText());
        if (!CloudClient.configured()) {
            openSetup();
        } else if (mode == Mode.LIST && rows.isEmpty() && !loading && listError == null) {
            refresh();
        }
    }

    private GuiTextField field(int max, String text) {
        GuiTextField f = new GuiTextField(0, fontRendererObj, 0, 0, 10, 10);
        f.setEnableBackgroundDrawing(false);
        f.setMaxStringLength(max);
        f.setText(text);
        return f;
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void setStatus(String s, boolean error) {
        status = s;
        statusColor = error ? RED : GREEN;
    }

    private void info(String s) {
        status = s;
        statusColor = GRAY;
    }

    private void focusOnly(GuiTextField f) {
        search.setFocused(f == search);
        nameField.setFocused(f == nameField);
        descField.setFocused(f == descField);
        urlField.setFocused(f == urlField);
    }

    // ------------------------------------------------------------------------------------------
    // views
    // ------------------------------------------------------------------------------------------

    private void openList() {
        mode = Mode.LIST;
        focusOnly(null);
        info("");
    }

    private void openShare() {
        if (!CloudClient.configured()) {
            openSetup();
            return;
        }
        mode = Mode.SHARE;
        focusOnly(nameField);
        info("");
    }

    private void openSetup() {
        mode = Mode.SETUP;
        urlField.setText(ClientSettings.cloudUrl);
        focusOnly(urlField);
        info("");
    }

    /** Goes one step back: out of a form into the list, or closes the screen from the list. */
    private void back() {
        if (mode == Mode.LIST) {
            mc.displayGuiScreen(parent);
        } else if (mode == Mode.SETUP && !CloudClient.configured()) {
            mc.displayGuiScreen(parent);
        } else {
            openList();
            if (rows.isEmpty() && !loading && listError == null) refresh();
        }
    }

    // ------------------------------------------------------------------------------------------
    // actions
    // ------------------------------------------------------------------------------------------

    private void refresh() {
        if (!CloudClient.configured()) {
            openSetup();
            return;
        }
        loading = true;
        listError = null;
        scroll = 0;
        confirmDelete = -1;
        searchDirty = false;
        info("");
        final int my = ++reqId;
        CloudClient.list(search.getText().trim(), mine, new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (my != reqId) return; // an older request, ignore
                loading = false;
                rows.clear();
                if (error != null) {
                    listError = friendly(error);
                    return;
                }
                JsonArray arr = result.isJsonArray() ? result.getAsJsonArray()
                        : (result.isJsonObject() && result.getAsJsonObject().has("configs")
                        ? result.getAsJsonObject().getAsJsonArray("configs") : new JsonArray());
                for (JsonElement el : arr) {
                    if (!el.isJsonObject()) continue;
                    JsonObject o = el.getAsJsonObject();
                    Row r = new Row();
                    r.id = str(o, "id");
                    r.name = str(o, "name");
                    r.author = str(o, "author");
                    r.description = str(o, "description");
                    r.visibility = str(o, "visibility");
                    r.downloads = o.has("downloads") && !o.get("downloads").isJsonNull() ? o.get("downloads").getAsInt() : 0;
                    rows.add(r);
                }
            }
        });
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    /** Turns raw network errors into something a player can act on. */
    private static String friendly(String err) {
        String l = err.toLowerCase();
        if (l.contains("unknownhost") || l.contains("connect") || l.contains("timed out") || l.contains("refused")) {
            return "Can't reach the cloud server. Check your connection or the server address.";
        }
        return err;
    }

    private void act(int id, int arg) {
        switch (id) {
            case A_BROWSE:
                switchTab(false);
                break;
            case A_MINE:
                switchTab(true);
                break;
            case A_RETRY:
                refresh();
                break;
            case A_PUBLIC:
                uploadPublic = true;
                break;
            case A_PRIVATE:
                uploadPublic = false;
                break;
            case A_CLOSE:
                mc.displayGuiScreen(parent);
                break;
            case A_BACK:
                back();
                break;
            case A_SHARE:
                openShare();
                break;
            case A_SERVER:
                openSetup();
                break;
            case A_CONNECT:
                connect();
                break;
            case A_LOAD:
                load(arg);
                break;
            case A_DELETE:
                delete(arg);
                break;
            case A_UPLOAD:
                upload();
                break;
            default:
                break;
        }
    }

    /** Clicking the tab you are already on just reloads it. */
    private void switchTab(boolean toMine) {
        if (mine != toMine) {
            mine = toMine;
            rows.clear();
        }
        info("");
        refresh();
    }

    private void connect() {
        String u = urlField.getText().trim();
        if (u.isEmpty()) {
            setStatus("Paste the server address first", true);
            return;
        }
        if (!u.toLowerCase().startsWith("http://") && !u.toLowerCase().startsWith("https://")) u = "https://" + u;
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (u.length() < 9 || u.indexOf('.') < 0 && !u.toLowerCase().contains("localhost")) {
            setStatus("That doesn't look like a server address", true);
            return;
        }
        if (!u.equals(ClientSettings.cloudUrl)) {
            ClientSettings.cloudUrl = u;
            CloudClient.signOut();
            ConfigManager.save();
            rows.clear();
        }
        mine = false;
        openList();
        refresh();
    }

    private void load(int i) {
        if (i < 0 || i >= rows.size()) return;
        final Row r = rows.get(i);
        info("Loading \"" + r.name + "\"...");
        CloudClient.get(r.id, new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (error != null) {
                    setStatus(friendly(error), true);
                    return;
                }
                try {
                    JsonObject o = result.getAsJsonObject();
                    JsonObject data = o.has("data") ? o.getAsJsonObject("data") : o;
                    ConfigManager.importShared(data);
                    setStatus("Applied \"" + r.name + "\" to your client", false);
                } catch (Exception ex) {
                    setStatus("That config couldn't be read", true);
                }
            }
        });
    }

    /** Two clicks: the first arms the button ("Sure?"), the second deletes. */
    private void delete(int i) {
        if (i < 0 || i >= rows.size() || !mine) return;
        if (confirmDelete != i) {
            confirmDelete = i;
            confirmAt = System.currentTimeMillis();
            return;
        }
        confirmDelete = -1;
        final Row r = rows.get(i);
        info("Deleting...");
        CloudClient.delete(r.id, new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (error != null) {
                    setStatus(friendly(error), true);
                } else {
                    refresh();
                    setStatus("Deleted \"" + r.name + "\"", false);
                }
            }
        });
    }

    private void upload() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            setStatus("Give your config a name first", true);
            focusOnly(nameField);
            return;
        }
        info("Uploading...");
        final boolean pub = uploadPublic;
        final String shown = name;
        CloudClient.upload(name, descField.getText().trim(), pub, ConfigManager.buildJson(true), new CloudClient.Callback() {
            @Override
            public void done(JsonElement result, String error) {
                if (error != null) {
                    setStatus(friendly(error), true);
                    return;
                }
                // success: clear the form and jump to "My Configs" so you see it right away
                nameField.setText("");
                descField.setText("");
                mine = true;
                rows.clear();
                openList();
                refresh();
                setStatus("Shared \"" + shown + "\" (" + (pub ? "public" : "private") + ")", false);
            }
        });
    }

    // ------------------------------------------------------------------------------------------
    // drawing helpers
    // ------------------------------------------------------------------------------------------

    private static float tw(String s, float sc) {
        return LumenFont.width(s) * sc;
    }

    private static void text(String s, float x, float y, float sc, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(sc, sc, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    /** Text vertically centred in a box of the given height. */
    private static void textMid(String s, float x, float y, float h, float sc, int color) {
        text(s, x, y + (h - LumenFont.EM * sc) / 2f - 0.5f, sc, color);
    }

    private static void textCentered(String s, float cx, float y, float sc, int color) {
        text(s, cx - tw(s, sc) / 2f, y, sc, color);
    }

    private Btn button(int id, float x, float y, float w, float h, String label, boolean active, boolean enabled, int mx, int my, float e) {
        return button(id, 0, x, y, w, h, label, active, enabled, false, mx, my, e);
    }

    private Btn button(int id, int arg, float x, float y, float w, float h, String label, boolean active, boolean enabled,
                       boolean danger, int mx, int my, float e) {
        Theme th = Theme.current();
        Btn b = new Btn(id, arg, x, y, w, h);
        boolean hov = enabled && b.contains(mx, my);
        if (enabled) btns.add(b);
        int c1 = Colors.opaque(th.c1), c3 = Colors.opaque(th.c3);
        int base = Colors.lerp(0xFF10132B, danger ? 0xFF8A2A2A : c3, active || danger ? 0.35f : hov ? 0.22f : 0.08f);
        int edge = danger ? RED : (active || hov ? c1 : Colors.lerp(c1, 0xFF1E2247, 0.7f));
        if (th.glass) {
            GlassFx.pane(x, y, x + w, y + h, 4f, enabled ? e : e * 0.45f, active ? 1f : hov ? 0.4f : 0f);
        } else {
            RenderUtil.roundedRect(x - 1, y - 1, x + w + 1, y + h + 1, 5f, Colors.mulAlpha(Colors.withAlpha(edge, enabled ? 255 : 90), e));
            RenderUtil.roundedRect(x, y, x + w, y + h, 4f, Colors.mulAlpha(Colors.withAlpha(base, 250), e));
        }
        float sc = 0.85f;
        int col = enabled ? 0xFFFFFFFF : 0xFF626A85;
        textMid(label, x + (w - tw(label, sc)) / 2f, y, h, sc, Colors.mulAlpha(col, e));
        return b;
    }

    private void box(GuiTextField f, float x, float y, float w, float h, String placeholder, float e) {
        Theme th = Theme.current();
        int c1 = Colors.opaque(th.c1);
        boolean foc = f.isFocused();
        if (th.glass) {
            RenderUtil.roundedRect(x, y, x + w, y + h, 4f, Colors.mulAlpha(0x66050B18, e));
            GlassFx.pane(x, y, x + w, y + h, 4f, e, foc ? 0.7f : 0f);
        } else {
            RenderUtil.roundedRect(x - 1, y - 1, x + w + 1, y + h + 1, 5f,
                    Colors.mulAlpha(foc ? c1 : Colors.lerp(c1, 0xFF1E2247, 0.75f), e));
            RenderUtil.roundedRect(x, y, x + w, y + h, 4f, Colors.mulAlpha(0xF2080A1A, e));
        }
        f.xPosition = (int) (x + 6);
        f.yPosition = (int) (y + (h - 8) / 2f);
        f.width = (int) (w - 12);
        f.height = (int) h;
        if (f.getText().isEmpty() && !foc) {
            textMid(placeholder, x + 6, y, h, 0.85f, Colors.mulAlpha(0xFF566080, e));
        }
        f.drawTextBox();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    @Override
    public void drawScreen(int mx, int my, float pt) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        Theme th = Theme.current();
        int c1 = Colors.opaque(th.c1), c3 = Colors.opaque(th.c3);
        btns.clear();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // backdrop
        int tint = Colors.lerp(c3, c1, 0.4f);
        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, true);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.12f));
        }

        // panel
        pw = Math.min(width - 20f, 440f);
        ph = Math.min(height - 16f, 330f);
        px = (width - pw) / 2f;
        py = (height - ph) / 2f + (1f - e) * 6f;
        if (th.glass) {
            RenderUtil.roundedRect(px - 4f, py - 2f, px + pw + 4f, py + ph + 5f, 12f, Colors.mulAlpha(0x22000000, e));
            GlassFx.pane(px, py, px + pw, py + ph, 8f, e, 0f);
        } else {
            RenderUtil.roundedRectH(px - 1, py - 1, px + pw + 1, py + ph + 1, 8f,
                    Colors.mulAlpha(Colors.withAlpha(c1, 150), e), Colors.mulAlpha(Colors.withAlpha(c3, 150), e));
            RenderUtil.roundedRect(px, py, px + pw, py + ph, 7f, Colors.mulAlpha(0xF40A0C1E, e));
        }

        lx = px + 14;
        lw = pw - 28;

        // header (same in every view)
        Icons.cloud(px + 22, py + 18, 16f, th, e);
        text("Config Cloud", px + 38, py + 9, 1.25f, Colors.mulAlpha(0xFFFFFFFF, e));
        float closeX = px + pw - 20;
        button(A_CLOSE, closeX, py + 8, 12, 12, "x", false, true, mx, my, e);
        if (mode == Mode.LIST && CloudClient.configured()) {
            button(A_SERVER, closeX - 6 - 46, py + 8, 46, 14, "Server", false, true, mx, my, e);
        }
        RenderUtil.gradientH(px + 14, py + 28, px + pw - 14, py + 29, Colors.mulAlpha(Colors.withAlpha(c1, 200), e), Colors.mulAlpha(Colors.withAlpha(c3, 40), e));

        float fy = py + ph - 30; // footer row
        if (mode == Mode.LIST) {
            drawList(mx, my, e, fy, c1);
        } else if (mode == Mode.SHARE) {
            drawShare(mx, my, e, fy);
        } else {
            drawSetup(mx, my, e, fy);
        }

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawFooterStatus(float x, float y, float maxX, float e) {
        if (status.isEmpty()) return;
        textMid(LumenFont.trim(status, (maxX - x) / 0.8f), x, y, 18, 0.8f, Colors.mulAlpha(statusColor, e));
    }

    private void drawList(int mx, int my, float e, float fy, int c1) {
        Theme th = Theme.current();

        // tabs + search
        float ty = py + 36;
        button(A_BROWSE, px + 14, ty, 64, 18, "Browse", !mine, true, mx, my, e);
        button(A_MINE, px + 82, ty, 84, 18, "My Configs", mine, true, mx, my, e);
        if (!mine) {
            float sx = px + 174;
            box(search, sx, ty, px + pw - 14 - sx, 18, "Search by name", e);
        } else {
            String hint = "Configs you've shared";
            text(hint, px + pw - 14 - tw(hint, 0.8f), ty + 5, 0.8f, Colors.mulAlpha(0xFF7A84A0, e));
        }

        // list
        ly = py + 62;
        lh = fy - 8 - ly;
        RenderUtil.roundedRect(lx, ly, lx + lw, ly + lh, 5f, Colors.mulAlpha(th.glass ? 0x40050B18 : 0x66000000, e));
        int visible = Math.max(1, (int) (lh / ROW_H));
        int max = Math.max(0, rows.size() - visible);
        scroll = Math.max(0, Math.min(max, scroll));
        RenderUtil.scissor(lx, ly, lw, lh);
        for (int n = 0; n < visible && n + scroll < rows.size(); n++) {
            int i = n + scroll;
            Row r = rows.get(i);
            float y = ly + n * ROW_H;
            boolean hov = mx >= lx && mx <= lx + lw - 8 && my >= y && my < y + ROW_H && my >= ly && my < ly + lh;
            if (hov) RenderUtil.roundedRect(lx + 2, y + 1, lx + lw - 8, y + ROW_H - 1, 4f, Colors.mulAlpha(0x22FFFFFF, e));

            // per-row actions on the right
            float by = y + (ROW_H - 18) / 2f;
            float loadX = lx + lw - 12 - 46;
            button(A_LOAD, i, loadX, by, 46, 18, "Load", true, true, false, mx, my, e);
            float textRight = loadX - 8;
            if (mine) {
                float delX = loadX - 4 - 52;
                boolean armed = confirmDelete == i;
                button(A_DELETE, i, delX, by, 52, 18, armed ? "Sure?" : "Delete", false, true, armed, mx, my, e);
                textRight = delX - 8;
            }

            // name (+ visibility tag in My Configs)
            String tag = mine ? ("private".equals(r.visibility) ? "Private" : "Public") : "";
            int tagCol = "Private".equals(tag) ? AMBER : GREEN;
            float tagW = mine ? tw(tag, 0.72f) + 6 : 0;
            String name = LumenFont.trim(r.name, (textRight - (lx + 9) - tagW) / 0.95f);
            text(name, lx + 9, y + 4, 0.95f, Colors.mulAlpha(0xFFFFFFFF, e));
            if (mine) text(tag, lx + 9 + tw(name, 0.95f) + 6, y + 5.5f, 0.72f, Colors.mulAlpha(tagCol, e));

            // second line: author · loads · description
            StringBuilder sub = new StringBuilder();
            if (!mine && !r.author.isEmpty()) sub.append("by ").append(r.author).append("  \u00b7  ");
            sub.append(r.downloads).append(r.downloads == 1 ? " load" : " loads");
            if (!r.description.isEmpty()) sub.append("  \u00b7  ").append(r.description);
            text(LumenFont.trim(sub.toString(), (textRight - (lx + 9)) / 0.72f), lx + 9, y + 17, 0.72f, Colors.mulAlpha(0xFF8C96B4, e));
        }
        RenderUtil.endScissor();

        if (max > 0) {
            float th2 = Math.max(14f, lh * visible / rows.size());
            float ty2 = ly + (lh - th2) * scroll / max;
            RenderUtil.roundedRect(lx + lw - 6, ty2, lx + lw - 3, ty2 + th2, 1.5f, Colors.mulAlpha(Colors.withAlpha(c1, 190), e));
        }

        // empty / loading / error states, centred in the list
        if (rows.isEmpty()) {
            float cx = lx + lw / 2f, cy = ly + lh / 2f;
            if (loading) {
                textCentered("Loading...", cx, cy - 4, 0.9f, Colors.mulAlpha(0xFF7A84A0, e));
            } else if (listError != null) {
                textCentered(LumenFont.trim(listError, (lw - 30) / 0.9f), cx, cy - 18, 0.9f, Colors.mulAlpha(RED, e));
                button(A_RETRY, cx - 32, cy + 2, 64, 18, "Try again", true, true, mx, my, e);
            } else if (mine) {
                textCentered("You haven't shared a config yet", cx, cy - 12, 0.9f, Colors.mulAlpha(0xFFC4CCE0, e));
                textCentered("Use \"Share my setup\" below to upload yours", cx, cy + 2, 0.75f, Colors.mulAlpha(0xFF7A84A0, e));
            } else {
                String q = search.getText().trim();
                String msg = q.isEmpty() ? "No configs have been shared yet" : "No configs match \"" + q + "\"";
                textCentered(LumenFont.trim(msg, (lw - 30) / 0.9f), cx, cy - 4, 0.9f, Colors.mulAlpha(0xFF7A84A0, e));
            }
        }

        // footer: status on the left, one clear primary action on the right
        float shareW = 104;
        button(A_SHARE, lx + lw - shareW, fy, shareW, 18, "Share my setup", true, true, mx, my, e);
        if (status.isEmpty() && !loading && listError == null) {
            int n = rows.size();
            if (n > 0) info(n + (n == 1 ? " config" : " configs") + (mine ? "" : " \u00b7 click Load to use one"));
        }
        drawFooterStatus(lx, fy, lx + lw - shareW - 8, e);
    }

    private void drawShare(int mx, int my, float e, float fy) {
        float y = py + 40;
        text("Share your current setup", lx, y, 1.05f, Colors.mulAlpha(0xFFFFFFFF, e));
        text("Your modules, settings and theme are uploaded. API keys never are.", lx, y + 14, 0.75f, Colors.mulAlpha(0xFF8C96B4, e));

        float a = y + 34;
        text("Name", lx, a, 0.8f, Colors.mulAlpha(0xFFC4CCE0, e));
        box(nameField, lx, a + 12, lw, 20, "e.g. Ranked PvP", e);

        float b = a + 42;
        text("Description (optional)", lx, b, 0.8f, Colors.mulAlpha(0xFFC4CCE0, e));
        box(descField, lx, b + 12, lw, 20, "What is it good for?", e);

        float c = b + 42;
        text("Who can load it?", lx, c, 0.8f, Colors.mulAlpha(0xFFC4CCE0, e));
        float half = (lw - 6) / 2f;
        button(A_PUBLIC, lx, c + 12, half, 20, "Public", uploadPublic, true, mx, my, e);
        button(A_PRIVATE, lx + half + 6, c + 12, half, 20, "Private", !uploadPublic, true, mx, my, e);
        String cap = uploadPublic ? "Anyone can find and load it." : "Only you can see it, under My Configs.";
        text(cap, lx, c + 38, 0.75f, Colors.mulAlpha(0xFF8C96B4, e));

        button(A_UPLOAD, lx + lw - 90, fy, 90, 18, "Upload", true, true, mx, my, e);
        button(A_BACK, lx + lw - 90 - 6 - 64, fy, 64, 18, "Cancel", false, true, mx, my, e);
        drawFooterStatus(lx, fy, lx + lw - 90 - 6 - 64 - 8, e);
    }

    private void drawSetup(int mx, int my, float e, float fy) {
        float y = py + 40;
        text("Connect to a config server", lx, y, 1.05f, Colors.mulAlpha(0xFFFFFFFF, e));
        text("Paste the address of the server you want to use. You only do this once.", lx, y + 14, 0.75f, Colors.mulAlpha(0xFF8C96B4, e));
        text("Server address", lx, y + 40, 0.8f, Colors.mulAlpha(0xFFC4CCE0, e));
        box(urlField, lx, y + 52, lw, 20, "https://your-server.example", e);
        text("You'll sign in automatically with your Minecraft account.", lx, y + 80, 0.75f, Colors.mulAlpha(0xFF7A84A0, e));

        button(A_CONNECT, lx + lw - 90, fy, 90, 18, "Connect", true, true, mx, my, e);
        float rightEdge = lx + lw - 90 - 8;
        if (CloudClient.configured()) {
            button(A_BACK, lx + lw - 90 - 6 - 64, fy, 64, 18, "Cancel", false, true, mx, my, e);
            rightEdge -= 70;
        }
        drawFooterStatus(lx, fy, rightEdge, e);
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    @Override
    public void updateScreen() {
        search.updateCursorCounter();
        nameField.updateCursorCounter();
        descField.updateCursorCounter();
        urlField.updateCursorCounter();
        long now = System.currentTimeMillis();
        if (confirmDelete >= 0 && now - confirmAt > CONFIRM_MS) confirmDelete = -1;
        // search as you type: wait a moment after the last key, then reload
        if (searchDirty && mode == Mode.LIST && !mine && now - searchAt > SEARCH_DELAY_MS) refresh();
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) {
            back();
            return;
        }
        if (mode == Mode.LIST) {
            if (!mine) {
                if (!search.isFocused()) {
                    // just start typing to search
                    if (c >= 32 && c != 127) search.setFocused(true);
                }
                if (search.isFocused()) {
                    if (key == Keyboard.KEY_RETURN) {
                        refresh();
                    } else if (search.textboxKeyTyped(c, key)) {
                        searchDirty = true;
                        searchAt = System.currentTimeMillis();
                    }
                }
            }
        } else if (mode == Mode.SHARE) {
            if (key == Keyboard.KEY_TAB) {
                focusOnly(nameField.isFocused() ? descField : nameField);
            } else if (key == Keyboard.KEY_RETURN) {
                if (nameField.isFocused()) focusOnly(descField);
                else upload();
            } else if (nameField.isFocused()) {
                nameField.textboxKeyTyped(c, key);
            } else if (descField.isFocused()) {
                descField.textboxKeyTyped(c, key);
            }
        } else {
            if (key == Keyboard.KEY_RETURN) connect();
            else urlField.textboxKeyTyped(c, key);
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        if (mode == Mode.LIST) {
            if (!mine) search.mouseClicked(mx, my, button);
        } else if (mode == Mode.SHARE) {
            nameField.mouseClicked(mx, my, button);
            descField.mouseClicked(mx, my, button);
        } else {
            urlField.mouseClicked(mx, my, button);
        }
        if (button != 0) return;
        for (Btn b : btns) {
            if (b.contains(mx, my)) {
                Sounds.click();
                act(b.id, b.arg);
                return;
            }
        }
        // clicking anywhere else disarms a pending delete
        confirmDelete = -1;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0 && mode == Mode.LIST) scroll += d < 0 ? 1 : -1;
    }
}
