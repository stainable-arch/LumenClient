package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

/**
 * The big soft ribbons that sway slowly along the left and right edges of the main menu and the
 * ClickGUI. Always on (not a module); the colour follows the current theme.
 */
public final class Stripes {
    private Stripes() {}

    /** Seconds for the animation, from a millisecond clock (kept small so floats stay precise). */
    public static float time(long nowMs) {
        return (nowMs % 86400000L) / 1000f;
    }

    public static int tint() {
        Theme th = Theme.current();
        return Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
    }

    public static void draw(int width, int height, float t, float e) {
        if (e <= 0.01f) return;
        int ribbonCol = Colors.lerp(tint(), 0xFFFFFFFF, 0.3f);
        int cr = Colors.channel(ribbonCol, 16), cg = Colors.channel(ribbonCol, 8), cb = Colors.channel(ribbonCol, 0);
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        float step = 6f;
        for (int side = 0; side < 2; side++) {
            for (int i = 0; i < 6; i++) {
                float phase = i * 0.28f + side * 1.7f;
                float half = width * 0.021f;
                int a = Math.min(255, (int) ((16 + i * 4) * e));
                wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
                for (float y = 0; y < height; y += step) {
                    float y2 = y + step;
                    float c1 = waveX(width, height, i, y, t, phase);
                    float c2 = waveX(width, height, i, y2, t, phase);
                    if (side == 1) {
                        c1 = width - c1;
                        c2 = width - c2;
                    }
                    // left half (transparent edge -> bright centre), then right half
                    wr.pos(c1 - half, y, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c1, y, 0).color(cr, cg, cb, a).endVertex();
                    wr.pos(c2, y2, 0).color(cr, cg, cb, a).endVertex();
                    wr.pos(c2 - half, y2, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c1, y, 0).color(cr, cg, cb, a).endVertex();
                    wr.pos(c1 + half, y, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c2 + half, y2, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c2, y2, 0).color(cr, cg, cb, a).endVertex();
                }
                tess.draw();
            }
        }
        GlStateManager.shadeModel(7424);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static float waveX(int width, int height, int i, float y, float t, float phase) {
        float yy = y / height;
        float swing = 0.5f + 0.5f * (float) Math.sin(yy * 5.2f + t * 0.22f + phase);
        return width * (0.02f + 0.047f * i) + width * 0.13f * swing;
    }
}
