package com.lumen.client.core;

import com.lumen.client.gui.HudEditor;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

/**
 * A module that draws something on the in-game HUD. Subclasses draw at the origin (0,0);
 * this class moves/scales the matrix. HUD modules can only be moved in the HUD editor (pencil button in the ClickGUI).
 */
public abstract class HudModule extends Module {
    public float x, y;
    /** Size of the last drawn frame (unscaled). Set by box(), used for dragging. */
    public float width = 60, height = 15;

    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.6, 2.0, 0.05));
    public final BooleanSetting background = add(new BooleanSetting("Background", true));

    protected HudModule(String name, String description, Category category, float x, float y) {
        super(name, description, category);
        this.x = x;
        this.y = y;
    }

    /** Draw the element with its top-left corner at (0,0) and call box() to report the size. */
    protected abstract void draw();

    public final void renderHud(ScaledResolution sr) {
        // keep the element reachable if the GUI scale or window size changed
        x = Math.max(0, Math.min(x, sr.getScaledWidth() - 12));
        y = Math.max(0, Math.min(y, sr.getScaledHeight() - 12));

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        float s = scale.getFloat();
        GlStateManager.scale(s, s, 1f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, 1f);
        draw();
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public float scaledWidth() {
        return width * scale.getFloat();
    }

    public float scaledHeight() {
        return height * scale.getFloat();
    }

    /** True while the HUD editor is open (HUD modules show placeholders so they can be positioned). */
    protected boolean editing() {
        return mc.currentScreen instanceof HudEditor;
    }

    protected int accent() {
        return Colors.opaque(Theme.current().c1);
    }

    /** Records the size and paints the translucent background with a thin theme-coloured underline. */
    protected void box(float w, float h) {
        this.width = w;
        this.height = h;
        if (background.value) {
            Theme th = Theme.current();
            RenderUtil.roundedRect(0, 0, w, h, 3, 0x8C000000);
            RenderUtil.gradientH(2, h - 1.5f, w - 2, h - 0.5f, Colors.withAlpha(th.c1, 230), Colors.withAlpha(th.c2, 230));
        }
    }

    protected void labelValue(String label, String value) {
        labelValue(label, value, 0xFFFFFFFF);
    }

    /** "LABEL value" in a one-line box: the label uses the theme accent. */
    protected void labelValue(String label, String value, int valueColor) {
        String prefix = label.isEmpty() ? "" : label + " ";
        float w = RenderUtil.width(prefix + value) + 10;
        box(w, 15);
        RenderUtil.string(prefix, 5, 3.5f, accent());
        RenderUtil.string(value, 5 + RenderUtil.width(prefix), 3.5f, valueColor);
    }
}
