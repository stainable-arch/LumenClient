package com.lumen.client.core;

import com.lumen.client.gui.HudEditor;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

/**
 * A module that draws something on the in-game HUD. Subclasses draw at the origin (0,0);
 * this class moves/scales the matrix. HUD modules can only be moved in the HUD editor (pencil button in the ClickGUI).
 */
public abstract class HudModule extends Module {
    public float x, y;
    /** Size of the last drawn frame (unscaled). Set by box(), used for dragging. */
    public float width = 60, height = 15;

    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.6, 2.0, 0.05));
    public final BooleanSetting background = add(new BooleanSetting("Background", true));
    public final BooleanSetting textShadow = add(new BooleanSetting("Text Shadow", true));

    protected HudModule(String name, String description, Category category, float x, float y) {
        super(name, description, category);
        this.x = x;
        this.y = y;
    }

    /** Draw the element with its top-left corner at (0,0) and call box() to report the size. */
    protected abstract void draw();

    public final void renderHud(ScaledResolution sr) {
        // keep the element reachable if the GUI scale or window size changed
        x = Math.max(0, Math.min(x, sr.getScaledWidth() - 12));
        y = Math.max(0, Math.min(y, sr.getScaledHeight() - 12));

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        float s = scale.getFloat();
        GlStateManager.scale(s, s, 1f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, 1f);
        RenderUtil.inHud = true;
        RenderUtil.hudShadow = textShadow.value;
        try {
            draw();
        } finally {
            RenderUtil.inHud = false;
            RenderUtil.hudShadow = true;
        }
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public float scaledWidth() {
        return width * scale.getFloat();
    }

    public float scaledHeight() {
        return height * scale.getFloat();
    }

    /** True while the HUD editor is open (HUD modules show placeholders so they can be positioned). */
    protected boolean editing() {
        return mc.currentScreen instanceof HudEditor;
    }

    protected int accent() {
        return Colors.opaque(Theme.current().c1);
    }

    /**
     * The HUD background for themes without the glass look: a dark pane tinted with the theme's own base colour,
     * a faint top sheen and a thin rim that blends from accent 1 to accent 2. {@code lit} (0..1) fills the pane
     * with the accent (used for pressed keys). The glass theme uses {@link com.lumen.client.gui.GlassFx#pane} instead.
     */
    public static void themedPane(float x, float y, float x2, float y2, float radius, float lit) {
        Theme th = Theme.current();
        int base = Colors.withAlpha(Colors.lerp(0xFF000000 | th.bg, 0xFF000000 | th.c1, 0.07f) & 0xFFFFFF, 178);
        int fill = Colors.lerp(base, Colors.withAlpha(th.c1, 225), lit);
        RenderUtil.roundedRect(x, y, x2, y2, radius, fill);
        float inset = Math.min(radius * 0.55f, (x2 - x) / 4f);
        RenderUtil.gradientV(x + inset, y + 1f, x2 - inset, y + (y2 - y) * 0.5f,
                Colors.withAlpha(0xFFFFFF, (int) (14 * (1f - lit))), 0x00FFFFFF);
        RenderUtil.roundedOutline(x, y, x2, y2, radius, 1f,
                Colors.withAlpha(th.c1, (int) (95 + 90 * lit)), Colors.withAlpha(th.c2, (int) (40 + 90 * lit)));
    }

    /** Records the size and paints the background (frosted glass for the glass theme, a tinted dark pane otherwise). */
    protected void box(float w, float h) {
        this.width = w;
        this.height = h;
        if (!background.value) return;
        if (Theme.current().glass) {
            com.lumen.client.gui.GlassFx.pane(0, 0, w, h, 3f, 1f, 0.12f);
        } else {
            themedPane(0, 0, w, h, 3f, 0f);
        }
    }

    protected void labelValue(String label, String value) {
        labelValue(label, value, 0xFFFFFFFF);
    }

    /** "LABEL value" in a one-line box: the label uses the theme accent. */
    protected void labelValue(String label, String value, int valueColor) {
        String prefix = label.isEmpty() ? "" : label + " ";
        float w = RenderUtil.width(prefix + value) + 10;
        box(w, 15);
        RenderUtil.string(prefix, 5, 3.5f, accent());
        RenderUtil.string(value, 5 + RenderUtil.width(prefix), 3.5f, valueColor);
    }
}
