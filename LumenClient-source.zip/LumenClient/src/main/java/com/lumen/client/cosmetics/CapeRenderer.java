package com.lumen.client.cosmetics;

import com.lumen.client.ClientSettings;
import com.lumen.client.util.LumenUsers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * The Lumen cape: fully black with a white "claude" in the Winkle font (assets/lumen/textures/cape.png,
 * baked by tools/gen_cape.py). It is drawn for Lumen users when Cosmetics is on, right after the player
 * model, using the same transforms and swing maths as vanilla's cape layer. Players who already wear a
 * Lumen's cape takes priority: before the player is rendered, a Mojang / OptiFine cape is hidden by clearing the
 * \"cape\" skin-part bit on the client-side data watcher (vanilla's cape layer checks it), and it is put back
 * right after. Forge events only, no mixins, no reflection.
 */
public final class CapeRenderer {
    private static final ResourceLocation CAPE = new ResourceLocation("lumen", "textures/cape.png");
    /** Data watcher slot of the skin-part flags (EntityPlayer) and the bit of the cape part. */
    private static final int PARTS_SLOT = 10;
    private static final int CAPE_BIT = EnumPlayerModelParts.CAPE.getPartMask();

    /** The cape texture (also used by the cosmetics screen for its thumbnail and preview). */
    public static ResourceLocation texture() {
        return CAPE;
    }

    private final Minecraft mc = Minecraft.getMinecraft();
    /** The player whose own cape is hidden for the render in progress, and the flags to put back. */
    private AbstractClientPlayer hidden;
    private byte savedFlags;

    /** The player if the Lumen cape should be drawn on them (the skin's \"cape\" part is checked separately). */
    private static AbstractClientPlayer eligible(EntityPlayer ep) {
        if (!ClientSettings.cosmetics || !ClientSettings.cape.value) return null;
        if (!(ep instanceof AbstractClientPlayer)) return null;
        AbstractClientPlayer p = (AbstractClientPlayer) ep;
        if (!LumenUsers.isLumenUser(p.getUniqueID())) return null;
        if (p.isInvisible() || p.isPlayerSleeping() || p.getHealth() <= 0f) return null;
        return p;
    }

    @SubscribeEvent
    public void onPlayerPre(RenderPlayerEvent.Pre e) {
        hidden = null;
        AbstractClientPlayer p = eligible(e.entityPlayer);
        if (p == null || p.getLocationCape() == null) return; // no Mojang / OptiFine cape to get out of the way
        byte flags = p.getDataWatcher().getWatchableObjectByte(PARTS_SLOT);
        if ((flags & CAPE_BIT) == 0) return;
        p.getDataWatcher().updateObject(PARTS_SLOT, Byte.valueOf((byte) (flags & ~CAPE_BIT)));
        hidden = p;
        savedFlags = flags;
    }

    @SubscribeEvent
    public void onPlayerPost(RenderPlayerEvent.Post e) {
        if (hidden != null) {
            // give the player their skin flags back (vanilla's cape layer has already been skipped)
            hidden.getDataWatcher().updateObject(PARTS_SLOT, Byte.valueOf(savedFlags));
            hidden = null;
        }
        AbstractClientPlayer p = eligible(e.entityPlayer);
        if (p == null || !p.isWearing(EnumPlayerModelParts.CAPE)) return;

        float pt = e.partialRenderTick;
        double y = e.y;
        if (p.isSneaking() && !(p instanceof EntityPlayerSP)) y -= 0.125D; // same as RenderPlayer.doRender

        float bodyYaw = interpolate(p.prevRenderYawOffset, p.renderYawOffset, pt);

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) e.x, (float) y, (float) e.z);
        GlStateManager.rotate(180f - bodyYaw, 0f, 1f, 0f);
        GlStateManager.enableRescaleNormal();
        GlStateManager.scale(-1f, -1f, 1f);
        GlStateManager.scale(0.9375f, 0.9375f, 0.9375f);
        GlStateManager.translate(0f, -1.5078125f, 0f);

        GlStateManager.color(1f, 1f, 1f, 1f);
        mc.getTextureManager().bindTexture(CAPE);
        GlStateManager.pushMatrix();
        GlStateManager.translate(0f, 0f, 0.125f);

        double dx = p.prevChasingPosX + (p.chasingPosX - p.prevChasingPosX) * pt
                - (p.prevPosX + (p.posX - p.prevPosX) * pt);
        double dy = p.prevChasingPosY + (p.chasingPosY - p.prevChasingPosY) * pt
                - (p.prevPosY + (p.posY - p.prevPosY) * pt);
        double dz = p.prevChasingPosZ + (p.chasingPosZ - p.prevChasingPosZ) * pt
                - (p.prevPosZ + (p.posZ - p.prevPosZ) * pt);
        float yawRaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        double sin = MathHelper.sin(yawRaw * (float) Math.PI / 180f);
        double cos = -MathHelper.cos(yawRaw * (float) Math.PI / 180f);
        float lift = (float) dy * 10f;
        lift = MathHelper.clamp_float(lift, -6f, 32f);
        float back = (float) (dx * sin + dz * cos) * 100f;
        float side = (float) (dx * cos - dz * sin) * 100f;
        if (back < 0f) back = 0f;
        float bob = p.prevCameraYaw + (p.cameraYaw - p.prevCameraYaw) * pt;
        lift += MathHelper.sin((p.prevDistanceWalkedModified
                + (p.distanceWalkedModified - p.prevDistanceWalkedModified) * pt) * 6f) * 32f * bob;
        if (p.isSneaking()) {
            // same as vanilla's cape layer: tilt more and move the cape in with the bent body
            lift += 25f;
            GlStateManager.translate(0f, 0.142f, -0.0178f);
        }

        GlStateManager.rotate(6f + back / 2f + lift, 1f, 0f, 0f);
        GlStateManager.rotate(side / 2f, 0f, 0f, 1f);
        GlStateManager.rotate(-side / 2f, 0f, 1f, 0f);
        GlStateManager.rotate(180f, 0f, 1f, 0f);
        e.renderer.getMainModel().renderCape(0.0625f);

        GlStateManager.popMatrix();
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
    }

    /** Like RendererLivingEntity.interpolateRotation: takes the short way round. */
    private static float interpolate(float from, float to, float pt) {
        float d = to - from;
        while (d < -180f) d += 360f;
        while (d >= 180f) d -= 360f;
        return from + pt * d;
    }
}
