package com.lumen.client.gui;

import com.lumen.client.core.ColorSetting;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

/**
 * Colour wheel in the style of ibisPaint: an outer hue ring and, inside it, a triangle whose corners are
 * the pure hue, white and black. The triangle turns with the hue, so the pure-hue corner always points at
 * the marker on the ring. Saturation / brightness are picked inside the triangle.
 */
public final class ColorWheel {
    private ColorWheel() {}

    public static final int NONE = 0, RING = 1, TRIANGLE = 2;
    private static final int SEG = 96;

    private static float ringWidth(float r) {
        return Math.max(5f, r * 0.2f);
    }

    /** Circumradius of the triangle. */
    private static float triR(float r) {
        return r - ringWidth(r) - 3f;
    }

    private static float a(int c) { return ((c >>> 24) & 255) / 255f; }
    private static float rr(int c) { return ((c >> 16) & 255) / 255f; }
    private static float gg(int c) { return ((c >> 8) & 255) / 255f; }
    private static float bb(int c) { return (c & 255) / 255f; }

    private static void color(int c, float alpha) {
        GL11.glColor4f(rr(c), gg(c), bb(c), a(c) * alpha);
    }

    /** Triangle corners: [0] = pure hue, [1] = white, [2] = black, each {x, y}. */
    private static float[][] corners(float cx, float cy, float r, float hue) {
        float tr = triR(r);
        double base = hue * Math.PI * 2.0;
        float[][] v = new float[3][2];
        for (int i = 0; i < 3; i++) {
            double ang = base + i * Math.PI * 2.0 / 3.0;
            v[i][0] = cx + (float) Math.cos(ang) * tr;
            v[i][1] = cy + (float) Math.sin(ang) * tr;
        }
        return v;
    }

    /** Draws the wheel with its centre at (cx, cy) and outer radius r. */
    public static void draw(float cx, float cy, float r, ColorSetting c, float alpha) {
        float w = ringWidth(r);
        float ri = r - w;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);

        // hue ring
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int i = 0; i <= SEG; i++) {
            double ang = i * Math.PI * 2.0 / SEG;
            float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
            color(Colors.hsb((float) i / SEG, 1f, 1f), alpha);
            GL11.glVertex2f(cx + ca * r, cy + sa * r);
            GL11.glVertex2f(cx + ca * ri, cy + sa * ri);
        }
        GL11.glEnd();

        // saturation / brightness triangle (colours between the corners are interpolated by the GPU)
        float[][] v = corners(cx, cy, r, c.hue);
        GL11.glBegin(GL11.GL_TRIANGLES);
        color(Colors.hsb(c.hue, 1f, 1f), alpha);
        GL11.glVertex2f(v[0][0], v[0][1]);
        color(0xFFFFFFFF, alpha);
        GL11.glVertex2f(v[1][0], v[1][1]);
        color(0xFF000000, alpha);
        GL11.glVertex2f(v[2][0], v[2][1]);
        GL11.glEnd();

        GlStateManager.shadeModel(7424);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);

        // markers
        double ang = c.hue * Math.PI * 2.0;
        float mr = (r + ri) / 2f;
        float hx = cx + (float) Math.cos(ang) * mr, hy = cy + (float) Math.sin(ang) * mr;
        float rad = w * 0.5f + 0.6f;
        RenderUtil.circle(hx, hy, rad + 1.6f, Colors.mulAlpha(0x66000000, alpha));
        RenderUtil.circle(hx, hy, rad + 0.7f, Colors.mulAlpha(0xFFFFFFFF, alpha));
        RenderUtil.circle(hx, hy, rad - 0.6f, Colors.mulAlpha(Colors.hsb(c.hue, 1f, 1f), alpha));

        float av = c.sat * c.val, bv = (1f - c.sat) * c.val, cv = 1f - c.val;
        float px = av * v[0][0] + bv * v[1][0] + cv * v[2][0];
        float py = av * v[0][1] + bv * v[1][1] + cv * v[2][1];
        RenderUtil.circle(px, py, 4.6f, Colors.mulAlpha(0x66000000, alpha));
        RenderUtil.circle(px, py, 3.7f, Colors.mulAlpha(0xFFFFFFFF, alpha));
        RenderUtil.circle(px, py, 2.6f, Colors.mulAlpha(Colors.opaque(c.rgb()), alpha));
    }

    /** What a press at (mx, my) grabs: the ring, the triangle area or nothing. */
    public static int hit(float cx, float cy, float r, float mx, float my) {
        float d = (float) Math.sqrt((mx - cx) * (mx - cx) + (my - cy) * (my - cy));
        float ri = r - ringWidth(r);
        if (d >= ri - 2f && d <= r + 2f) return RING;
        if (d < ri - 2f) return TRIANGLE;
        return NONE;
    }

    /** Applies a press / drag at (mx, my) to the colour; {@code mode} is what the press started on. */
    public static void drag(int mode, float cx, float cy, float r, float mx, float my, ColorSetting c) {
        if (mode == RING) {
            double ang = Math.atan2(my - cy, mx - cx);
            float h = (float) (ang / (Math.PI * 2.0));
            c.hue = h - (float) Math.floor(h);
        } else if (mode == TRIANGLE) {
            float[][] v = corners(cx, cy, r, c.hue);
            float x1 = v[0][0], y1 = v[0][1], x2 = v[1][0], y2 = v[1][1], x3 = v[2][0], y3 = v[2][1];
            float den = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3);
            if (Math.abs(den) < 1e-6f) return;
            float wa = ((y2 - y3) * (mx - x3) + (x3 - x2) * (my - y3)) / den;
            float wb = ((y3 - y1) * (mx - x3) + (x1 - x3) * (my - y3)) / den;
            float wc = 1f - wa - wb;
            // outside the triangle: slide to its edge
            wa = Math.max(0f, wa);
            wb = Math.max(0f, wb);
            wc = Math.max(0f, wc);
            float sum = wa + wb + wc;
            if (sum <= 0f) return;
            wa /= sum;
            wb /= sum;
            float val = wa + wb;
            c.val = val;
            if (val > 1e-4f) c.sat = wa / val;
        }
    }
}
