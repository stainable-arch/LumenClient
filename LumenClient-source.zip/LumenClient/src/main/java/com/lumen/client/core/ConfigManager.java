package com.lumen.client.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lumen.client.ClientSettings;
import com.lumen.client.gui.Theme;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;

/** Saves/loads module states, keybinds, HUD positions and settings to config/lumenclient.json. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private ConfigManager() {}

    private static File file() {
        return new File(Minecraft.getMinecraft().mcDataDir, "config/lumenclient.json");
    }

    /** Current setup as JSON. {@code shareable} leaves out secrets (API keys, cloud server) so it can be uploaded. */
    public static JsonObject buildJson(boolean shareable) {
        JsonObject root = new JsonObject();
        root.addProperty("theme", Theme.current().name);
        root.addProperty("aurora", ClientSettings.aurora);
        root.addProperty("sounds", ClientSettings.sounds);
        root.addProperty("packDraggable", ClientSettings.packDraggable);
        root.addProperty("font", ClientSettings.font);
        if (!shareable) {
            root.addProperty("hypixelKey", ClientSettings.hypixelKey);
            root.addProperty("voxylKey", ClientSettings.voxylKey);
            root.addProperty("cloudUrl", ClientSettings.cloudUrl);
        }

        JsonObject mods = new JsonObject();
        for (Module m : ModuleManager.modules) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.key);
            if (m instanceof HudModule) {
                o.addProperty("x", ((HudModule) m).x);
                o.addProperty("y", ((HudModule) m).y);
            }
            JsonObject s = new JsonObject();
            for (Setting st : m.settings) {
                s.add(st.name, st.save());
            }
            o.add("settings", s);
            mods.add(m.name, o);
        }
        root.add("modules", mods);
        return root;
    }

    public static synchronized void save() {
        try {
            JsonObject root = buildJson(false);

            File f = file();
            f.getParentFile().mkdirs();
            Writer w = new OutputStreamWriter(new FileOutputStream(f), UTF8);
            try {
                GSON.toJson(root, w);
            } finally {
                w.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static synchronized void load() {
        File f = file();
        if (!f.isFile()) return;
        try {
            Reader r = new InputStreamReader(new FileInputStream(f), UTF8);
            JsonObject root;
            try {
                root = new JsonParser().parse(r).getAsJsonObject();
            } finally {
                r.close();
            }

            apply(root, false);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** Applies a config downloaded from the cloud: secrets are kept, module on/off states are matched exactly. */
    public static synchronized void importShared(JsonObject root) {
        apply(root, true);
        save();
    }

    private static void apply(JsonObject root, boolean shared) {
        try {
            if (root.has("theme")) Theme.setByName(root.get("theme").getAsString());
            if (root.has("aurora")) ClientSettings.aurora = root.get("aurora").getAsBoolean();
            if (root.has("sounds")) ClientSettings.sounds = root.get("sounds").getAsBoolean();
            if (root.has("packDraggable")) ClientSettings.packDraggable = root.get("packDraggable").getAsBoolean();
            if (root.has("font")) ClientSettings.setFont(root.get("font").getAsString());
            if (!shared && root.has("hypixelKey")) ClientSettings.hypixelKey = root.get("hypixelKey").getAsString();
            if (!shared && root.has("voxylKey")) ClientSettings.voxylKey = root.get("voxylKey").getAsString();
            if (!shared && root.has("cloudUrl")) ClientSettings.cloudUrl = root.get("cloudUrl").getAsString();

            JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module m : ModuleManager.modules) {
                if (!mods.has(m.name)) continue;
                try {
                    JsonObject o = mods.getAsJsonObject(m.name);
                    if (o.has("key")) m.key = o.get("key").getAsInt();
                    if (m instanceof HudModule) {
                        if (o.has("x")) ((HudModule) m).x = o.get("x").getAsFloat();
                        if (o.has("y")) ((HudModule) m).y = o.get("y").getAsFloat();
                    }
                    if (o.has("settings")) {
                        JsonObject s = o.getAsJsonObject("settings");
                        for (Setting st : m.settings) {
                            if (s.has(st.name)) {
                                try {
                                    st.load(s.get(st.name));
                                } catch (Exception ignored) {
                                    // bad value in the file: keep the default
                                }
                            }
                        }
                    }
                    if (o.has("enabled")) {
                        boolean on = o.get("enabled").getAsBoolean();
                        if (on || shared) m.setEnabled(on);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
