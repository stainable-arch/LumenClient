package com.lumen.client.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lumen.client.ClientSettings;
import com.lumen.client.gui.Theme;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/** Saves/loads module states, keybinds, HUD positions and settings to config/lumenclient.json. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Charset UTF8 = Charset.forName("UTF-8");

    /** Saving is blocked until the config was loaded, so a blank default can never overwrite saved data. */
    private static volatile boolean loaded;

    private ConfigManager() {}

    /** API keys live in their own small file too, so nothing else in the config can ever take them down. */
    private static File keysFile() {
        return new File(Minecraft.getMinecraft().mcDataDir, "config/lumenclient-keys.json");
    }

    /** Writes the text to a temp file first and then swaps it in, so a crash mid-write can't leave a broken file. */
    private static void writeAtomic(File f, String text) throws java.io.IOException {
        f.getParentFile().mkdirs();
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        Writer w = new OutputStreamWriter(new FileOutputStream(tmp), UTF8);
        try {
            w.write(text);
            w.flush();
        } finally {
            w.close();
        }
        try {
            Files.move(tmp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception atomicFailed) {
            Files.move(tmp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void saveKeys() {
        try {
            JsonObject k = new JsonObject();
            k.addProperty("hypixelKey", ClientSettings.hypixelKey);
            k.addProperty("voxylKey", ClientSettings.voxylKey);
            writeAtomic(keysFile(), GSON.toJson(k));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void loadKeys() {
        File f = keysFile();
        if (!f.isFile()) return;
        try {
            Reader r = new InputStreamReader(new FileInputStream(f), UTF8);
            JsonObject k;
            try {
                k = new JsonParser().parse(r).getAsJsonObject();
            } finally {
                r.close();
            }
            if (k.has("hypixelKey")) ClientSettings.hypixelKey = k.get("hypixelKey").getAsString();
            if (k.has("voxylKey")) ClientSettings.voxylKey = k.get("voxylKey").getAsString();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static File file() {
        return new File(Minecraft.getMinecraft().mcDataDir, "config/lumenclient.json");
    }

    /** Current setup as JSON. */
    public static JsonObject buildJson() {
        JsonObject root = new JsonObject();
        root.addProperty("theme", Theme.current().name);
        root.addProperty("sounds", ClientSettings.sounds);
        root.addProperty("cosmetics", ClientSettings.cosmetics);
        root.addProperty("packDraggable", ClientSettings.packDraggable);
        root.addProperty("cape", ClientSettings.cape.value);
        root.addProperty("sahurPet", ClientSettings.sahurPet.value);
        root.addProperty("cute", ClientSettings.cute);
        root.addProperty("cuteScale", ClientSettings.cuteScale.value);
        root.addProperty("cuteX", ClientSettings.cuteX);
        root.addProperty("cuteY", ClientSettings.cuteY);
        root.addProperty("gui", ClientSettings.gui.get());
        JsonObject opts = new JsonObject();
        for (com.lumen.client.core.BooleanSetting o : ClientSettings.OPTIONS) opts.addProperty(o.name, o.value);
        root.add("options", opts);
        root.addProperty("hypixelKey", ClientSettings.hypixelKey);
        root.addProperty("voxylKey", ClientSettings.voxylKey);

        JsonObject mods = new JsonObject();
        for (Module m : ModuleManager.modules) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.key);
            if (m instanceof HudModule) {
                o.addProperty("x", ((HudModule) m).x);
                o.addProperty("y", ((HudModule) m).y);
            }
            JsonObject s = new JsonObject();
            for (Setting st : m.settings) {
                s.add(st.name, st.save());
            }
            o.add("settings", s);
            mods.add(m.name, o);
        }
        root.add("modules", mods);
        return root;
    }

    public static synchronized void save() {
        if (!loaded) return;
        try {
            writeAtomic(file(), GSON.toJson(buildJson()));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        saveKeys();
    }

    public static synchronized void load() {
        try {
            loadKeys(); // first and on its own: the keys must survive whatever else is in the config
            File f = file();
            if (!f.isFile()) return;
            try {
                Reader r = new InputStreamReader(new FileInputStream(f), UTF8);
                JsonObject root;
                try {
                    root = new JsonParser().parse(r).getAsJsonObject();
                } finally {
                    r.close();
                }
                apply(root);
            } catch (Exception ex) {
                ex.printStackTrace();
                try { // keep the unreadable file instead of overwriting it with defaults
                    Files.copy(f.toPath(), new File(f.getParentFile(), f.getName() + ".bak").toPath(), StandardCopyOption.REPLACE_EXISTING);
                } catch (Exception ignored) {
                }
            }
        } finally {
            loaded = true;
        }
    }

    private static void apply(JsonObject root) {
        // keys saved in the main file by older versions are used when the keys file has none
        try {
            if (root.has("hypixelKey") && ClientSettings.hypixelKey.isEmpty()) ClientSettings.hypixelKey = root.get("hypixelKey").getAsString();
            if (root.has("voxylKey") && ClientSettings.voxylKey.isEmpty()) ClientSettings.voxylKey = root.get("voxylKey").getAsString();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            if (root.has("theme")) Theme.setByName(root.get("theme").getAsString());
            if (root.has("sounds")) ClientSettings.sounds = root.get("sounds").getAsBoolean();
            if (root.has("cosmetics")) ClientSettings.cosmetics = root.get("cosmetics").getAsBoolean();
            if (root.has("packDraggable")) ClientSettings.packDraggable = root.get("packDraggable").getAsBoolean();
            if (root.has("cape")) {
                ClientSettings.cape.value = root.get("cape").getAsBoolean();
                ClientSettings.cape.anim = ClientSettings.cape.value ? 1f : 0f;
            }
            if (root.has("sahurPet")) {
                ClientSettings.sahurPet.value = root.get("sahurPet").getAsBoolean();
                ClientSettings.sahurPet.anim = ClientSettings.sahurPet.value ? 1f : 0f;
            }
            if (root.has("cute")) ClientSettings.cute = root.get("cute").getAsBoolean();
            if (root.has("cuteScale")) ClientSettings.cuteScale.set(root.get("cuteScale").getAsDouble());
            if (root.has("gui")) ClientSettings.gui.load(root.get("gui"));
            if (root.has("cuteX")) ClientSettings.cuteX = root.get("cuteX").getAsFloat();
            if (root.has("cuteY")) ClientSettings.cuteY = root.get("cuteY").getAsFloat();
            if (root.has("options") && root.get("options").isJsonObject()) {
                JsonObject opts = root.getAsJsonObject("options");
                for (com.lumen.client.core.BooleanSetting o : ClientSettings.OPTIONS) {
                    if (opts.has(o.name)) o.load(opts.get(o.name));
                }
            }

            JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module m : ModuleManager.modules) {
                if (!mods.has(m.name)) continue;
                try {
                    JsonObject o = mods.getAsJsonObject(m.name);
                    if (o.has("key")) m.key = o.get("key").getAsInt();
                    if (m instanceof HudModule) {
                        if (o.has("x")) ((HudModule) m).x = o.get("x").getAsFloat();
                        if (o.has("y")) ((HudModule) m).y = o.get("y").getAsFloat();
                    }
                    if (o.has("settings")) {
                        JsonObject s = o.getAsJsonObject("settings");
                        for (Setting st : m.settings) {
                            if (s.has(st.name)) {
                                try {
                                    st.load(s.get(st.name));
                                } catch (Exception ignored) {
                                    // bad value in the file: keep the default
                                }
                            }
                        }
                    }
                    if (o.has("enabled")) {
                        boolean on = o.get("enabled").getAsBoolean();
                        if (on) m.setEnabled(on);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
