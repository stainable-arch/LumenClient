package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/**
 * The "cute" picture of the Settings page: shown in the bottom-left of the ClickGUI (and only there, it is
 * not a HUD element), can be dragged around while the ClickGUI is open and is scaled with its Scale option.
 */
public final class CutePicture {
    private static final ResourceLocation TEX = new ResourceLocation("lumen", "textures/cute.png");
    /** Size of the image at scale 1.0 in GUI units (aspect ratio of cute.png: 139 x 201). */
    private static final float BASE_H = 80f, ASPECT = 139f / 201f;
    /** Left edge of the default spot: leaves room for the HUD editor's pencil button in the corner. */
    private static final float DEFAULT_X = 36f, MARGIN = 4f;

    private static boolean dragging;
    private static float grabX, grabY;

    /** Time of the last module toggle, drives the little bob animation. */
    private static long bobStart = -1L;
    private static final float BOB_MS = 450f, BOB_AMP = 5f;

    private CutePicture() {}

    /** Called whenever a module is enabled / disabled: makes the picture hop a little. */
    public static void bob() {
        bobStart = System.currentTimeMillis();
    }

    /** Vertical offset (GUI units, negative = up) of the current bob: a damped bounce. */
    private static float bobOffset() {
        if (bobStart < 0L) return 0f;
        float t = (System.currentTimeMillis() - bobStart) / BOB_MS;
        if (t >= 1f) {
            bobStart = -1L;
            return 0f;
        }
        return -(float) Math.abs(Math.sin(t * Math.PI * 2.0)) * (1f - t) * BOB_AMP * Math.max(0.5f, ClientSettings.cuteScale.getFloat());
    }

    public static boolean isDragging() {
        return dragging;
    }

    private static float w() {
        return BASE_H * ASPECT * ClientSettings.cuteScale.getFloat();
    }

    private static float h() {
        return BASE_H * ClientSettings.cuteScale.getFloat();
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(Math.max(lo, hi), v));
    }

    private static float x(int sw) {
        float x = ClientSettings.cuteX < 0f ? DEFAULT_X : ClientSettings.cuteX * sw;
        return clamp(x, 0f, sw - w());
    }

    private static float y(int sh) {
        float y = ClientSettings.cuteY < 0f ? sh - h() - MARGIN : ClientSettings.cuteY * sh;
        return clamp(y, 0f, sh - h());
    }

    public static boolean over(int sw, int sh, int mx, int my) {
        float x = x(sw), y = y(sh);
        return mx >= x && mx <= x + w() && my >= y && my <= y + h();
    }

    public static void beginDrag(int sw, int sh, int mx, int my) {
        grabX = mx - x(sw);
        grabY = my - y(sh);
        dragging = true;
    }

    public static void drag(int sw, int sh, int mx, int my) {
        if (!dragging) return;
        ClientSettings.cuteX = clamp(mx - grabX, 0f, sw - w()) / Math.max(1, sw);
        ClientSettings.cuteY = clamp(my - grabY, 0f, sh - h()) / Math.max(1, sh);
    }

    public static void endDrag() {
        dragging = false;
    }

    public static void draw(int sw, int sh, float alpha) {
        float x = x(sw), y = y(sh) + bobOffset(), w = w(), h = h();
        Minecraft.getMinecraft().getTextureManager().bindTexture(TEX);
        // smooth when scaled (vanilla textures are point-filtered)
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, Math.max(0f, Math.min(1f, alpha)));
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        wr.pos(x, y + h, 0).tex(0, 1).endVertex();
        wr.pos(x + w, y + h, 0).tex(1, 1).endVertex();
        wr.pos(x + w, y, 0).tex(1, 0).endVertex();
        wr.pos(x, y, 0).tex(0, 0).endVertex();
        t.draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
