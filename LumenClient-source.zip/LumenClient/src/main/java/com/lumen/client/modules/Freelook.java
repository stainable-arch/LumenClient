package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.util.Events;
import com.lumen.client.util.ServerUtil;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Look around freely with the camera while your character keeps facing (and moving) the same way.
 * Hold or toggle the "Freelook" key (Options > Controls, default Left Alt).
 *
 * Locked on Hypixel: the module can't be turned on there, and freelook stops if you join it.
 *
 * Implementation (Forge events only): while active, the player's rotation is swapped for the camera's
 * rotation just around the frame render (so the mouse and the camera use it), and the real rotation is
 * put back right after, so game ticks, movement and packets always see the real one.
 */
public class Freelook extends Module {
    /** Registered in LumenClient.init. */
    public static KeyBinding key;

    private final ModeSetting mode = add(new ModeSetting("Mode", "Hold", "Hold", "Toggle"));
    private final BooleanSetting thirdPerson = add(new BooleanSetting("Third Person", true));

    private boolean active;
    private boolean toggled;
    private float lockYaw, lockPitch;
    private float camYaw, camPitch;
    private int oldView;

    public Freelook() {
        super("Freelook", "Look around with the camera without turning your character. Locked on Hypixel.", Category.VISUALS);
        // always listening, so holding the bind works even if the module isn't switched on in the ClickGUI
        Events.register(this);
    }

    @Override
    public String lockReason() {
        return ServerUtil.onHypixel() ? "Locked: not usable on Hypixel" : null;
    }

    @Override
    protected void onDisable() {
        stop();
        toggled = false;
        Events.register(this); // Module.setEnabled(false) unregisters; keep listening for the bind
    }

    private void start() {
        EntityPlayer p = mc.thePlayer;
        if (p == null) return;
        lockYaw = p.rotationYaw;
        lockPitch = p.rotationPitch;
        camYaw = lockYaw;
        camPitch = lockPitch;
        oldView = mc.gameSettings.thirdPersonView;
        if (thirdPerson.value) mc.gameSettings.thirdPersonView = 1;
        active = true;
    }

    private void stop() {
        if (!active) return;
        active = false;
        EntityPlayer p = mc.thePlayer;
        if (p != null) restore(p);
        mc.gameSettings.thirdPersonView = oldView;
    }

    private void restore(EntityPlayer p) {
        p.rotationYaw = p.prevRotationYaw = lockYaw;
        p.rotationPitch = p.prevRotationPitch = lockPitch;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || key == null) return;
        boolean toggleHit = key.isPressed(); // consumes the press either way
        if (mc.thePlayer == null || mc.theWorld == null) {
            stop();
            return;
        }
        if (lockReason() != null) {
            if (active || toggleHit) {
                stop();
                toggled = false;
                if (toggleHit) {
                    mc.thePlayer.addChatMessage(new ChatComponentText("§b[Lumen] §cFreelook is disabled on Hypixel."));
                }
            }
            return;
        }
        boolean want;
        if (mode.is("Toggle")) {
            if (toggleHit) toggled = !toggled;
            want = toggled;
        } else {
            toggled = false;
            want = key.isKeyDown();
        }
        if (mc.currentScreen != null) want = false;
        if (want && !active) start();
        else if (!want && active) stop();
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        EntityPlayer p = mc.thePlayer;
        if (!active || p == null) return;
        if (e.phase == TickEvent.Phase.START) {
            // the frame (mouse look + camera) works on the camera's rotation ...
            p.rotationYaw = p.prevRotationYaw = camYaw;
            p.rotationPitch = p.prevRotationPitch = camPitch;
        } else {
            // ... then the real rotation goes back
            camYaw = p.rotationYaw;
            camPitch = Math.max(-90f, Math.min(90f, p.rotationPitch));
            restore(p);
        }
    }
}
