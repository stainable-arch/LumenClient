package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Shrinks (or removes) the bobbing of the CAMERA while your hand keeps its full vanilla bob; at 100% the
 * camera shakes like vanilla too. The bobbing
 * amount is driven by the player's camera yaw/pitch values: they're scaled while the world
 * camera is set up, put back to full just before the hand is drawn, and restored after the frame.
 * View bobbing is also forced on for that frame, so the hand bobs even if the vanilla option is
 * off (your options.txt is never changed).
 */
public class MinimalViewBobbing extends Module {
    private final NumberSetting intensity = add(new NumberSetting("Camera Bob %", 100, 0, 100, 5));

    private EntityPlayer player;
    private boolean savedBobbing;
    private float yaw, prevYaw, pitch, prevPitch;

    public MinimalViewBobbing() {
        super("Minimal View Bobbing", "Stops the camera from bobbing while your hand keeps bobbing.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            if (mc.thePlayer == null || mc.gameSettings == null) return;
            player = mc.thePlayer;
            float f = intensity.getFloat() / 100f;
            savedBobbing = mc.gameSettings.viewBobbing;
            yaw = player.cameraYaw;
            prevYaw = player.prevCameraYaw;
            pitch = player.cameraPitch;
            prevPitch = player.prevCameraPitch;
            mc.gameSettings.viewBobbing = true;
            player.cameraYaw = yaw * f;
            player.prevCameraYaw = prevYaw * f;
            player.cameraPitch = pitch * f;
            player.prevCameraPitch = prevPitch * f;
        } else {
            restore();
        }
    }

    /**
     * The world is done and the hand has not been drawn yet: give it the full, unscaled bob again.
     * This runs before vanilla (or 1.7 Animations) draws the hand, and it can't be skipped by another
     * module cancelling the hand event.
     */
    @SubscribeEvent
    public void onWorldLast(RenderWorldLastEvent e) {
        giveHandFullBob();
    }

    /** Backup for the same thing, first in line so it also runs before 1.7 Animations draws the hand. */
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public void onRenderHand(RenderHandEvent e) {
        giveHandFullBob();
    }

    private void giveHandFullBob() {
        if (player == null) return;
        player.cameraYaw = yaw;
        player.prevCameraYaw = prevYaw;
        player.cameraPitch = pitch;
        player.prevCameraPitch = prevPitch;
        mc.gameSettings.viewBobbing = true; // the hand bobs even if the vanilla option is off
    }

    private void restore() {
        if (player == null) return;
        player.cameraYaw = yaw;
        player.prevCameraYaw = prevYaw;
        player.cameraPitch = pitch;
        player.prevCameraPitch = prevPitch;
        mc.gameSettings.viewBobbing = savedBobbing;
        player = null;
    }

    @Override
    protected void onDisable() {
        restore();
    }
}
