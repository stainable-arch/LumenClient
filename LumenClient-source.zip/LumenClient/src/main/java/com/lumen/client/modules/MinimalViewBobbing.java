package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Keeps view bobbing but shrinks it. The bobbing amount is driven by the player's camera
 * yaw/pitch values, so they're scaled for the duration of one rendered frame and restored after.
 * View bobbing is also forced on for that frame, so the module works even if the vanilla
 * option is off (your options.txt is never changed).
 */
public class MinimalViewBobbing extends Module {
    private final NumberSetting intensity = add(new NumberSetting("Intensity %", 0, 0, 100, 1));

    private EntityPlayer player;
    private boolean savedBobbing;
    private float yaw, prevYaw, pitch, prevPitch;

    public MinimalViewBobbing() {
        super("Minimal View Bobbing", "Reduces view bobbing; 0 disables camera bobbing.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            if (mc.thePlayer == null || mc.gameSettings == null) return;
            player = mc.thePlayer;
            float f = intensity.getFloat() / 100f;
            savedBobbing = mc.gameSettings.viewBobbing;
            yaw = player.cameraYaw;
            prevYaw = player.prevCameraYaw;
            pitch = player.cameraPitch;
            prevPitch = player.prevCameraPitch;
            mc.gameSettings.viewBobbing = true;
            player.cameraYaw = yaw * f;
            player.prevCameraYaw = prevYaw * f;
            player.cameraPitch = pitch * f;
            player.prevCameraPitch = prevPitch * f;
        } else {
            restore();
        }
    }

    private void restore() {
        if (player == null) return;
        player.cameraYaw = yaw;
        player.prevCameraYaw = prevYaw;
        player.cameraPitch = pitch;
        player.prevCameraPitch = prevPitch;
        mc.gameSettings.viewBobbing = savedBobbing;
        player = null;
    }

    @Override
    protected void onDisable() {
        restore();
    }
}
