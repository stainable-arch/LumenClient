package com.lumen.client.modules;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Backs the "Minimal View Bobbing" option (Options screen, no configuration): removes the bobbing of the
 * CAMERA while your hand keeps its full vanilla bob. The bobbing
 * amount is driven by the player's camera yaw/pitch values: they're scaled while the world
 * camera is set up, put back to full just before the hand is drawn, and restored after the frame.
 * View bobbing is also forced on for that frame, so the hand bobs even if the vanilla option is
 * off (your options.txt is never changed).
 */
public class MinimalViewBobbing {
    private final Minecraft mc = Minecraft.getMinecraft();

    private EntityPlayer player;
    private boolean savedBobbing;
    private float yaw, prevYaw, pitch, prevPitch;

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            if (!ClientSettings.minimalViewBobbing.value || mc.thePlayer == null || mc.gameSettings == null) return;
            player = mc.thePlayer;
            float f = 0f; // camera bob fully off
            savedBobbing = mc.gameSettings.viewBobbing;
            yaw = player.cameraYaw;
            prevYaw = player.prevCameraYaw;
            pitch = player.cameraPitch;
            prevPitch = player.prevCameraPitch;
            mc.gameSettings.viewBobbing = true;
            player.cameraYaw = yaw * f;
            player.prevCameraYaw = prevYaw * f;
            player.cameraPitch = pitch * f;
            player.prevCameraPitch = prevPitch * f;
        } else {
            restore();
        }
    }

    /**
     * The world is done and the hand has not been drawn yet: give it the full, unscaled bob again.
     * This runs before vanilla (or 1.7 Animations) draws the hand, and it can't be skipped by another
     * module cancelling the hand event.
     */
    @SubscribeEvent
    public void onWorldLast(RenderWorldLastEvent e) {
        giveHandFullBob();
    }

    /** Backup for the same thing, first in line so it also runs before 1.7 Animations draws the hand. */
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public void onRenderHand(RenderHandEvent e) {
        giveHandFullBob();
    }

    private void giveHandFullBob() {
        if (player == null) return;
        player.cameraYaw = yaw;
        player.prevCameraYaw = prevYaw;
        player.cameraPitch = pitch;
        player.prevCameraPitch = prevPitch;
        mc.gameSettings.viewBobbing = true; // the hand bobs even if the vanilla option is off
    }

    private void restore() {
        if (player == null) return;
        player.cameraYaw = yaw;
        player.prevCameraYaw = prevYaw;
        player.cameraPitch = pitch;
        player.prevCameraPitch = prevPitch;
        mc.gameSettings.viewBobbing = savedBobbing;
        player = null;
    }

}
