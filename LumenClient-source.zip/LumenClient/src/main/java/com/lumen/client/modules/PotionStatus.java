package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PotionStatus extends HudModule {
    private static final String[] ROMAN = { "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X" };

    public PotionStatus() {
        super("Potion Status", "Lists your active potion effects with their remaining time.", Category.HUD, 80, 4);
    }

    @Override
    protected void draw() {
        if (mc.thePlayer == null) return;
        Collection<PotionEffect> effects = mc.thePlayer.getActivePotionEffects();
        if (effects.isEmpty()) {
            if (editing()) {
                labelValue("Potions", "(none)");
            } else {
                width = 0;
                height = 0;
            }
            return;
        }

        List<PotionEffect> list = new ArrayList<PotionEffect>(effects);
        int n = list.size();
        String[] names = new String[n];
        String[] times = new String[n];
        float maxName = 0, maxTime = 0;
        for (int i = 0; i < n; i++) {
            PotionEffect pe = list.get(i);
            String name = I18n.format(pe.getEffectName());
            int amp = pe.getAmplifier() + 1;
            if (amp > 1) {
                name += " " + (amp < ROMAN.length ? ROMAN[amp] : String.valueOf(amp));
            }
            names[i] = name;
            times[i] = Potion.getDurationString(pe);
            maxName = Math.max(maxName, RenderUtil.width(names[i]));
            maxTime = Math.max(maxTime, RenderUtil.width(times[i]));
        }

        float rowH = 12f;
        box(11 + maxName + 10 + maxTime + 5, n * rowH + 4);
        for (int i = 0; i < n; i++) {
            PotionEffect pe = list.get(i);
            int rgb = 0xFFFFFF;
            int id = pe.getPotionID();
            if (id >= 0 && id < Potion.potionTypes.length && Potion.potionTypes[id] != null) {
                rgb = Potion.potionTypes[id].getLiquidColor();
            }
            float y = 2 + i * rowH;
            RenderUtil.roundedRect(4, y + 2, 7, y + 9, 1.5f, 0xFF000000 | rgb);
            RenderUtil.string(names[i], 11, y + 1.5f, 0xFFFFFFFF);
            RenderUtil.string(times[i], 11 + maxName + 10, y + 1.5f, pe.getDuration() < 200 ? 0xFFFF6B6B : 0xFFCCCCCC);
        }
    }
}
