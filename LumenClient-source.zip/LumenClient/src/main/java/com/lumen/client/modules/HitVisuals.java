package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.fx.ParticleSystem;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import com.lumen.client.util.CombatTracker;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.Vec3;

import java.util.Random;

/** Spawns a burst of particles on the spot where you land a hit. */
public class HitVisuals extends Module implements CombatTracker.HitListener {
    private final ModeSetting style = add(new ModeSetting("Style", "Sparks", "Sparks", "Stars", "Hearts", "Crit", "Blood"));
    private final NumberSetting amount = add(new NumberSetting("Amount", 14, 4, 40, 1));
    private final NumberSetting glow = add(new NumberSetting("Glow", 4, 0, 10, 1));

    private final Random rand = new Random();

    public HitVisuals() {
        super("Hit Visuals", "Particle burst where you hit an enemy (sparks, stars, hearts, crits or blood).", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        CombatTracker.addListener(this);
    }

    @Override
    protected void onDisable() {
        CombatTracker.removeListener(this);
    }

    @Override
    public void onHit(EntityLivingBase target, Vec3 hitVec) {
        if (mc.theWorld == null) return;
        double x, y, z;
        if (hitVec != null) {
            x = hitVec.xCoord;
            y = hitVec.yCoord;
            z = hitVec.zCoord;
        } else {
            x = target.posX;
            y = target.posY + target.height * 0.6;
            z = target.posZ;
        }
        int n = amount.getInt();
        Theme th = Theme.current();

        if (style.is("Crit")) {
            for (int i = 0; i < n; i++) {
                mc.theWorld.spawnParticle(EnumParticleTypes.CRIT, x, y, z,
                        (rand.nextDouble() - 0.5) * 0.9, rand.nextDouble() * 0.6, (rand.nextDouble() - 0.5) * 0.9);
            }
        } else if (style.is("Blood")) {
            int stateId = Block.getStateId(Blocks.redstone_block.getDefaultState());
            for (int i = 0; i < n; i++) {
                mc.theWorld.spawnParticle(EnumParticleTypes.BLOCK_CRACK, x, y, z,
                        (rand.nextDouble() - 0.5) * 0.5, rand.nextDouble() * 0.3, (rand.nextDouble() - 0.5) * 0.5, stateId);
            }
        } else if (style.is("Hearts")) {
            int[] pinks = { 0xFF6FA8, 0xFF9EC8, 0xFFC2DB, 0xFF4F94 };
            for (int i = 0; i < Math.max(3, n / 3); i++) {
                ParticleSystem.INSTANCE.spawn(new ParticleSystem.Particle(
                        x + (rand.nextDouble() - 0.5) * 0.4, y + rand.nextDouble() * 0.3, z + (rand.nextDouble() - 0.5) * 0.4,
                        (rand.nextDouble() - 0.5) * 0.05, 0.05 + rand.nextDouble() * 0.05, (rand.nextDouble() - 0.5) * 0.05,
                        0.07f + rand.nextFloat() * 0.06f, 22 + rand.nextInt(14), ParticleSystem.HEART,
                        pinks[rand.nextInt(pinks.length)]).physics(-0.002f, 0.94f, 0.003f).spin((float) rand.nextGaussian() * 3f)
                        .glow(glow.getFloat() / 10f));
            }
        } else {
            boolean stars = style.is("Stars");
            for (int i = 0; i < n; i++) {
                double ang = rand.nextDouble() * Math.PI * 2;
                double pitch = (rand.nextDouble() - 0.35) * Math.PI;
                double speed = 0.08 + rand.nextDouble() * 0.12;
                double vx = Math.cos(ang) * Math.cos(pitch) * speed;
                double vy = Math.sin(pitch) * speed + 0.03;
                double vz = Math.sin(ang) * Math.cos(pitch) * speed;
                int sprite = stars ? ParticleSystem.STAR : (rand.nextFloat() < 0.6f ? ParticleSystem.SPARKLE : ParticleSystem.STAR);
                int color = stars ? (rand.nextBoolean() ? 0xFFE066 : 0xFFFFFF) : Colors.gradient(th, rand.nextFloat());
                float size = stars ? 0.06f + rand.nextFloat() * 0.05f : 0.04f + rand.nextFloat() * 0.05f;
                ParticleSystem.INSTANCE.spawn(new ParticleSystem.Particle(x, y, z, vx, vy, vz, size,
                        10 + rand.nextInt(10), sprite, color).physics(0.018f, 0.84f, 0f).spin((float) rand.nextGaussian() * 8f)
                        .glow(glow.getFloat() / 10f));
            }
        }
    }
}
