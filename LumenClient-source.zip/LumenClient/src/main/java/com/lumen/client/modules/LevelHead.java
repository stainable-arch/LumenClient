package com.lumen.client.modules;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lumen.client.ClientSettings;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Shows each player's level above their name tag: the Hypixel network level, or the level on
 * bedwarspractice.club (Voxyl), chosen with the Source setting.
 *
 * Hypixel levels come from the official Hypixel API (free key from developer.hypixel.net, set with
 * /lumen apikey YOUR-KEY). Bedwars Practice levels come from the Voxyl API (/lumen voxylkey YOUR-KEY). Lookups run on a background
 * thread, are throttled, and are cached, so the game never waits on the network.
 */
public class LevelHead extends Module {
    private final ModeSetting source = add(new ModeSetting("Source", "Hypixel", "Hypixel", "Bedwars Practice"));
    private final BooleanSetting showSelf = add(new BooleanSetting("Show On Self", false));
    private final BooleanSetting decimals = add(new BooleanSetting("Decimals", false));
    private final BooleanSetting background = add(new BooleanSetting("Background", true));
    private final BooleanSetting hypixelOnly = add(new BooleanSetting("Server Only", true));
    private final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.6, 2.0, 0.1));

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final long REFRESH_MS = 10L * 60L * 1000L;

    private static final class Entry {
        volatile double level = -1;
        volatile long fetchedAt;
        volatile long retryAt;
        volatile boolean pending;
    }

    private static final Map<UUID, Entry> CACHE = new ConcurrentHashMap<UUID, Entry>();
    private static final BlockingQueue<UUID> QUEUE = new LinkedBlockingQueue<UUID>();
    private static volatile long rateLimitedUntil;
    private static volatile boolean warnedKey;
    private static volatile boolean practice;
    private boolean lastPractice;

    private volatile boolean running;
    private Thread worker;

    public LevelHead() {
        super("Level Head", "Shows the Hypixel or Bedwars Practice level above players (needs /lumen key <your key>).", Category.VISUALS);
    }

    /** Called when the API key changes: forget everything so players are looked up again. */
    public static void resetCache() {
        CACHE.clear();
        QUEUE.clear();
        warnedKey = false;
        rateLimitedUntil = 0;
    }

    @Override
    protected void onEnable() {
        running = true;
        warnedKey = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                work();
            }
        }, "Lumen-LevelHead");
        worker.setDaemon(true);
        worker.start();
        if (source.is("Bedwars Practice")) {
            if (ClientSettings.voxylKey.isEmpty()) {
                chat("\u00a7eLevel Head (Bedwars Practice) needs a Voxyl API key, then type \u00a7f/lumen key <your key>");
            }
        } else if (ClientSettings.hypixelKey.isEmpty()) {
            chat("\u00a7eLevel Head needs a Hypixel API key. Get a free one at developer.hypixel.net, then type \u00a7f/lumen key <your key>");
        }
    }

    @Override
    protected void onDisable() {
        running = false;
        if (worker != null) worker.interrupt();
        worker = null;
    }

    // ------------------------------------------------------------------------------------------
    // rendering
    // ------------------------------------------------------------------------------------------

    private boolean onHypixel() {
        ServerData sd = mc.getCurrentServerData();
        return sd != null && sd.serverIP != null && sd.serverIP.toLowerCase(Locale.ROOT).contains("hypixel");
    }

    private boolean onPracticeServer() {
        ServerData sd = mc.getCurrentServerData();
        if (sd == null || sd.serverIP == null) return false;
        String ip = sd.serverIP.toLowerCase(Locale.ROOT);
        return ip.contains("bedwarspractice") || ip.contains("voxyl");
    }

    @SubscribeEvent
    public void onSpecials(RenderLivingEvent.Specials.Post e) {
        EntityLivingBase ent = e.entity;
        if (!(ent instanceof EntityPlayer) || mc.thePlayer == null || mc.getNetHandler() == null) return;
        if (ent == mc.thePlayer && !showSelf.value) return;
        if (ent.isInvisible() || ent.isDead) return;
        boolean prac = source.is("Bedwars Practice");
        if (prac != lastPractice) {
            // the source changed: forget the other service's levels
            lastPractice = prac;
            resetCache();
        }
        practice = prac;
        if (hypixelOnly.value && !(prac ? onPracticeServer() : onHypixel())) return;
        if (ent.getDistanceSqToEntity(mc.thePlayer) > 64.0 * 64.0) return;

        UUID id = ent.getUniqueID();
        // real players have version-4 UUIDs and are in the tab list; NPCs are neither
        if (id.version() != 4 || mc.getNetHandler().getPlayerInfo(id) == null) return;
        if ((prac ? ClientSettings.voxylKey : ClientSettings.hypixelKey).isEmpty()) return;

        long now = System.currentTimeMillis();
        Entry en = CACHE.get(id);
        if (en == null) {
            en = new Entry();
            en.pending = true;
            CACHE.put(id, en);
            QUEUE.offer(id);
        } else if (!en.pending && now >= en.retryAt && (en.level < 0 || now - en.fetchedAt > REFRESH_MS)) {
            en.pending = true;
            QUEUE.offer(id);
        }
        if (en.level < 0) return;

        String value = decimals.value ? String.format(Locale.ROOT, "%.2f", en.level) : String.valueOf((int) Math.floor(en.level));
        draw(ent, e.x, e.y, e.z, "Level: ", value);
    }

    private void draw(EntityLivingBase ent, double x, double y, double z, String prefix, String value) {
        FontRenderer fr = mc.fontRendererObj;
        RenderManager rm = mc.getRenderManager();
        int pw = fr.getStringWidth(prefix);
        int half = (pw + fr.getStringWidth(value)) / 2;
        float s = 0.016666668f * 1.6f * scale.getFloat();
        int accent = 0xFF000000 | Theme.current().c1;

        GlStateManager.pushMatrix();
        // the vanilla name tag sits at height + 0.5; this goes on the line above it
        GlStateManager.translate((float) x, (float) y + ent.height + 0.5f + 0.3f * scale.getFloat(), (float) z);
        GL11.glNormal3f(0f, 1f, 0f);
        GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
        GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
        GlStateManager.scale(-s, -s, s);
        GlStateManager.disableLighting();
        GlStateManager.depthMask(false);
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (background.value) {
            GlStateManager.disableTexture2D();
            Tessellator t = Tessellator.getInstance();
            WorldRenderer wr = t.getWorldRenderer();
            wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
            wr.pos(-half - 2, -1, 0).color(0f, 0f, 0f, 0.3f).endVertex();
            wr.pos(-half - 2, 9, 0).color(0f, 0f, 0f, 0.3f).endVertex();
            wr.pos(half + 2, 9, 0).color(0f, 0f, 0f, 0.3f).endVertex();
            wr.pos(half + 2, -1, 0).color(0f, 0f, 0f, 0.3f).endVertex();
            t.draw();
            GlStateManager.enableTexture2D();
        }

        // faint copy visible through walls, then the solid one where nothing is in the way
        fr.drawString(prefix, -half, 0, (accent & 0x00FFFFFF) | 0x40000000);
        fr.drawString(value, -half + pw, 0, 0x40FFFFFF);
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        fr.drawString(prefix, -half, 0, accent);
        fr.drawString(value, -half + pw, 0, 0xFFFFFFFF);

        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    // ------------------------------------------------------------------------------------------
    // background lookups
    // ------------------------------------------------------------------------------------------

    private void work() {
        while (running) {
            try {
                UUID id = QUEUE.poll(1, TimeUnit.SECONDS);
                if (id == null) continue;
                long wait = rateLimitedUntil - System.currentTimeMillis();
                if (wait > 0) Thread.sleep(Math.min(wait, 30000L));
                fetch(id);
                Thread.sleep(600); // stay well under the API's request limit
            } catch (InterruptedException ie) {
                return;
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    private void fetch(UUID id) {
        if (practice) fetchVoxyl(id);
        else fetchHypixel(id);
    }

    private void fetchHypixel(UUID id) {
        Entry en = CACHE.get(id);
        if (en == null) return;
        long now = System.currentTimeMillis();
        String key = ClientSettings.hypixelKey;
        if (key.isEmpty()) {
            en.retryAt = now + 5000;
            en.pending = false;
            return;
        }
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://api.hypixel.net/v2/player?uuid=" + id.toString().replace("-", "")).openConnection();
            c.setRequestProperty("API-Key", key);
            c.setRequestProperty("User-Agent", "LumenClient");
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            int code = c.getResponseCode();
            if (code == 200) {
                JsonObject o = new JsonParser().parse(new InputStreamReader(c.getInputStream(), UTF8)).getAsJsonObject();
                double exp = 0;
                JsonElement pl = o.get("player");
                if (pl != null && pl.isJsonObject() && pl.getAsJsonObject().has("networkExp")) {
                    exp = pl.getAsJsonObject().get("networkExp").getAsDouble();
                }
                // Hypixel's level formula
                en.level = 1.0 + (-8750.0 + Math.sqrt(8750.0 * 8750.0 + 5000.0 * exp)) / 2500.0;
                en.fetchedAt = System.currentTimeMillis();
            } else if (code == 403) {
                en.retryAt = now + 30000;
                if (!warnedKey) {
                    warnedKey = true;
                    chat("\u00a7cHypixel rejected your API key. Set a valid one with \u00a7f/lumen key <your key>");
                }
            } else if (code == 429) {
                rateLimitedUntil = now + 20000;
                en.retryAt = now + 20000;
            } else {
                en.retryAt = now + 60000;
            }
        } catch (Exception ex) {
            en.retryAt = now + 60000;
        } finally {
            if (c != null) c.disconnect();
            en.pending = false;
        }
    }

    /**
     * Bedwars Practice (Voxyl) level. The endpoint paths below follow the public Voxyl API clients;
     * each is tried in turn, and the level is read from whichever JSON field is called "level".
     */
    private static final String[] VOXYL_PATHS = {
            "https://api.voxyl.net/player/stats/overall/%s?api=%s",
            "https://api.voxyl.net/player/info/%s?api=%s"
    };

    private void fetchVoxyl(UUID id) {
        Entry en = CACHE.get(id);
        if (en == null) return;
        long now = System.currentTimeMillis();
        String key = ClientSettings.voxylKey;
        if (key.isEmpty()) {
            en.retryAt = now + 5000;
            en.pending = false;
            return;
        }
        String plain = id.toString().replace("-", "");
        try {
            for (String pattern : VOXYL_PATHS) {
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(String.format(Locale.ROOT, pattern, plain, key)).openConnection();
                    c.setRequestProperty("User-Agent", "LumenClient");
                    c.setConnectTimeout(6000);
                    c.setReadTimeout(6000);
                    int code = c.getResponseCode();
                    if (code == 200) {
                        JsonElement root = new JsonParser().parse(new InputStreamReader(c.getInputStream(), UTF8));
                        double lvl = findLevel(root, 0);
                        if (lvl >= 0) {
                            en.level = lvl;
                            en.fetchedAt = System.currentTimeMillis();
                            return;
                        }
                    } else if (code == 401 || code == 403) {
                        en.retryAt = now + 30000;
                        if (!warnedKey) {
                            warnedKey = true;
                            chat("\u00a7cVoxyl rejected your API key. Set a valid one with \u00a7f/lumen key <your key>");
                        }
                        return;
                    } else if (code == 429) {
                        rateLimitedUntil = now + 20000;
                        en.retryAt = now + 20000;
                        return;
                    }
                    // 404 / other: try the next path
                } finally {
                    if (c != null) c.disconnect();
                }
            }
            en.retryAt = now + 60000; // nothing worked (unknown player, or the API changed)
        } catch (Exception ex) {
            en.retryAt = now + 60000;
        } finally {
            en.pending = false;
        }
    }

    /** Depth-first search for a numeric field named "level" anywhere in the response; -1 if none. */
    private static double findLevel(JsonElement e, int depth) {
        if (e == null || depth > 4 || !e.isJsonObject()) return -1;
        JsonObject o = e.getAsJsonObject();
        JsonElement lv = o.get("level");
        if (lv != null && lv.isJsonPrimitive() && lv.getAsJsonPrimitive().isNumber()) return lv.getAsDouble();
        for (Map.Entry<String, JsonElement> en : o.entrySet()) {
            double r = findLevel(en.getValue(), depth + 1);
            if (r >= 0) return r;
        }
        return -1;
    }

    private void chat(final String msg) {
        mc.addScheduledTask(new Runnable() {
            @Override
            public void run() {
                if (mc.thePlayer != null) {
                    mc.thePlayer.addChatMessage(new ChatComponentText("\u00a7b[Lumen] \u00a7r" + msg));
                }
            }
        });
    }
}
