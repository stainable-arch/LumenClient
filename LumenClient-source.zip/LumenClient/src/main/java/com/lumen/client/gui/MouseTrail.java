package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A soft glowing trail behind the mouse cursor, drawn on top of every screen (title screen, world and
 * server lists, resource packs, options, the ClickGUI ...) in the current theme's colour.
 * Always on, not a module.
 */
public final class MouseTrail {
    public static final MouseTrail INSTANCE = new MouseTrail();

    private static final long LIFE_MS = 450L;
    private static final float SPACING = 3f;
    private static final int MAX_POINTS = 90;

    private static final class Point {
        final float x, y;
        final long born;

        Point(float x, float y, long born) {
            this.x = x;
            this.y = y;
            this.born = born;
        }
    }

    private final List<Point> points = new ArrayList<Point>();
    private float lastX = Float.NaN, lastY = Float.NaN;

    private MouseTrail() {}

    @SubscribeEvent
    public void onDraw(GuiScreenEvent.DrawScreenEvent.Post e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (e.gui == null || e.gui instanceof GuiChat) return;

        // exact (non-integer) cursor position in scaled GUI units
        ScaledResolution sr = new ScaledResolution(mc);
        float sw = sr.getScaledWidth(), sh = sr.getScaledHeight();
        float x = Mouse.getX() * sw / (float) mc.displayWidth;
        float y = sh - Mouse.getY() * sh / (float) mc.displayHeight - 1f;
        long now = System.currentTimeMillis();

        // add points along the movement since last frame so fast swipes stay continuous
        if (!Float.isNaN(lastX)) {
            float dx = x - lastX, dy = y - lastY;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist >= SPACING) {
                int n = Math.min(40, (int) (dist / SPACING));
                for (int i = 1; i <= n; i++) {
                    float f = i / (float) n;
                    points.add(new Point(lastX + dx * f, lastY + dy * f, now));
                }
                lastX = x;
                lastY = y;
            }
        } else {
            lastX = x;
            lastY = y;
        }
        while (points.size() > MAX_POINTS) points.remove(0);

        Theme th = Theme.current();
        int col = Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.3f);

        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        Iterator<Point> it = points.iterator();
        while (it.hasNext()) {
            Point p = it.next();
            float f = (now - p.born) / (float) LIFE_MS;
            if (f >= 1f) {
                it.remove();
                continue;
            }
            float fade = (1f - f) * (1f - f);
            int al = (int) (62 * fade);
            if (al < 3) continue; // invisible anyway, skip the draw
            RenderUtil.glow(p.x, p.y, 7f + 9f * (1f - f), Colors.withAlpha(col, al));
        }
        // soft light right at the cursor
        RenderUtil.glow(x, y, 30f, Colors.withAlpha(col, 40));
        GlStateManager.enableDepth();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
