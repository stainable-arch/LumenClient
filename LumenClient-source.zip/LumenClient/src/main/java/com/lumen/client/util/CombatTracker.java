package com.lumen.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Detects confirmed hits purely on the client: when you left-click an entity we wait for that
 * entity's hurt animation to start (the server confirmed the damage). Feeds Hit Visuals,
 * Combo Counter and Reach Display. No packets are touched.
 */
public final class CombatTracker {
    public static final CombatTracker INSTANCE = new CombatTracker();

    public interface HitListener {
        void onHit(EntityLivingBase target, Vec3 hitVec);
    }

    public static int combo;
    public static int bestCombo;
    /** Distance from your eyes to the point you hit on the target's hitbox. 0 = nothing yet. */
    public static double lastReach;
    public static long lastHitTime;

    private static final List<HitListener> LISTENERS = new CopyOnWriteArrayList<HitListener>();

    private static final class Pending {
        EntityLivingBase target;
        Vec3 hitVec;
        double reach;
        int hurtAtClick;
        int age;
    }

    private final Minecraft mc = Minecraft.getMinecraft();
    private final List<Pending> pending = new ArrayList<Pending>();
    private int lastHurt;

    private CombatTracker() {}

    public static void addListener(HitListener l) {
        if (!LISTENERS.contains(l)) LISTENERS.add(l);
    }

    public static void removeListener(HitListener l) {
        LISTENERS.remove(l);
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate || e.button != 0) return;
        if (mc.currentScreen != null || mc.thePlayer == null) return;
        MovingObjectPosition mop = mc.objectMouseOver;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY) return;
        if (!(mop.entityHit instanceof EntityLivingBase)) return;

        Pending p = new Pending();
        p.target = (EntityLivingBase) mop.entityHit;
        p.hitVec = mop.hitVec;
        p.reach = mop.hitVec != null
                ? mc.thePlayer.getPositionEyes(1.0F).distanceTo(mop.hitVec)
                : mc.thePlayer.getDistanceToEntity(mop.entityHit);
        p.hurtAtClick = p.target.hurtTime;
        if (pending.size() > 8) pending.remove(0);
        pending.add(p);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        EntityPlayerSP me = mc.thePlayer;
        if (me == null || mc.theWorld == null) {
            pending.clear();
            combo = 0;
            return;
        }

        // we got hit -> combo is over
        if (me.maxHurtTime > 0 && me.hurtTime > lastHurt && me.hurtTime >= me.maxHurtTime - 1) {
            combo = 0;
        }
        lastHurt = me.hurtTime;
        if (combo > 0 && System.currentTimeMillis() - lastHitTime > 2500L) {
            combo = 0;
        }

        for (Iterator<Pending> it = pending.iterator(); it.hasNext(); ) {
            Pending p = it.next();
            p.age++;
            if (p.target.isDead || p.age > 12) it.remove();
        }

        boolean again = true;
        while (again) {
            again = false;
            for (Pending p : pending) {
                EntityLivingBase t = p.target;
                if (t.maxHurtTime > 0 && t.hurtTime >= t.maxHurtTime - 2 && p.hurtAtClick < t.maxHurtTime - 2) {
                    registerHit(p);
                    // drop every other pending click on the same target (spam clicking = one hit)
                    for (Iterator<Pending> it = pending.iterator(); it.hasNext(); ) {
                        if (it.next().target == t) it.remove();
                    }
                    again = true;
                    break;
                }
            }
        }
    }

    private void registerHit(Pending p) {
        combo++;
        if (combo > bestCombo) bestCombo = combo;
        lastReach = p.reach;
        lastHitTime = System.currentTimeMillis();
        for (HitListener l : LISTENERS) {
            l.onHit(p.target, p.hitVec);
        }
    }
}
