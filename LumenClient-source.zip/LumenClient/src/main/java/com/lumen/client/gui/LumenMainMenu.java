package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.Random;
import java.util.UUID;

/**
 * Replacement title screen: near-black themed background with drifting wave ribbons and outlined
 * stars, the Lumen logo, text-only menu entries and your own skin on the right.
 */
public class LumenMainMenu extends GuiScreen {
    private static final String[] ITEMS = { "Singleplayer", "Multiplayer", "Minecraft Settings", "Client", "Quit Game" };
    /** Vertical position of every entry as a fraction of the screen height. */
    private static final float[] ITEM_Y = { 0.419f, 0.482f, 0.560f, 0.623f, 0.692f };
    private static final float[] ITEM_BRIGHT = { 1f, 1f, 0.72f, 0.72f, 0.72f };

    private static final int STAR_COUNT = 26;

    private final float[] hover = new float[ITEMS.length];
    private final float[][] stars = new float[STAR_COUNT][6]; // x, y, size, speed, rotation, spin

    private ModelPlayer modelWide, modelSlim;
    private ResourceLocation skin;
    private boolean slim;

    private long start = System.currentTimeMillis();
    private long last = start;
    private float fade;

    public LumenMainMenu() {
        Random r = new Random(7L);
        for (float[] s : stars) {
            s[0] = r.nextFloat();
            s[1] = r.nextFloat();
            s[2] = 3f + r.nextFloat() * r.nextFloat() * 11f;
            s[3] = 0.004f + r.nextFloat() * 0.01f;
            s[4] = r.nextFloat() * 360f;
            s[5] = (r.nextFloat() - 0.5f) * 14f;
        }
    }

    @Override
    public void initGui() {
        super.initGui();
        if (modelWide == null) {
            modelWide = new ModelPlayer(0f, false);
            modelSlim = new ModelPlayer(0f, true);
        }
        loadSkin();
    }

    private void loadSkin() {
        final GameProfile profile = mc.getSession().getProfile();
        UUID id = EntityPlayer.getUUID(profile);
        skin = DefaultPlayerSkin.getDefaultSkin(id);
        slim = "slim".equals(DefaultPlayerSkin.getSkinType(id));
        mc.getSkinManager().loadProfileTextures(profile, new SkinManager.SkinAvailableCallback() {
            @Override
            public void skinAvailable(MinecraftProfileTexture.Type type, ResourceLocation location, MinecraftProfileTexture tex) {
                if (type == MinecraftProfileTexture.Type.SKIN) {
                    skin = location;
                    slim = "slim".equals(tex.getMetadata("model"));
                }
            }
        }, true);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static int tint() {
        Theme th = Theme.current();
        return Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now - start) / 1000f;
        fade = Math.min(1f, fade + dt * 2.2f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        Theme th = Theme.current();
        int tint = tint();
        float k = height / 254f; // everything scales with the screen

        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // background: almost black, tinted with the theme
        RenderUtil.gradientV(0, 0, width, height,
                Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.11f));

        drawWaves(t, tint, e);
        drawStars(dt, tint, e);

        // ---- title: logo + name ----
        float logo = 24f * k;
        float tScale = 1.9f * k;
        String first = "\u00a7oLumen";
        String rest = " Client";
        float tw = LumenFont.width(first) * tScale + LumenFont.width(rest) * tScale;
        float gap = 9f * k;
        float tx = (width - (logo + gap + tw)) / 2f;
        float ty = height * 0.307f - logo / 2f + (1f - e) * 6f;
        RenderUtil.roundedRectH(tx, ty, tx + logo, ty + logo, 7f * k, Colors.mulAlpha(Colors.opaque(th.c1), e), Colors.mulAlpha(Colors.opaque(th.c3), e));
        float ls = 2.2f * k;
        text("L", tx + (logo - LumenFont.width("L") * ls) / 2f, ty + (logo - LumenFont.EM * ls) / 2f - 1f * k, ls, Colors.mulAlpha(0xFF0B1020, e));
        float textY = ty + (logo - LumenFont.EM * tScale) / 2f - 1f * k;
        text(first, tx + logo + gap, textY, tScale, Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f), e));
        text(rest, tx + logo + gap + LumenFont.width(first) * tScale, textY, tScale, Colors.mulAlpha(0xFFFFFFFF, e));

        // ---- menu entries (text only) ----
        float iScale = 1.05f * k;
        for (int i = 0; i < ITEMS.length; i++) {
            float w = LumenFont.width(ITEMS[i]) * iScale;
            float cy = height * ITEM_Y[i] + (1f - e) * 6f;
            boolean hov = overItem(i, mouseX, mouseY);
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * Math.min(1f, dt * 14f);
            float h = hover[i];

            float base = ITEM_BRIGHT[i];
            int dim = Colors.lerp(0xFF000000, 0xFFFFFFFF, 0.55f + 0.45f * base);
            int col = Colors.lerp(dim, 0xFFFFFFFF, h);
            float sc = iScale * (1f + 0.05f * h);
            float sw = LumenFont.width(ITEMS[i]) * sc;
            text(ITEMS[i], (width - sw) / 2f, cy - LumenFont.EM * sc / 2f, sc, Colors.mulAlpha(col, e));
            if (h > 0.02f) {
                float lw = sw * h;
                float ly = cy + LumenFont.EM * sc / 2f + 2f * k;
                RenderUtil.gradientH((width - lw) / 2f, ly, (width + lw) / 2f, ly + Math.max(1f, k * 0.9f),
                        Colors.mulAlpha(Colors.opaque(th.c1), e), Colors.mulAlpha(Colors.opaque(th.c3), e));
            }
        }

        // ---- player (skin only, no name tag) ----
        drawPlayer(width * 0.75f, height * 0.77f, height * 0.265f, mouseX, mouseY, t, e);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Big translucent ribbons that sway slowly at the left and right edges. */
    private void drawWaves(float t, int tint, float e) {
        int ribbonCol = Colors.lerp(tint, 0xFFFFFFFF, 0.3f);
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        float step = 6f;
        for (int side = 0; side < 2; side++) {
            for (int i = 0; i < 6; i++) {
                float phase = i * 0.28f + side * 1.7f;
                float half = width * 0.021f;
                int a = (int) ((16 + i * 4) * e);
                wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
                for (float y = 0; y < height; y += step) {
                    float y2 = y + step;
                    float c1 = waveX(i, y, t, phase);
                    float c2 = waveX(i, y2, t, phase);
                    if (side == 1) {
                        c1 = width - c1;
                        c2 = width - c2;
                    }
                    int cr = Colors.channel(ribbonCol, 16), cg = Colors.channel(ribbonCol, 8), cb = Colors.channel(ribbonCol, 0);
                    // left half (transparent edge -> bright centre), then right half
                    wr.pos(c1 - half, y, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c1, y, 0).color(cr, cg, cb, a).endVertex();
                    wr.pos(c2, y2, 0).color(cr, cg, cb, a).endVertex();
                    wr.pos(c2 - half, y2, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c1, y, 0).color(cr, cg, cb, a).endVertex();
                    wr.pos(c1 + half, y, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c2 + half, y2, 0).color(cr, cg, cb, 0).endVertex();
                    wr.pos(c2, y2, 0).color(cr, cg, cb, a).endVertex();
                }
                tess.draw();
            }
        }
        GlStateManager.shadeModel(7424);
        GlStateManager.enableTexture2D();
    }

    private float waveX(int i, float y, float t, float phase) {
        float yy = y / height;
        float swing = 0.5f + 0.5f * (float) Math.sin(yy * 5.2f + t * 0.22f + phase);
        return width * (0.02f + 0.047f * i) + width * 0.13f * swing;
    }

    /** Small drifting five-pointed star outlines in the theme colours. */
    private void drawStars(float dt, int tint, float e) {
        Theme th = Theme.current();
        int[] cols = { Colors.opaque(th.c1), Colors.opaque(th.c2), Colors.opaque(th.c3) };
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glLineWidth(Math.max(1f, height / 254f * 0.9f));
        float k = height / 254f;
        for (int n = 0; n < stars.length; n++) {
            float[] s = stars[n];
            s[1] -= s[3] * dt;
            s[0] += (float) Math.sin(s[4] * 0.02f + s[1] * 6f) * 0.0004f;
            s[4] += s[5] * dt;
            if (s[1] < -0.05f) {
                s[1] = 1.05f;
            }
            float size = s[2] * k;
            int col = Colors.lerp(cols[n % 3], 0xFFFFFFFF, 0.35f);
            int a = (int) ((60 + 18 * (n % 5)) * e * Math.min(1f, s[2] / 8f + 0.3f));
            GlStateManager.color(Colors.channel(col, 16) / 255f, Colors.channel(col, 8) / 255f, Colors.channel(col, 0) / 255f, a / 255f);
            GL11.glBegin(GL11.GL_LINE_LOOP);
            for (int v = 0; v < 10; v++) {
                double ang = Math.toRadians(s[4]) - Math.PI / 2 + v * Math.PI / 5;
                double rad = (v % 2 == 0) ? size : size * 0.45;
                GL11.glVertex2d(s[0] * width + Math.cos(ang) * rad, s[1] * height + Math.sin(ang) * rad);
            }
            GL11.glEnd();
        }
        GL11.glLineWidth(1f);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawPlayer(float cx, float footY, float s, int mouseX, int mouseY, float t, float e) {
        if (skin == null || modelWide == null) return;
        ModelPlayer m = slim ? modelSlim : modelWide;

        // soft shadow on the "floor"
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, footY + 1f, 0f);
        GlStateManager.scale(1f, 0.1f, 1f);
        RenderUtil.circle(0f, 0f, s * 0.62f, Colors.withAlpha(tint(), (int) (46 * e)));
        GlStateManager.popMatrix();

        // idle pose + head follows the cursor (rotations in radians)
        float lookX = Math.max(-1f, Math.min(1f, (mouseX - cx) / (width * 0.4f)));
        float lookY = Math.max(-1f, Math.min(1f, (mouseY - (footY - s * 1.8f)) / (height * 0.4f)));
        float breathe = (float) Math.sin(t * 1.3f) * 0.04f;
        m.bipedHead.rotateAngleY = -lookX * 0.7f;
        m.bipedHead.rotateAngleX = lookY * 0.4f;
        m.bipedHeadwear.rotateAngleY = m.bipedHead.rotateAngleY;
        m.bipedHeadwear.rotateAngleX = m.bipedHead.rotateAngleX;
        m.bipedRightArm.rotateAngleZ = 0.05f + breathe;
        m.bipedLeftArm.rotateAngleZ = -0.05f - breathe;
        m.bipedRightArmwear.rotateAngleZ = m.bipedRightArm.rotateAngleZ;
        m.bipedLeftArmwear.rotateAngleZ = m.bipedLeftArm.rotateAngleZ;

        float yaw = -lookX * 14f + (float) Math.sin(t * 0.5f) * 5f;

        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.clear(256);
        GlStateManager.enableColorMaterial();
        GlStateManager.enableRescaleNormal();
        GlStateManager.pushMatrix();
        // model units are 1/16 block; the figure is 2 blocks tall and its feet are 1.5 below its origin
        GlStateManager.translate(cx, footY - 1.5f * s + (1f - e) * 8f, 100f);
        GlStateManager.scale(-s, s, s);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(180f, 0f, 1f, 0f);
        GlStateManager.rotate(yaw, 0f, 1f, 0f);
        GlStateManager.color(1f, 1f, 1f, 1f);
        mc.getTextureManager().bindTexture(skin);
        float f = 0.0625f;
        m.bipedHead.render(f);
        m.bipedBody.render(f);
        m.bipedRightArm.render(f);
        m.bipedLeftArm.render(f);
        m.bipedRightLeg.render(f);
        m.bipedLeftLeg.render(f);
        m.bipedHeadwear.render(f);
        m.bipedBodyWear.render(f);
        m.bipedRightArmwear.render(f);
        m.bipedLeftArmwear.render(f);
        m.bipedRightLegwear.render(f);
        m.bipedLeftLegwear.render(f);
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.disableColorMaterial();
        GlStateManager.disableDepth();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    private boolean overItem(int i, int mx, int my) {
        float k = height / 254f;
        float w = LumenFont.width(ITEMS[i]) * 1.05f * k;
        float cy = height * ITEM_Y[i];
        float pad = 12f * k;
        return mx >= (width - w) / 2f - pad && mx <= (width + w) / 2f + pad
                && my >= cy - 9f * k && my <= cy + 9f * k;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        for (int i = 0; i < ITEMS.length; i++) {
            if (!overItem(i, mouseX, mouseY)) continue;
            Sounds.click();
            switch (i) {
                case 0:
                    mc.displayGuiScreen(new GuiSelectWorld(this));
                    break;
                case 1:
                    mc.displayGuiScreen(new GuiMultiplayer(this));
                    break;
                case 2:
                    mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
                    break;
                case 3:
                    mc.displayGuiScreen(new ClickGui());
                    break;
                default:
                    mc.shutdown();
                    break;
            }
            return;
        }
    }
}
