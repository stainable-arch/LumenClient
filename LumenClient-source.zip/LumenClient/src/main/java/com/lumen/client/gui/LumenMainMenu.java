package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.Random;

/**
 * Replacement title screen: near-black themed background with drifting wave ribbons and outlined
 * stars, the Lumen title and text-only menu entries.
 */
public class LumenMainMenu extends GuiScreen {
    private static final String[] ITEMS = { "Singleplayer", "Multiplayer", "Minecraft Settings", "Client", "Quit Game" };
    /** Vertical position of every entry as a fraction of the screen height. */
    private static final float[] ITEM_Y = { 0.419f, 0.482f, 0.560f, 0.623f, 0.692f };
    private static final float[] ITEM_BRIGHT = { 1f, 1f, 0.72f, 0.72f, 0.72f };

    private static final int STAR_COUNT = 26;

    private final float[] hover = new float[ITEMS.length];
    private final float[][] stars = new float[STAR_COUNT][6]; // x, y, size, speed, rotation, spin

    private long start = System.currentTimeMillis();
    private long last = start;
    private float fade;
    /** Smoothed mouse position (-1..1) for the background parallax. */
    private float parX, parY;

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (float) Math.pow(1f - x, 3);
    }

    public LumenMainMenu() {
        Random r = new Random(7L);
        for (float[] s : stars) {
            s[0] = r.nextFloat();
            s[1] = r.nextFloat();
            s[2] = 3f + r.nextFloat() * r.nextFloat() * 11f;
            s[3] = 0.004f + r.nextFloat() * 0.01f;
            s[4] = r.nextFloat() * 360f;
            s[5] = (r.nextFloat() - 0.5f) * 14f;
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static int tint() {
        Theme th = Theme.current();
        return Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now - start) / 1000f;
        fade = Math.min(1f, fade + dt * 2.2f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        float pk = Math.min(1f, dt * 3f);
        parX += (((float) mouseX / Math.max(1, width) - 0.5f) * 2f - parX) * pk;
        parY += (((float) mouseY / Math.max(1, height) - 0.5f) * 2f - parY) * pk;
        float pox = -parX * width * 0.03f, poy = -parY * height * 0.03f;

        Theme th = Theme.current();
        int tint = tint();
        float k = height / 254f; // everything scales with the screen

        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // background: almost black, tinted with the theme
        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, true, pox, poy);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.11f));
        }

        GlStateManager.pushMatrix();
        GlStateManager.translate(pox * 0.5f, poy * 0.5f, 0f);
        Stripes.draw(width, height, t, e);
        GlStateManager.popMatrix();
        if (!th.glass) GlassFx.ambient(width, height, e, now, pox, poy);
        GlStateManager.pushMatrix();
        GlStateManager.translate(pox * 1.2f, poy * 1.2f, 0f);
        drawStars(dt, tint, e);
        GlStateManager.popMatrix();

        // ---- title: logo + name ----
        float logo = 0f;
        float tScale = 1.9f * k;
        String first = "\u00a7oLumen";
        String rest = " Client";
        float tw = LumenFont.width(first) * tScale + LumenFont.width(rest) * tScale;
        float gap = 0f;
        float tx = (width - (logo + gap + tw)) / 2f;
        float te = ease((t - 0.05f) / 0.6f);
        float ty = height * 0.307f - logo / 2f + (1f - te) * 10f * k;
        float textY = ty + (logo - LumenFont.EM * tScale) / 2f - 1f * k;
        if (th.glass) {
            // frosted plate behind the title only (the menu entries have no button backgrounds)
            GlassFx.pane(tx - 14f * k, textY - 7f * k, tx + tw + 14f * k, textY + LumenFont.EM * tScale + 5f * k, 9f * k, te, 0f);
        }
        text(first, tx + logo + gap, textY, tScale, Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f), te));
        text(rest, tx + logo + gap + LumenFont.width(first) * tScale, textY, tScale, Colors.mulAlpha(0xFFFFFFFF, te));

        // ---- menu entries (text only) ----
        float iScale = 1.05f * k;
        for (int i = 0; i < ITEMS.length; i++) {
            float w = LumenFont.width(ITEMS[i]) * iScale;
            float ie = ease((t - 0.2f - i * 0.08f) / 0.55f);
            float cy = height * ITEM_Y[i] + (1f - ie) * 12f * k;
            boolean hov = overItem(i, mouseX, mouseY);
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * Math.min(1f, dt * 14f);
            float h = hover[i];

            float base = ITEM_BRIGHT[i];
            int dim = Colors.lerp(0xFF000000, 0xFFFFFFFF, 0.55f + 0.45f * base);
            int col = Colors.lerp(dim, 0xFFFFFFFF, h);
            float sc = iScale * (1f + 0.05f * h);
            float sw = LumenFont.width(ITEMS[i]) * sc;
            text(ITEMS[i], (width - sw) / 2f, cy - LumenFont.EM * sc / 2f, sc, Colors.mulAlpha(col, ie));
            if (h > 0.02f && !th.glass) {
                float lw = sw * h;
                float ly = cy + LumenFont.EM * sc / 2f + 2f * k;
                RenderUtil.gradientH((width - lw) / 2f, ly, (width + lw) / 2f, ly + Math.max(1f, k * 0.9f),
                        Colors.mulAlpha(Colors.opaque(th.c1), ie), Colors.mulAlpha(Colors.opaque(th.c3), ie));
            }
        }

        drawShirtButton(mouseX, mouseY, e);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static final float SHIRT_BTN = 22f, SHIRT_MARGIN = 8f;

    private float shirtX() { return SHIRT_MARGIN; }

    private float shirtY() { return height - SHIRT_MARGIN - SHIRT_BTN; }

    private boolean overShirt(int mx, int my) {
        float x = shirtX(), y = shirtY();
        return mx >= x && mx <= x + SHIRT_BTN && my >= y && my <= y + SHIRT_BTN;
    }

    /** Shirt button in the bottom-left corner: opens the cosmetics screen. */
    private void drawShirtButton(int mouseX, int mouseY, float alpha) {
        Theme th = Theme.current();
        float x = shirtX(), y = shirtY();
        boolean hover = overShirt(mouseX, mouseY);
        if (th.glass) {
            GlassFx.pane(x, y, x + SHIRT_BTN, y + SHIRT_BTN, 6f, alpha, hover ? 0.45f : 0f);
        } else {
            int border = Colors.mulAlpha(Colors.opaque(hover ? th.c1 : Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), alpha);
            RenderUtil.roundedRect(x - 1f, y - 1f, x + SHIRT_BTN + 1f, y + SHIRT_BTN + 1f, 7f, border);
            int fill = Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), hover ? 0.18f : 0.07f);
            RenderUtil.roundedRect(x, y, x + SHIRT_BTN, y + SHIRT_BTN, 6f, Colors.mulAlpha(Colors.withAlpha(fill, 245), alpha));
        }
        Icons.shirt(x + SHIRT_BTN / 2f, y + SHIRT_BTN / 2f, 14f, th, alpha);
    }

    /** Small drifting five-pointed star outlines in the theme colours. */
    private void drawStars(float dt, int tint, float e) {
        Theme th = Theme.current();
        int[] cols = { Colors.opaque(th.c1), Colors.opaque(th.c2), Colors.opaque(th.c3) };
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glLineWidth(Math.max(1f, height / 254f * 0.9f));
        float k = height / 254f;
        for (int n = 0; n < stars.length; n++) {
            float[] s = stars[n];
            s[1] -= s[3] * dt;
            s[0] += (float) Math.sin(s[4] * 0.02f + s[1] * 6f) * 0.0004f;
            s[4] += s[5] * dt;
            if (s[1] < -0.05f) {
                s[1] = 1.05f;
            }
            float size = s[2] * k;
            int col = Colors.lerp(cols[n % 3], 0xFFFFFFFF, 0.35f);
            int a = (int) ((60 + 18 * (n % 5)) * e * Math.min(1f, s[2] / 8f + 0.3f));
            GlStateManager.color(Colors.channel(col, 16) / 255f, Colors.channel(col, 8) / 255f, Colors.channel(col, 0) / 255f, a / 255f);
            GL11.glBegin(GL11.GL_LINE_LOOP);
            for (int v = 0; v < 10; v++) {
                double ang = Math.toRadians(s[4]) - Math.PI / 2 + v * Math.PI / 5;
                double rad = (v % 2 == 0) ? size : size * 0.45;
                GL11.glVertex2d(s[0] * width + Math.cos(ang) * rad, s[1] * height + Math.sin(ang) * rad);
            }
            GL11.glEnd();
        }
        GL11.glLineWidth(1f);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    private boolean overItem(int i, int mx, int my) {
        float k = height / 254f;
        float w = LumenFont.width(ITEMS[i]) * 1.05f * k;
        float cy = height * ITEM_Y[i];
        float pad = 12f * k;
        return mx >= (width - w) / 2f - pad && mx <= (width + w) / 2f + pad
                && my >= cy - 9f * k && my <= cy + 9f * k;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        if (overShirt(mouseX, mouseY)) {
            Sounds.click();
            mc.displayGuiScreen(new CosmeticsScreen(this));
            return;
        }
        for (int i = 0; i < ITEMS.length; i++) {
            if (!overItem(i, mouseX, mouseY)) continue;
            Sounds.click();
            switch (i) {
                case 0:
                    mc.displayGuiScreen(new LumenWorldSelect(this));
                    break;
                case 1:
                    mc.displayGuiScreen(new LumenServerSelect(this));
                    break;
                case 2:
                    mc.displayGuiScreen(new LumenOptions(this, mc.gameSettings));
                    break;
                case 3:
                    mc.displayGuiScreen(GuiScreens.clickGui());
                    break;
                default:
                    mc.shutdown();
                    break;
            }
            return;
        }
    }
}
