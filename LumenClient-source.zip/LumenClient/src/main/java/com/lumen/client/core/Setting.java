package com.lumen.client.core;

import com.google.gson.JsonElement;

public abstract class Setting {
    public final String name;
    /** 0..1 value the ClickGUI uses for smooth animations. */
    public float anim;

    protected Setting(String name) {
        this.name = name;
    }

    /** Height of this setting's row in the ClickGUI. */
    public abstract int height();

    public abstract JsonElement save();

    public abstract void load(JsonElement element);
}
