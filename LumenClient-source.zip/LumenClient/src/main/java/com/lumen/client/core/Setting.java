package com.lumen.client.core;

import com.google.gson.JsonElement;

public abstract class Setting {
    public final String name;
    /** 0..1 value the ClickGUI uses for smooth animations. */
    public float anim;

    /** If set, this setting is only shown in the ClickGUI while that switch is on. */
    public BooleanSetting showWhen;
    /** 0..1: how far the row is revealed (animated by the ClickGUI). */
    public float visAnim = 1f;

    /** Makes this setting appear only while {@code dep} is enabled. */
    public void showWhen(BooleanSetting dep) {
        this.showWhen = dep;
        this.visAnim = dep.value ? 1f : 0f;
    }

    public boolean visible() {
        return showWhen == null || showWhen.value;
    }

    /** Row height in the ClickGUI including the reveal animation. */
    public final float shownHeight() {
        return height() * visAnim;
    }

    protected Setting(String name) {
        this.name = name;
    }

    /** Height of this setting's row in the ClickGUI. */
    public abstract int height();

    public abstract JsonElement save();

    public abstract void load(JsonElement element);
}
