package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

/**
 * Options screen opened by the gear button in the top-right corner of the ClickGUI: a list of checkboxes
 * ({@link ClientSettings#OPTIONS}). The gear or Esc goes back to the ClickGUI.
 */
public class OptionsScreen extends GuiScreen {
    static final float BTN = 22f, BTN_MARGIN = 8f;
    private static final float PANEL_W = 220f, ROW_H = 18f, PAD = 10f, TITLE_H = 22f, BOX = 10f;

    private float fade;
    private long lastFrame = System.currentTimeMillis();

    static float btnX(int screenWidth) { return screenWidth - BTN_MARGIN - BTN; }

    static float btnY() { return BTN_MARGIN; }

    /** Draws the gear button; active = the Options screen is open (button stays lit). */
    static void drawButton(int sw, int mouseX, int mouseY, float alpha, boolean active) {
        Theme th = Theme.current();
        float x = btnX(sw), y = btnY();
        boolean hover = overButton(sw, mouseX, mouseY);
        int border = Colors.mulAlpha(Colors.opaque(active || hover ? th.c1 : Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), alpha);
        if (th.glass) {
            GlassFx.pane(x, y, x + BTN, y + BTN, 6f, alpha, active ? 1f : (hover ? 0.45f : 0f));
        } else {
            int fill = Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), active ? 0.30f : (hover ? 0.18f : 0.07f));
            GlassFx.classicPane(x, y, x + BTN, y + BTN, 6f, Colors.withAlpha(fill, 245), th.c1, th.c2,
                    active ? 1f : (hover ? 0.45f : 0f), alpha);
        }
        Icons.gear(x + BTN / 2f, y + BTN / 2f, 13f, th, alpha);
    }

    static boolean overButton(int sw, int mx, int my) {
        float x = btnX(sw), y = btnY();
        return mx >= x && mx <= x + BTN && my >= y && my <= y + BTN;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
    }

    @Override
    public void onGuiClosed() {
        ConfigManager.save();
    }

    private float panelH() {
        int n = Math.max(1, ClientSettings.OPTIONS.size());
        return TITLE_H + PAD + n * ROW_H + PAD;
    }

    private float panelX() { return (width - PANEL_W) / 2f; }

    private float panelY() { return (height - panelH()) / 2f; }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        Theme th = Theme.current();
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (th.glass) {
            GlassFx.backdrop(width, height, e * 0.55f, now, false);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.bg), 110), e),
                    Colors.mulAlpha(Colors.withAlpha(Colors.lerp(Colors.opaque(th.bg), Colors.opaque(th.c3), 0.18f), 140), e));
        }

        float px = panelX(), py = panelY(), pw = PANEL_W, ph = panelH();
        if (th.glass) {
            GlassFx.pane(px, py, px + pw, py + ph, 8f, e, 0f);
        } else {
            RenderUtil.roundedRect(px - 1f, py - 1f, px + pw + 1f, py + ph + 1f, 9f,
                    Colors.mulAlpha(Colors.opaque(Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), e));
            RenderUtil.roundedRect(px, py, px + pw, py + ph, 8f, Colors.mulAlpha(Colors.withAlpha(0xFF0C0E24, 245), e));
        }
        LumenFont.draw("Options", px + PAD, py + 6f, Colors.mulAlpha(0xFFFFFFFF, e), true);

        float ry = py + TITLE_H + PAD;
        if (ClientSettings.OPTIONS.isEmpty()) {
            LumenFont.draw("No options yet", px + PAD, ry + 4f, Colors.mulAlpha(0xFFA2AAC9, e), true);
        }
        for (BooleanSetting o : ClientSettings.OPTIONS) {
            boolean hover = mouseX >= px + 4f && mouseX <= px + pw - 4f && mouseY >= ry && mouseY < ry + ROW_H;
            o.anim += ((o.value ? 1f : 0f) - o.anim) * Math.min(1f, dt * 14f);
            if (hover) RenderUtil.roundedRect(px + 4f, ry, px + pw - 4f, ry + ROW_H, 5f,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.c1), 34), e));
            LumenFont.draw(o.name, px + PAD, ry + 4f, Colors.mulAlpha(Colors.lerp(0xFFD5D9E8, 0xFFFFFFFF, o.anim), e), true);
            drawBox(px + pw - PAD - BOX, ry + (ROW_H - BOX) / 2f, o.anim, th, e);
            ry += ROW_H;
        }

        drawButton(width, mouseX, mouseY, e, true);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Checkbox: outlined square that fills with the theme colour and shows a tick when on (on = 0..1). */
    private void drawBox(float x, float y, float on, Theme th, float alpha) {
        int c = Colors.opaque(th.c1);
        RenderUtil.roundedRect(x - 1f, y - 1f, x + BOX + 1f, y + BOX + 1f, 3.5f,
                Colors.mulAlpha(Colors.lerp(Colors.lerp(c, 0xFF1E2247, 0.55f), c, on), alpha));
        RenderUtil.roundedRect(x, y, x + BOX, y + BOX, 3f,
                Colors.mulAlpha(Colors.lerp(0xFF0C0E24, c, on), alpha));
        if (on > 0.02f) {
            int white = Colors.mulAlpha(0xFFFFFFFF, alpha * on);
            float cx = x + BOX / 2f, cy = y + BOX / 2f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(cx, cy, 0f);
            GlStateManager.rotate(45f, 0f, 0f, 1f);
            RenderUtil.rect(-2.6f, 0.2f, -1.4f, 3.2f, white);   // short stroke
            RenderUtil.rect(-2.6f, 2.0f, 3.4f, 3.2f, white);    // long stroke
            GlStateManager.popMatrix();
            GlStateManager.color(1f, 1f, 1f, 1f);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        if (overButton(width, mouseX, mouseY)) {
            back();
            return;
        }
        float px = panelX(), ry = panelY() + TITLE_H + PAD;
        for (BooleanSetting o : ClientSettings.OPTIONS) {
            if (mouseX >= px + 4f && mouseX <= px + PANEL_W - 4f && mouseY >= ry && mouseY < ry + ROW_H) {
                o.toggle();
                Sounds.toggle(o.value);
                if (o == ClientSettings.renderFoliage) com.lumen.client.util.FoliageFilter.refresh();
                return;
            }
            ry += ROW_H;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) back();
    }

    private void back() {
        Sounds.click();
        mc.displayGuiScreen(ColumnGui.create());
    }
}
