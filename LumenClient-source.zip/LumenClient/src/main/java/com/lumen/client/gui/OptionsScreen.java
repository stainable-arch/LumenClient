package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.core.Setting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.List;

import java.io.IOException;

/**
 * Options screen opened by the gear button in the top-right corner of the ClickGUI: a list of checkboxes
 * ({@link ClientSettings#OPTIONS}). The gear or Esc goes back to the ClickGUI.
 */
public class OptionsScreen extends GuiScreen {
    static final float BTN = 22f, BTN_MARGIN = 8f;
    private static final float PANEL_W = 220f, ROW_H = 18f, PAD = 10f, TITLE_H = 22f, BOX = 10f;

    private static final float NUM_H = 26f, HEAD_H = 16f;
    private float fade, scroll;
    private NumberSetting dragging;
    /** Rows of the list: BooleanSetting / NumberSetting, or null = the "Performance" heading. */
    private final List<Setting> rows = new ArrayList<Setting>();

    private long lastFrame = System.currentTimeMillis();

    static float btnX(int screenWidth) { return screenWidth - BTN_MARGIN - BTN; }

    static float btnY() { return BTN_MARGIN; }

    /** Draws the gear button; active = the Options screen is open (button stays lit). */
    static void drawButton(int sw, int mouseX, int mouseY, float alpha, boolean active) {
        Theme th = Theme.current();
        float x = btnX(sw), y = btnY();
        boolean hover = overButton(sw, mouseX, mouseY);
        int border = Colors.mulAlpha(Colors.opaque(active || hover ? th.c1 : Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), alpha);
        if (th.glass) {
            GlassFx.pane(x, y, x + BTN, y + BTN, 6f, alpha, active ? 1f : (hover ? 0.45f : 0f));
        } else {
            RenderUtil.roundedRect(x - 1f, y - 1f, x + BTN + 1f, y + BTN + 1f, 7f, border);
            int fill = Colors.lerp(0xFF0C0E24, Colors.opaque(th.c3), active ? 0.30f : (hover ? 0.18f : 0.07f));
            RenderUtil.roundedRect(x, y, x + BTN, y + BTN, 6f, Colors.mulAlpha(Colors.withAlpha(fill, 245), alpha));
        }
        Icons.gear(x + BTN / 2f, y + BTN / 2f, 13f, th, alpha);
    }

    static boolean overButton(int sw, int mx, int my) {
        float x = btnX(sw), y = btnY();
        return mx >= x && mx <= x + BTN && my >= y && my <= y + BTN;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
    }

    @Override
    public void onGuiClosed() {
        ConfigManager.save();
    }

    private void buildRows() {
        rows.clear();
        rows.addAll(ClientSettings.OPTIONS);
        rows.add(null);
        for (Setting p : ClientSettings.PERF) if (p.visible()) rows.add(p);
    }

    private static float rowH(Setting s) {
        return s == null ? HEAD_H : s instanceof NumberSetting ? NUM_H : ROW_H;
    }

    private float contentH() {
        float h = 0f;
        for (Setting s : rows) h += rowH(s);
        return h;
    }

    private float panelH() {
        return Math.min(TITLE_H + PAD + contentH() + PAD, height - 24f);
    }

    private float viewH() { return panelH() - TITLE_H - PAD * 2f; }

    private float maxScroll() { return Math.max(0f, contentH() - viewH()); }

    private float panelX() { return (width - PANEL_W) / 2f; }

    private float panelY() { return (height - panelH()) / 2f; }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = Math.min(1f, fade + dt * 5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        Theme th = Theme.current();
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (th.glass) {
            GlassFx.backdrop(width, height, e * 0.55f, now, false);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.bg), 110), e),
                    Colors.mulAlpha(Colors.withAlpha(Colors.lerp(Colors.opaque(th.bg), Colors.opaque(th.c3), 0.18f), 140), e));
        }

        buildRows();
        float px = panelX(), py = panelY(), pw = PANEL_W, ph = panelH();
        if (th.glass) {
            GlassFx.pane(px, py, px + pw, py + ph, 8f, e, 0f);
        } else {
            RenderUtil.roundedRect(px - 1f, py - 1f, px + pw + 1f, py + ph + 1f, 9f,
                    Colors.mulAlpha(Colors.opaque(Colors.lerp(Colors.opaque(th.c1), 0xFF1E2247, 0.55f)), e));
            RenderUtil.roundedRect(px, py, px + pw, py + ph, 8f, Colors.mulAlpha(Colors.withAlpha(0xFF0C0E24, 245), e));
        }
        LumenFont.draw("Options", px + PAD, py + 6f, Colors.mulAlpha(0xFFFFFFFF, e), true);

        float step = Math.min(1f, dt * 14f);
        scroll = Math.max(0f, Math.min(maxScroll(), scroll));
        float top = py + TITLE_H + PAD;
        RenderUtil.scissor(px, top, pw, viewH());
        float ry = top - scroll;
        for (Setting s : rows) {
            float h = rowH(s);
            if (ry + h >= top && ry <= top + viewH()) drawRow(s, px, ry, pw, mouseX, mouseY, step, th, e);
            ry += h;
        }
        RenderUtil.endScissor();
        if (maxScroll() > 0.5f) {
            float th2 = viewH(), bar = Math.max(12f, th2 * th2 / contentH());
            float by = top + (th2 - bar) * (scroll / maxScroll());
            RenderUtil.roundedRect(px + pw - 4f, by, px + pw - 2f, by + bar, 1f, Colors.mulAlpha(0x88FFFFFF, e));
        }

        drawButton(width, mouseX, mouseY, e, true);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawRow(Setting s, float px, float ry, float pw, int mouseX, int mouseY, float step, Theme th, float e) {
        if (s == null) {
            LumenFont.draw("Performance", px + PAD, ry + 4f, Colors.mulAlpha(Colors.opaque(th.c1), e), true);
            RenderUtil.rect(px + PAD, ry + HEAD_H - 2f, px + pw - PAD, ry + HEAD_H - 1f, Colors.mulAlpha(0x22FFFFFF, e));
            return;
        }
        boolean sub = s.showWhen != null;
        float ix = px + PAD + (sub ? 8f : 0f);
        if (s instanceof BooleanSetting) {
            BooleanSetting o = (BooleanSetting) s;
            boolean hover = mouseX >= px + 4f && mouseX <= px + pw - 4f && mouseY >= ry && mouseY < ry + ROW_H
                    && mouseY >= panelY() + TITLE_H + PAD && mouseY <= panelY() + TITLE_H + PAD + viewH();
            o.anim += ((o.value ? 1f : 0f) - o.anim) * step;
            if (hover) RenderUtil.roundedRect(px + 4f, ry, px + pw - 4f, ry + ROW_H, 5f,
                    Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.c1), 34), e));
            LumenFont.draw(o.name, ix, ry + 4f, Colors.mulAlpha(Colors.lerp(0xFFD5D9E8, 0xFFFFFFFF, o.anim), e), true);
            drawBox(px + pw - PAD - BOX - 4f, ry + (ROW_H - BOX) / 2f, o.anim, th, e);
        } else if (s instanceof NumberSetting) {
            NumberSetting n = (NumberSetting) s;
            LumenFont.draw(n.name, ix, ry + 2f, Colors.mulAlpha(0xFFD5D9E8, e), true);
            String v = n.display();
            LumenFont.draw(v, px + pw - PAD - 4f - LumenFont.width(v), ry + 2f, Colors.mulAlpha(Colors.opaque(th.c1), e), true);
            float tx = ix, tw = px + pw - PAD - 4f - ix, ty = ry + 16f;
            float fw = Math.max(3f, tw * (float) n.fraction());
            RenderUtil.roundedRect(tx, ty, tx + tw, ty + 3f, 1.5f, Colors.mulAlpha(0x55FFFFFF, e));
            RenderUtil.roundedRect(tx, ty, tx + fw, ty + 3f, 1.5f, Colors.mulAlpha(Colors.opaque(th.c1), e));
            RenderUtil.circle(tx + fw, ty + 1.5f, 3.2f, Colors.mulAlpha(0xFFFFFFFF, e));
        }
    }

    private void setNumberFromMouse(NumberSetting n, int mouseX) {
        float ix = panelX() + PAD + 8f, tw = panelX() + PANEL_W - PAD - 4f - ix;
        n.set(n.min + (n.max - n.min) * Math.max(0f, Math.min(1f, (mouseX - ix) / tw)));
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scroll = Math.max(0f, Math.min(maxScroll(), scroll - Integer.signum(d) * 24f));
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long time) {
        if (dragging != null) setNumberFromMouse(dragging, mouseX);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = null;
    }

    /** Checkbox: outlined square that fills with the theme colour and shows a tick when on (on = 0..1). */
    private void drawBox(float x, float y, float on, Theme th, float alpha) {
        int c = Colors.opaque(th.c1);
        RenderUtil.roundedRect(x - 1f, y - 1f, x + BOX + 1f, y + BOX + 1f, 3.5f,
                Colors.mulAlpha(Colors.lerp(Colors.lerp(c, 0xFF1E2247, 0.55f), c, on), alpha));
        RenderUtil.roundedRect(x, y, x + BOX, y + BOX, 3f,
                Colors.mulAlpha(Colors.lerp(0xFF0C0E24, c, on), alpha));
        if (on > 0.02f) {
            int white = Colors.mulAlpha(0xFFFFFFFF, alpha * on);
            float cx = x + BOX / 2f, cy = y + BOX / 2f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(cx, cy, 0f);
            GlStateManager.rotate(45f, 0f, 0f, 1f);
            RenderUtil.rect(-2.6f, 0.2f, -1.4f, 3.2f, white);   // short stroke
            RenderUtil.rect(-2.6f, 2.0f, 3.4f, 3.2f, white);    // long stroke
            GlStateManager.popMatrix();
            GlStateManager.color(1f, 1f, 1f, 1f);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        buildRows();
        if (overButton(width, mouseX, mouseY)) {
            back();
            return;
        }
        float px = panelX(), top = panelY() + TITLE_H + PAD;
        if (mouseY < top || mouseY > top + viewH()) return;
        float ry = top - scroll;
        for (Setting s : rows) {
            float h = rowH(s);
            if (s != null && mouseY >= ry && mouseY < ry + h && mouseX >= px + 4f && mouseX <= px + PANEL_W - 4f) {
                if (s instanceof BooleanSetting) {
                    BooleanSetting o = (BooleanSetting) s;
                    o.toggle();
                    Sounds.toggle(o.value);
                    if (o == ClientSettings.renderFoliage) com.lumen.client.util.FoliageFilter.refresh();
                } else if (s instanceof NumberSetting && mouseY >= ry + 10f) {
                    dragging = (NumberSetting) s;
                    setNumberFromMouse(dragging, mouseX);
                }
                return;
            }
            ry += h;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) back();
    }

    private void back() {
        Sounds.click();
        mc.displayGuiScreen(new ClickGui());
    }
}
