package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.util.Colors;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Shows critical-hit and/or sharpness particles on every hit you land, with an adjustable amount.
 * Purely visual and client side. The multiplier is the number of particle bursts per hit (a vanilla
 * crit is one burst); fractions work as a chance, so 2.5x is two bursts plus a 50% chance of a third.
 *
 * "Shiny Particles" keeps the vanilla particles exactly as they are and adds a soft additive glow
 * behind each one. To know where the particles are, the burst is spawned the same way vanilla does it
 * (16 tries per tick for 3 ticks, same spread and speed) but through the particle manager directly.
 */
public class Particles extends Module {
    private final BooleanSetting crit = add(new BooleanSetting("Always Crit Particles", true));
    private final BooleanSetting sharp = add(new BooleanSetting("Always Sharp Particles", false));
    private final NumberSetting amount = add(new NumberSetting("Multiplier", 1.0, 1.0, 10.0, 0.5));
    private final BooleanSetting shiny = add(new BooleanSetting("Shiny Particles", false));
    private final NumberSetting glow = add(new NumberSetting("Glow", 4, 0, 10, 1));

    private final Random random = new Random();

    /** A burst that still has ticks left to emit (vanilla's emitter lives 3 ticks). */
    private static final class Burst {
        final Entity target;
        final EnumParticleTypes type;
        int ticksLeft = 3;

        Burst(Entity target, EnumParticleTypes type) {
            this.target = target;
            this.type = type;
        }
    }

    /** A spawned vanilla particle that gets a glow halo. */
    private static final class Glowing {
        final EntityFX fx;
        final int color;
        final long born = System.currentTimeMillis();

        Glowing(EntityFX fx, int color) {
            this.fx = fx;
            this.color = color;
        }
    }

    private final List<Burst> bursts = new ArrayList<Burst>();
    private final List<Glowing> glowing = new ArrayList<Glowing>();

    public Particles() {
        super("Particles", "Always show crit / sharpness particles when you hit, from 1x to 10x.", Category.VISUALS);
        glow.showWhen(shiny);
    }

    @Override
    protected void onDisable() {
        bursts.clear();
        glowing.clear();
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (e.entityPlayer != mc.thePlayer) return;
        Entity target = e.target;
        if (!(target instanceof EntityLivingBase) || target.isDead) return;

        double a = amount.value;
        int count = (int) Math.floor(a);
        if (random.nextDouble() < a - count) count++;
        for (int i = 0; i < count; i++) {
            if (shiny.value) {
                if (crit.value) bursts.add(new Burst(target, EnumParticleTypes.CRIT));
                if (sharp.value) bursts.add(new Burst(target, EnumParticleTypes.CRIT_MAGIC));
            } else {
                if (crit.value) mc.effectRenderer.emitParticleAtEntity(target, EnumParticleTypes.CRIT);
                if (sharp.value) mc.effectRenderer.emitParticleAtEntity(target, EnumParticleTypes.CRIT_MAGIC);
            }
        }
    }

    /** Same emission as vanilla's particle emitter, but we keep the particle objects. */
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.theWorld == null) return;
        Iterator<Burst> it = bursts.iterator();
        while (it.hasNext()) {
            Burst b = it.next();
            if (b.target.isDead || b.ticksLeft <= 0) {
                it.remove();
                continue;
            }
            for (int i = 0; i < 16; i++) {
                double dx = random.nextFloat() * 2f - 1f;
                double dy = random.nextFloat() * 2f - 1f;
                double dz = random.nextFloat() * 2f - 1f;
                if (dx * dx + dy * dy + dz * dz > 1.0) continue;
                double x = b.target.posX + dx * b.target.width / 4.0;
                double y = b.target.getEntityBoundingBox().minY + b.target.height / 2.0f + dy * b.target.height / 4.0;
                double z = b.target.posZ + dz * b.target.width / 4.0;
                EntityFX fx = mc.effectRenderer.spawnEffectParticle(b.type.getParticleID(), x, y, z, dx, dy + 0.2, dz);
                if (fx != null && glow.value > 0) {
                    glowing.add(new Glowing(fx, b.type == EnumParticleTypes.CRIT ? 0xFFB347 : 0x6FEFE0));
                }
            }
            if (--b.ticksLeft <= 0) it.remove();
        }
        // never let the list grow without bound
        while (glowing.size() > 400) glowing.remove(0);
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent e) {
        if (glowing.isEmpty() || mc.getRenderViewEntity() == null) return;
        Entity view = mc.getRenderViewEntity();
        RenderManager rm = mc.getRenderManager();
        double cx = view.lastTickPosX + (view.posX - view.lastTickPosX) * e.partialTicks;
        double cy = view.lastTickPosY + (view.posY - view.lastTickPosY) * e.partialTicks;
        double cz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * e.partialTicks;
        float g = glow.getFloat() / 10f;
        long now = System.currentTimeMillis();

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1); // additive
        GlStateManager.shadeModel(7425);

        Iterator<Glowing> it = glowing.iterator();
        while (it.hasNext()) {
            Glowing p = it.next();
            if (p.fx.isDead) {
                it.remove();
                continue;
            }
            float life = 1f - Math.min(1f, (now - p.born) / 650f);
            if (life <= 0f) {
                it.remove();
                continue;
            }
            double x = p.fx.prevPosX + (p.fx.posX - p.fx.prevPosX) * e.partialTicks - cx;
            double y = p.fx.prevPosY + (p.fx.posY - p.fx.prevPosY) * e.partialTicks - cy;
            double z = p.fx.prevPosZ + (p.fx.posZ - p.fx.prevPosZ) * e.partialTicks - cz;
            GlStateManager.pushMatrix();
            GlStateManager.translate((float) x, (float) y, (float) z);
            GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
            GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
            // tight halo + wide halo, brighter and bigger with a higher setting (kept gentle on purpose)
            halo(0.07f + 0.08f * g, p.color, (0.10f + 0.50f * g) * life);
            halo(0.14f + 0.16f * g, p.color, (0.05f + 0.28f * g) * life);
            GlStateManager.popMatrix();
        }

        GlStateManager.shadeModel(7424);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    /** Camera-facing radial glow of the given radius (world units); centre colour fades to nothing at the rim. */
    private static void halo(float radius, int rgb, float strength) {
        float r = Colors.channel(rgb, 16) / 255f, gr = Colors.channel(rgb, 8) / 255f, b = Colors.channel(rgb, 0) / 255f;
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glColor4f(r, gr, b, Math.min(1f, strength));
        GL11.glVertex3f(0f, 0f, 0f);
        GL11.glColor4f(r, gr, b, 0f);
        for (int i = 0; i <= 12; i++) {
            double a = i * Math.PI * 2 / 12;
            GL11.glVertex3f((float) Math.cos(a) * radius, (float) Math.sin(a) * radius, 0f);
        }
        GL11.glEnd();
    }
}
