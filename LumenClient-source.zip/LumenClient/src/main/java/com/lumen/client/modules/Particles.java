package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.util.Colors;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Shows critical-hit and/or sharpness particles on every hit you land, with an adjustable amount.
 * Purely visual and client side. The multiplier is the number of particle bursts per hit (a vanilla
 * crit is one burst); fractions work as a chance, so 2.5x is two bursts plus a 50% chance of a third.
 *
 * "Shiny Particles" keeps the vanilla particles exactly as they are and adds a soft additive glow
 * around the shape of each one (drawn from the active texture pack's own particle sprite). To know where the particles are, the burst is spawned the same way vanilla does it
 * (16 tries per tick for 3 ticks, same spread and speed) but through the particle manager directly.
 */
public class Particles extends Module {
    private final BooleanSetting crit = add(new BooleanSetting("Always Crit Particles", true));
    private final BooleanSetting sharp = add(new BooleanSetting("Always Sharp Particles", false));
    private final NumberSetting amount = add(new NumberSetting("Multiplier", 1.0, 1.0, 10.0, 0.5));
    private final BooleanSetting shiny = add(new BooleanSetting("Shiny Particles", false));
    private final NumberSetting glow = add(new NumberSetting("Glow", 4, 0, 10, 1));

    private final Random random = new Random();

    /** A burst that still has ticks left to emit (vanilla's emitter lives 3 ticks). */
    private static final class Burst {
        final Entity target;
        final EnumParticleTypes type;
        int ticksLeft = 3;

        Burst(Entity target, EnumParticleTypes type) {
            this.target = target;
            this.type = type;
        }
    }

    /** A spawned vanilla particle that gets a glow halo. */
    private static final class Glowing {
        final EntityFX fx;
        final int color;
        final boolean magic;
        final long born = System.currentTimeMillis();

        Glowing(EntityFX fx, int color, boolean magic) {
            this.fx = fx;
            this.color = color;
            this.magic = magic;
        }
    }

    private final List<Burst> bursts = new ArrayList<Burst>();
    private final List<Glowing> glowing = new ArrayList<Glowing>();

    public Particles() {
        super("Particles", "Always show crit / sharpness particles when you hit, from 1x to 10x.", Category.VISUALS);
        glow.showWhen(shiny);
    }

    @Override
    protected void onDisable() {
        bursts.clear();
        glowing.clear();
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (e.entityPlayer != mc.thePlayer) return;
        Entity target = e.target;
        if (!(target instanceof EntityLivingBase) || target.isDead) return;

        double a = amount.value;
        int count = (int) Math.floor(a);
        if (random.nextDouble() < a - count) count++;
        for (int i = 0; i < count; i++) {
            if (shiny.value) {
                if (crit.value) bursts.add(new Burst(target, EnumParticleTypes.CRIT));
                if (sharp.value) bursts.add(new Burst(target, EnumParticleTypes.CRIT_MAGIC));
            } else {
                if (crit.value) mc.effectRenderer.emitParticleAtEntity(target, EnumParticleTypes.CRIT);
                if (sharp.value) mc.effectRenderer.emitParticleAtEntity(target, EnumParticleTypes.CRIT_MAGIC);
            }
        }
    }

    /** Same emission as vanilla's particle emitter, but we keep the particle objects. */
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.theWorld == null) return;
        Iterator<Burst> it = bursts.iterator();
        while (it.hasNext()) {
            Burst b = it.next();
            if (b.target.isDead || b.ticksLeft <= 0) {
                it.remove();
                continue;
            }
            for (int i = 0; i < 16; i++) {
                double dx = random.nextFloat() * 2f - 1f;
                double dy = random.nextFloat() * 2f - 1f;
                double dz = random.nextFloat() * 2f - 1f;
                if (dx * dx + dy * dy + dz * dz > 1.0) continue;
                double x = b.target.posX + dx * b.target.width / 4.0;
                double y = b.target.getEntityBoundingBox().minY + b.target.height / 2.0f + dy * b.target.height / 4.0;
                double z = b.target.posZ + dz * b.target.width / 4.0;
                EntityFX fx = mc.effectRenderer.spawnEffectParticle(b.type.getParticleID(), x, y, z, dx, dy + 0.2, dz);
                if (fx != null && glow.value > 0) {
                    glowing.add(new Glowing(fx, b.type == EnumParticleTypes.CRIT ? 0xFFB347 : 0x6FEFE0, b.type != EnumParticleTypes.CRIT));
                }
            }
            if (--b.ticksLeft <= 0) it.remove();
        }
        // never let the list grow without bound
        while (glowing.size() > 400) glowing.remove(0);
    }

    /** Vanilla's particle sheet (so the glow follows whatever texture pack the player uses). */
    private static final ResourceLocation PARTICLE_SHEET = new ResourceLocation("textures/particle/particles.png");
    /** Cells of the 16x16 sheet: crit is 65, sharpness (crit magic) is the next one over. */
    private static final int CELL_CRIT = 65, CELL_MAGIC = 66;

    private static java.lang.reflect.Field scaleField;
    private static boolean scaleFieldTried;

    /** The particle's current size multiplier (1.0 if it can't be read). */
    private static float scaleOf(EntityFX fx) {
        if (!scaleFieldTried) {
            scaleFieldTried = true;
            for (String name : new String[] { "particleScale", "field_70544_f" }) {
                try {
                    java.lang.reflect.Field f = EntityFX.class.getDeclaredField(name);
                    f.setAccessible(true);
                    scaleField = f;
                    break;
                } catch (Throwable ignored) {
                    // try the next name
                }
            }
        }
        if (scaleField != null) {
            try {
                return scaleField.getFloat(fx);
            } catch (Throwable ignored) {
                // fall through
            }
        }
        return 1f;
    }

    /**
     * The glow is drawn from the particle's own sprite in the active resource pack: copies of the
     * sprite are pushed outwards in a ring (two rings, a tight and a wide one) with additive blending,
     * so the glow hugs the shape of the texture instead of being a blob in the middle.
     */
    @SubscribeEvent
    public void onRender(RenderWorldLastEvent e) {
        if (glowing.isEmpty() || mc.getRenderViewEntity() == null) return;
        Entity view = mc.getRenderViewEntity();
        RenderManager rm = mc.getRenderManager();
        double cx = view.lastTickPosX + (view.posX - view.lastTickPosX) * e.partialTicks;
        double cy = view.lastTickPosY + (view.posY - view.lastTickPosY) * e.partialTicks;
        double cz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * e.partialTicks;
        float g = glow.getFloat() / 10f;
        long now = System.currentTimeMillis();

        GlStateManager.pushMatrix();
        GlStateManager.enableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.003921569F);
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1); // additive
        mc.getTextureManager().bindTexture(PARTICLE_SHEET);

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();

        Iterator<Glowing> it = glowing.iterator();
        while (it.hasNext()) {
            Glowing p = it.next();
            if (p.fx.isDead) {
                it.remove();
                continue;
            }
            float life = 1f - Math.min(1f, (now - p.born) / 650f);
            if (life <= 0f) {
                it.remove();
                continue;
            }
            double x = p.fx.prevPosX + (p.fx.posX - p.fx.prevPosX) * e.partialTicks - cx;
            double y = p.fx.prevPosY + (p.fx.posY - p.fx.prevPosY) * e.partialTicks - cy;
            double z = p.fx.prevPosZ + (p.fx.posZ - p.fx.prevPosZ) * e.partialTicks - cz;

            // half-size of vanilla's particle quad
            float h = 0.1f * scaleOf(p.fx);
            if (h <= 0.001f) continue;

            int cell = p.magic ? CELL_MAGIC : CELL_CRIT;
            float u0 = (cell % 16) / 16f + 0.0015f, u1 = (cell % 16 + 1) / 16f - 0.0015f;
            float v0 = (cell / 16) / 16f + 0.0015f, v1 = (cell / 16 + 1) / 16f - 0.0015f;
            float r = Colors.channel(p.color, 16) / 255f, gr = Colors.channel(p.color, 8) / 255f, b = Colors.channel(p.color, 0) / 255f;

            GlStateManager.pushMatrix();
            GlStateManager.translate((float) x, (float) y, (float) z);
            GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
            GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);

            wr.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            // tight ring, then a wider and fainter one; stronger and further out with a higher setting
            ring(wr, h, h * (0.16f + 0.20f * g), 0.20f * g * life, u0, u1, v0, v1, r, gr, b);
            ring(wr, h, h * (0.40f + 0.45f * g), 0.09f * g * life, u0, u1, v0, v1, r, gr, b);
            tess.draw();
            GlStateManager.popMatrix();
        }

        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.alphaFunc(516, 0.1F);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    /** Eight copies of the particle sprite pushed outwards by `dist` in a circle. */
    private static void ring(WorldRenderer wr, float h, float dist, float alpha,
                             float u0, float u1, float v0, float v1, float r, float g, float b) {
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            float ox = (float) Math.cos(a) * dist, oy = (float) Math.sin(a) * dist;
            // local +x points to the screen's left, so u is mirrored (same as vanilla's billboards)
            wr.pos(ox + h, oy + h, 0).tex(u0, v0).color(r, g, b, alpha).endVertex();
            wr.pos(ox - h, oy + h, 0).tex(u1, v0).color(r, g, b, alpha).endVertex();
            wr.pos(ox - h, oy - h, 0).tex(u1, v1).color(r, g, b, alpha).endVertex();
            wr.pos(ox + h, oy - h, 0).tex(u0, v1).color(r, g, b, alpha).endVertex();
        }
    }
}
