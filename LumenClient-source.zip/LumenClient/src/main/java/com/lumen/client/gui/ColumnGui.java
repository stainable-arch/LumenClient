package com.lumen.client.gui;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ColorSetting;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.core.Setting;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Column-style ClickGUI (Figma "Minecraft Hack GUI #6"): one floating column per category,
 * a header pill on top, a glass panel of module rows below, and a search pill at the bottom.
 *
 * Stage 1: layout, header pills, module rows with toggle switches, search.
 * Left click a row = toggle. Right click = expand (settings are drawn in stage 2).
 */
public class ColumnGui extends GuiScreen {
    private static final float COL_W = 118f;
    private static final float COL_GAP = 8f;
    private static final float HEADER_H = 18f;
    private static final float HEADER_GAP = 6f;
    private static final float ROW_H = 17f;
    private static final float ROW_GAP = 2f;
    private static final float PAD = 4f;
    private static final float RADIUS = 5f;
    private static final float SEARCH_W = 130f;
    private static final float SEARCH_H = 16f;
    private static final float BIND_H = 13f;

    private static final int COL_PANEL = 0xB0101114;
    private static final int COL_HEADER = 0xC0181A1F;
    private static final int COL_ROW = 0x40FFFFFF;
    private static final int COL_ROW_ON = 0x70FFFFFF;
    private static final int COL_STROKE = 0x30FFFFFF;
    private static final int COL_TEXT = 0xFFE1E1E1;
    private static final int COL_TEXT_DIM = 0xFF7C7F86;

    private final Category[] cats = Category.values();
    private String query = "";
    private boolean searchFocused;
    private float openAnim;

    private static final int H_ROW = 0, H_BOOL = 1, H_MODE = 2, H_NUM = 3, H_COLOR = 4, H_BIND = 5, H_CLASSIC = 6, H_SAT = 7, H_VAL = 8;
    private static final class Hit {
        final int type; final float x, y, w, h; final Module m; final Setting st;
        Hit(int type, float x, float y, float w, float h, Module m, Setting st) {
            this.type = type; this.x = x; this.y = y; this.w = w; this.h = h; this.m = m; this.st = st;
        }
        boolean in(int mx, int my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }
    private final List<Hit> hits = new ArrayList<Hit>();
    private Hit dragging;
    private Module binding;
    private float scroll;
    private static final float CLASSIC_W = 44f;

    /** The GUI selected in the Gui option ("Default" = classic ClickGui, "Columns" = this one). */
    public static GuiScreen create() {
        return com.lumen.client.ClientSettings.gui.is("Columns") ? new ColumnGui() : new ClickGui();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        openAnim = 0f;
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    // ---- layout ----

    private float totalW() {
        return cats.length * COL_W + (cats.length - 1) * COL_GAP;
    }

    private float colX(int i) {
        return (width - totalW()) / 2f + i * (COL_W + COL_GAP);
    }

    private float baseTop() {
        return Math.max(12f, height * 0.18f);
    }

    private float colTop() {
        return baseTop() - scroll;
    }

    private float maxScroll() {
        float maxPanel = 0;
        for (Category c : cats) maxPanel = Math.max(maxPanel, panelHeight(visible(c)));
        float bottom = baseTop() + HEADER_H + HEADER_GAP + maxPanel + 14f + SEARCH_H + 12f;
        return Math.max(0f, bottom - height);
    }

    private List<Module> visible(Category c) {
        List<Module> out = new ArrayList<Module>();
        String q = query.toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.byCategory(c)) {
            if (q.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    private float rowHeight(Module m) {
        m.expandAnim += ((m.expanded ? 1f : 0f) - m.expandAnim) * 0.3f;
        if (Math.abs((m.expanded ? 1f : 0f) - m.expandAnim) < 0.01f) m.expandAnim = m.expanded ? 1f : 0f;
        return ROW_H + settingsHeight(m) * m.expandAnim;
    }

    private static float settingH(Setting st) {
        if (st instanceof NumberSetting) return 20f;
        if (st instanceof ColorSetting) return 34f;
        return 13f;
    }

    private static float settingsHeight(Module m) {
        float h = 0;
        for (Setting st : m.settings) if (st.visible()) h += settingH(st);
        return h + BIND_H + 4f;
    }

    private float panelHeight(List<Module> mods) {
        float h = PAD * 2;
        for (Module m : mods) h += rowHeight(m) + ROW_GAP;
        return Math.max(h - ROW_GAP, PAD * 2 + ROW_H);
    }

    private float searchY() {
        float maxPanel = 0;
        for (Category c : cats) maxPanel = Math.max(maxPanel, panelHeight(visible(c)));
        return colTop() + HEADER_H + HEADER_GAP + maxPanel + 14f;
    }

    // ---- drawing ----

    @Override
    public void drawScreen(int mx, int my, float pt) {
        openAnim = Math.min(1f, openAnim + 0.12f);
        float a = openAnim;
        drawRect(0, 0, width, height, Colors.withAlpha(0x000000, (int) (150 * a)));
        hits.clear();
        if (dragging != null) updateDrag(mx);

        for (int i = 0; i < cats.length; i++) {
            drawColumn(i, mx, my, a);
        }
        drawSearch(mx, my, a);
        float cx = (width + SEARCH_W) / 2f + 6f, cy = searchY();
        boolean ch = mx >= cx && mx <= cx + CLASSIC_W && my >= cy && my <= cy + SEARCH_H;
        RenderUtil.roundedRect(cx, cy, cx + CLASSIC_W, cy + SEARCH_H, SEARCH_H / 2f, Colors.mulAlpha(ch ? 0xC0202228 : COL_HEADER, a));
        RenderUtil.rectOutline(cx, cy, cx + CLASSIC_W, cy + SEARCH_H, 0.5f, Colors.mulAlpha(COL_STROKE, a));
        RenderUtil.string("Classic", cx + (CLASSIC_W - RenderUtil.width("Classic")) / 2f, cy + (SEARCH_H - 8f) / 2f, Colors.mulAlpha(COL_TEXT, a));
        hits.add(new Hit(H_CLASSIC, cx, cy, CLASSIC_W, SEARCH_H, null, null));
    }

    private void drawColumn(int i, int mx, int my, float a) {
        Category c = cats[i];
        float x = colX(i);
        float y = colTop() + (1f - a) * 8f;

        // header pill
        GlassFx.shadow(x, y, x + COL_W, y + HEADER_H, RADIUS, a * 0.6f);
        RenderUtil.roundedRect(x, y, x + COL_W, y + HEADER_H, RADIUS, Colors.mulAlpha(COL_HEADER, a));
        GlassFx.pane(x, y, x + COL_W, y + HEADER_H, RADIUS, a * 0.7f, 0.5f);
        float tw = RenderUtil.width(c.label);
        float lx = x + (COL_W - tw) / 2f + 5f;
        RenderUtil.string(c.label, lx, y + (HEADER_H - 8f) / 2f, Colors.mulAlpha(COL_TEXT, a));
        drawCategoryIcon(c, lx - 8f, y + HEADER_H / 2f, a);

        // panel
        List<Module> mods = visible(c);
        float py = y + HEADER_H + HEADER_GAP;
        float ph = panelHeight(mods);
        GlassFx.shadow(x, py, x + COL_W, py + ph, RADIUS, a);
        RenderUtil.roundedRect(x, py, x + COL_W, py + ph, RADIUS, Colors.mulAlpha(COL_PANEL, a));
        GlassFx.pane(x, py, x + COL_W, py + ph, RADIUS, a * 0.55f, 0.15f);

        float ry = py + PAD;
        for (Module m : mods) {
            drawRow(m, x + PAD, ry, COL_W - PAD * 2, mx, my, a);
            hits.add(new Hit(H_ROW, x + PAD, ry, COL_W - PAD * 2, ROW_H, m, null));
            float rh = rowHeight(m);
            if (m.expandAnim > 0.02f) {
                RenderUtil.scissor(x + PAD, ry + ROW_H, COL_W - PAD * 2, Math.max(0f, rh - ROW_H));
                drawSettings(m, x + PAD, ry + ROW_H + 2f, COL_W - PAD * 2, a * Math.min(1f, m.expandAnim * 1.5f), m.expandAnim > 0.95f);
                RenderUtil.endScissor();
            }
            ry += rh + ROW_GAP;
        }
    }

    private void drawRow(Module m, float x, float y, float w, int mx, int my, float a) {
        boolean hover = mx >= x && mx <= x + w && my >= y && my <= y + ROW_H;
        m.hoverAnim += ((hover ? 1f : 0f) - m.hoverAnim) * 0.25f;
        m.toggleAnim += ((m.isEnabled() ? 1f : 0f) - m.toggleAnim) * 0.25f;

        int base = Colors.lerp(0x18FFFFFF, COL_ROW_ON, m.toggleAnim);
        base = Colors.lerp(base, Colors.withAlpha(0xFFFFFF, Math.min(255, ((base >> 24) & 255) + 16)), m.hoverAnim);
        RenderUtil.roundedRect(x, y, x + w, y + ROW_H, 3f, Colors.mulAlpha(base, a));

        int text = Colors.lerp(COL_TEXT_DIM, 0xFF111214, m.toggleAnim);
        if (m.toggleAnim < 0.5f) text = Colors.lerp(COL_TEXT_DIM, COL_TEXT, m.hoverAnim);
        RenderUtil.string(m.name, x + 6f, y + (ROW_H - 8f) / 2f, Colors.mulAlpha(text, a));

        // toggle switch
        float sw = 14f, sh = 7f;
        float sx = x + w - sw - 5f, sy = y + (ROW_H - sh) / 2f;
        int track = Colors.lerp(0xFF3A3C42, 0xFF16171A, m.toggleAnim);
        RenderUtil.roundedRect(sx, sy, sx + sw, sy + sh, sh / 2f, Colors.mulAlpha(track, a));
        float kx = sx + sh / 2f + (sw - sh) * m.toggleAnim;
        int knob = Colors.lerp(0xFF8A8D94, 0xFFFFFFFF, m.toggleAnim);
        RenderUtil.circle(kx, sy + sh / 2f, sh / 2f - 1f, Colors.mulAlpha(knob, a));
    }

    /** Tiny vector glyphs for the header pills. (cx, cy) is the icon centre. */
    private void drawCategoryIcon(Category c, float cx, float cy, float a) {
        int col = Colors.mulAlpha(COL_TEXT, a);
        switch (c) {
            case HUD: // 2x2 grid
                for (int i = 0; i < 2; i++)
                    for (int j = 0; j < 2; j++)
                        RenderUtil.roundedRect(cx - 3.5f + i * 4f, cy - 3.5f + j * 4f, cx - 0.5f + i * 4f, cy - 0.5f + j * 4f, 0.8f, col);
                break;
            case COMBAT: // crossed blades
                RenderUtil.triangle(cx, cy, 4.5f, 45f, col);
                RenderUtil.triangle(cx, cy, 4.5f, -45f, col);
                break;
            default: // eye
                RenderUtil.ring(cx, cy, 3.6f, 1f, col);
                RenderUtil.circle(cx, cy, 1.4f, col);
                break;
        }
    }

    private void drawSettings(Module m, float x, float y, float w, float a, boolean live) {
        float ix = x + 6f, iw = w - 12f;
        RenderUtil.string("Bind", ix, y + 2f, Colors.mulAlpha(COL_TEXT, a));
        String kn = binding == m ? "..." : (m.key == Keyboard.KEY_NONE ? "None" : Keyboard.getKeyName(m.key));
        float kw = RenderUtil.width(kn) + 8f;
        RenderUtil.roundedRect(ix + iw - kw, y, ix + iw, y + 11f, 3f, Colors.mulAlpha(binding == m ? 0xFF4A4D55 : 0xFF2A2C32, a));
        RenderUtil.string(kn, ix + iw - kw + 4f, y + 2f, Colors.mulAlpha(COL_TEXT, a));
        if (live) hits.add(new Hit(H_BIND, ix + iw - kw, y, kw, 11f, m, null));
        y += BIND_H;
        for (Setting st : m.settings) {
            if (!st.visible()) continue;
            float h = settingH(st);
            if (st instanceof BooleanSetting) {
                BooleanSetting b = (BooleanSetting) st;
                st.anim += ((b.value ? 1f : 0f) - st.anim) * 0.3f;
                RenderUtil.string(st.name, ix, y + 2f, Colors.mulAlpha(COL_TEXT, a));
                float bx = ix + iw - 8f, by = y + 2f;
                RenderUtil.roundedRect(bx, by, bx + 8f, by + 8f, 2f, Colors.mulAlpha(Colors.lerp(0xFF3A3C42, 0xFFE1E1E1, st.anim), a));
                if (st.anim > 0.5f) RenderUtil.rect(bx + 2.5f, by + 2.5f, bx + 5.5f, by + 5.5f, Colors.mulAlpha(0xFF111214, a));
                if (live) hits.add(new Hit(H_BOOL, ix, y, iw, h, m, st));
            } else if (st instanceof ModeSetting) {
                ModeSetting ms = (ModeSetting) st;
                RenderUtil.string(st.name, ix, y + 2f, Colors.mulAlpha(COL_TEXT, a));
                String v = ms.get();
                RenderUtil.string(v, ix + iw - RenderUtil.width(v), y + 2f, Colors.mulAlpha(COL_TEXT_DIM, a));
                if (live) hits.add(new Hit(H_MODE, ix, y, iw, h, m, st));
            } else if (st instanceof NumberSetting) {
                NumberSetting n = (NumberSetting) st;
                RenderUtil.string(st.name, ix, y + 1f, Colors.mulAlpha(COL_TEXT, a));
                String v = n.display();
                RenderUtil.string(v, ix + iw - RenderUtil.width(v), y + 1f, Colors.mulAlpha(COL_TEXT_DIM, a));
                float ty = y + 13f;
                RenderUtil.roundedRect(ix, ty, ix + iw, ty + 2f, 1f, Colors.mulAlpha(0xFF3A3C42, a));
                float fx = ix + iw * (float) Math.max(0, Math.min(1, n.fraction()));
                RenderUtil.roundedRect(ix, ty, fx, ty + 2f, 1f, Colors.mulAlpha(0xFFE1E1E1, a));
                RenderUtil.circle(fx, ty + 1f, 2.5f, Colors.mulAlpha(0xFFFFFFFF, a));
                if (live) hits.add(new Hit(H_NUM, ix, y + 8f, iw, 12f, m, st));
            } else if (st instanceof ColorSetting) {
                ColorSetting c = (ColorSetting) st;
                RenderUtil.string(st.name, ix, y + 2f, Colors.mulAlpha(COL_TEXT, a));
                float sx = ix + iw - 10f;
                RenderUtil.roundedRect(sx, y + 1f, sx + 10f, y + 11f, 2f, Colors.mulAlpha(0xFF000000 | c.rgb(), a));
                // hue bar under the label row
                float hx = ix, hw = iw - 14f, hy = y + 13f;
                for (int i = 0; i < 12; i++) {
                    RenderUtil.rect(hx + hw * i / 12f, hy, hx + hw * (i + 1) / 12f, hy + 2f,
                            Colors.mulAlpha(0xFF000000 | Colors.hsb(i / 12f, 1f, 1f), a));
                }
                RenderUtil.circle(hx + hw * c.hue, hy + 1f, 2.5f, Colors.mulAlpha(0xFFFFFFFF, a));
                if (live) hits.add(new Hit(H_COLOR, hx, y + 10f, hw, 7f, m, st));
                // saturation bar
                float sy2 = y + 21f;
                int full = Colors.hsb(c.hue, 1f, Math.max(c.val, 0.3f));
                RenderUtil.gradientH(hx, sy2, hx + hw, sy2 + 2f, Colors.mulAlpha(Colors.hsb(c.hue, 0f, Math.max(c.val, 0.3f)), a), Colors.mulAlpha(full, a));
                RenderUtil.circle(hx + hw * c.sat, sy2 + 1f, 2.5f, Colors.mulAlpha(0xFFFFFFFF, a));
                if (live) hits.add(new Hit(H_SAT, hx, y + 18f, hw, 7f, m, st));
                // brightness bar
                float vy = y + 29f;
                RenderUtil.gradientH(hx, vy, hx + hw, vy + 2f, Colors.mulAlpha(0xFF000000, a), Colors.mulAlpha(Colors.hsb(c.hue, c.sat, 1f), a));
                RenderUtil.circle(hx + hw * c.val, vy + 1f, 2.5f, Colors.mulAlpha(0xFFFFFFFF, a));
                if (live) hits.add(new Hit(H_VAL, hx, y + 26f, hw, 7f, m, st));
            }
            y += h;
        }
    }

    private void updateDrag(int mx) {
        if (dragging.st instanceof NumberSetting) {
            NumberSetting n = (NumberSetting) dragging.st;
            double f = Math.max(0, Math.min(1, (mx - dragging.x) / dragging.w));
            n.set(n.min + f * (n.max - n.min));
        } else if (dragging.st instanceof ColorSetting) {
            ColorSetting c = (ColorSetting) dragging.st;
            float f = (float) Math.max(0, Math.min(1, (mx - dragging.x) / dragging.w));
            if (dragging.type == H_SAT) c.sat = f;
            else if (dragging.type == H_VAL) c.val = f;
            else c.hue = f;
        }
    }

    private void drawSearch(int mx, int my, float a) {
        float x = (width - SEARCH_W) / 2f;
        float y = searchY();
        int fill = searchFocused ? 0xC0202228 : COL_HEADER;
        RenderUtil.roundedRect(x, y, x + SEARCH_W, y + SEARCH_H, SEARCH_H / 2f, Colors.mulAlpha(fill, a));
        RenderUtil.rectOutline(x, y, x + SEARCH_W, y + SEARCH_H, 0.5f, Colors.mulAlpha(COL_STROKE, a));
        boolean empty = query.isEmpty();
        String shown = empty ? "Search for module..." : query;
        if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) shown += "_";
        RenderUtil.string(shown, x + 8f, y + (SEARCH_H - 8f) / 2f,
                Colors.mulAlpha(empty && !searchFocused ? COL_TEXT_DIM : COL_TEXT, a));
    }

    // ---- input ----

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        float sx = (width - SEARCH_W) / 2f, sy = searchY();
        binding = null;
        searchFocused = mx >= sx && mx <= sx + SEARCH_W && my >= sy && my <= sy + SEARCH_H;
        if (searchFocused) return;

        for (Hit h : hits) {
            if (!h.in(mx, my)) continue;
            switch (h.type) {
                case H_ROW:
                    if (button == 0) h.m.toggle();
                    else if (button == 1) h.m.expanded = !h.m.expanded;
                    return;
                case H_BIND:
                    binding = h.m;
                    return;
                case H_CLASSIC:
                    mc.displayGuiScreen(new ClickGui());
                    return;
                case H_BOOL:
                    ((BooleanSetting) h.st).toggle();
                    return;
                case H_MODE:
                    ((ModeSetting) h.st).cycle(button == 1 ? -1 : 1);
                    return;
                case H_NUM:
                case H_COLOR:
                case H_SAT:
                case H_VAL:
                    dragging = h;
                    updateDrag(mx);
                    return;
            }
        }
        super.mouseClicked(mx, my, button);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scroll = Math.max(0f, Math.min(maxScroll(), scroll - Integer.signum(d) * 24f));
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        dragging = null;
        super.mouseReleased(mx, my, state);
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (binding != null) {
            binding.key = (key == Keyboard.KEY_ESCAPE || key == Keyboard.KEY_DELETE) ? Keyboard.KEY_NONE : key;
            binding = null;
            return;
        }
        if (searchFocused) {
            if (key == Keyboard.KEY_ESCAPE) {
                searchFocused = false;
                return;
            }
            if (key == Keyboard.KEY_BACK) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
            } else if (c >= 32 && c != 127 && query.length() < 24) {
                query += c;
            }
            return;
        }
        super.keyTyped(c, key); // ESC closes
    }
}
