package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.HudModule;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class ArmorStatus extends HudModule {
    private final BooleanSetting heldItem = add(new BooleanSetting("Held Item", true));
    private final ModeSetting durability = add(new ModeSetting("Durability", "Number", "Number", "Percent", "Off"));

    public ArmorStatus() {
        super("Armor Status", "Shows your armor and held item with their durability.", Category.HUD, 4, 172);
    }

    @Override
    protected void draw() {
        EntityPlayer p = mc.thePlayer;
        if (p == null) return;

        List<ItemStack> stacks = new ArrayList<ItemStack>();
        for (int i = 3; i >= 0; i--) {
            ItemStack s = p.inventory.armorInventory[i];
            if (s != null) stacks.add(s);
        }
        if (heldItem.value && p.getHeldItem() != null) {
            stacks.add(p.getHeldItem());
        }
        if (stacks.isEmpty()) {
            if (editing()) {
                labelValue("Armor", "(empty)");
            } else {
                width = 0;
                height = 0;
            }
            return;
        }

        int n = stacks.size();
        String[] texts = new String[n];
        int[] colors = new int[n];
        float maxText = 0;
        for (int i = 0; i < n; i++) {
            ItemStack s = stacks.get(i);
            int max = s.getMaxDamage();
            if (max > 0 && !durability.is("Off")) {
                int left = max - s.getItemDamage();
                texts[i] = durability.is("Percent") ? (left * 100 / max) + "%" : String.valueOf(left);
                colors[i] = Colors.hsb(0.33f * Math.max(0f, Math.min(1f, left / (float) max)), 0.8f, 1f);
            } else if (s.stackSize > 1) {
                texts[i] = "x" + s.stackSize;
                colors[i] = 0xFFFFFFFF;
            } else {
                texts[i] = "";
                colors[i] = 0xFFFFFFFF;
            }
            maxText = Math.max(maxText, RenderUtil.width(texts[i]));
        }

        float rowH = 18f;
        box(22 + maxText + 5, n * rowH + 2);

        RenderHelper.enableGUIStandardItemLighting();
        for (int i = 0; i < n; i++) {
            mc.getRenderItem().renderItemAndEffectIntoGUI(stacks.get(i), 3, 1 + (int) (i * rowH));
        }
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();

        for (int i = 0; i < n; i++) {
            RenderUtil.string(texts[i], 22, 1 + i * rowH + 5, colors[i]);
        }
    }
}
