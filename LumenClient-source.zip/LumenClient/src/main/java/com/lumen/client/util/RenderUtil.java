package com.lumen.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

/** Small 2D drawing helpers used by the ClickGUI and the HUD. All colours are ARGB. */
public final class RenderUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private RenderUtil() {}

    // Precomputed corner / circle geometry: the old code called cos/sin for every vertex of every shape every frame.
    private static final int SEG = 8;
    private static final float[][] CORNER_COS = new float[4][SEG + 1];
    private static final float[][] CORNER_SIN = new float[4][SEG + 1];
    private static final int GLOW_SEG = 28;
    private static final float[] GLOW_COS = new float[GLOW_SEG + 1];
    private static final float[] GLOW_SIN = new float[GLOW_SEG + 1];

    static {
        float[] start = { 180f, 270f, 0f, 90f };
        for (int c = 0; c < 4; c++) {
            for (int i = 0; i <= SEG; i++) {
                double ang = Math.toRadians(start[c] + i * (90f / SEG));
                CORNER_COS[c][i] = (float) Math.cos(ang);
                CORNER_SIN[c][i] = (float) Math.sin(ang);
            }
        }
        for (int i = 0; i <= GLOW_SEG; i++) {
            double ang = i * Math.PI * 2 / GLOW_SEG;
            GLOW_COS[i] = (float) Math.cos(ang);
            GLOW_SIN[i] = (float) Math.sin(ang);
        }
    }

    private static float a(int c) { return ((c >> 24) & 255) / 255f; }
    private static float r(int c) { return ((c >> 16) & 255) / 255f; }
    private static float g(int c) { return ((c >> 8) & 255) / 255f; }
    private static float b(int c) { return (c & 255) / 255f; }

    private static void begin2D() {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    }

    private static void end2D() {
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        // the shape code above sets colours with raw glColor4f, which GlStateManager's colour cache doesn't see:
        // reset the real colour too, or a later white draw is skipped as "unchanged" and keeps the stale tint
        GL11.glColor4f(1f, 1f, 1f, 1f);
    }

    public static void rect(float x, float y, float x2, float y2, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION);
        wr.pos(x, y2, 0).endVertex();
        wr.pos(x2, y2, 0).endVertex();
        wr.pos(x2, y, 0).endVertex();
        wr.pos(x, y, 0).endVertex();
        t.draw();
        end2D();
    }

    public static void rectOutline(float x, float y, float x2, float y2, float thickness, int color) {
        rect(x, y, x2, y + thickness, color);
        rect(x, y2 - thickness, x2, y2, color);
        rect(x, y + thickness, x + thickness, y2 - thickness, color);
        rect(x2 - thickness, y + thickness, x2, y2 - thickness, color);
    }

    private static void quad(float x, float y, float x2, float y2, int tl, int tr, int br, int bl) {
        begin2D();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x2, y, 0).color(Colors.channel(tr, 16), Colors.channel(tr, 8), Colors.channel(tr, 0), Colors.channel(tr, 24)).endVertex();
        wr.pos(x, y, 0).color(Colors.channel(tl, 16), Colors.channel(tl, 8), Colors.channel(tl, 0), Colors.channel(tl, 24)).endVertex();
        wr.pos(x, y2, 0).color(Colors.channel(bl, 16), Colors.channel(bl, 8), Colors.channel(bl, 0), Colors.channel(bl, 24)).endVertex();
        wr.pos(x2, y2, 0).color(Colors.channel(br, 16), Colors.channel(br, 8), Colors.channel(br, 0), Colors.channel(br, 24)).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    public static void gradientV(float x, float y, float x2, float y2, int top, int bottom) {
        quad(x, y, x2, y2, top, top, bottom, bottom);
    }

    public static void gradientH(float x, float y, float x2, float y2, int left, int right) {
        quad(x, y, x2, y2, left, right, right, left);
    }

    public static void roundedRect(float x, float y, float x2, float y2, float radius, int color) {
        roundedRectH(x, y, x2, y2, radius, color, color);
    }

    /** Rounded rectangle with a horizontal colour gradient. */
    public static void roundedRectH(float x, float y, float x2, float y2, float radius, int left, int right) {
        if (x2 <= x || y2 <= y) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        begin2D();
        GlStateManager.shadeModel(7425);
        boolean flat = left == right; // one colour: set it once instead of per vertex
        if (flat) GL11.glColor4f(r(left), g(left), b(left), a(left));
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        if (flat) GL11.glVertex2f((x + x2) / 2f, (y + y2) / 2f);
        else vertex(x, x2, (x + x2) / 2f, (y + y2) / 2f, left, right);
        for (int c = 0; c < 4; c++) {
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            for (int i = 0; i <= SEG; i++) {
                float vx = ccx + CORNER_COS[c][i] * r, vy = ccy + CORNER_SIN[c][i] * r;
                if (flat) GL11.glVertex2f(vx, vy);
                else vertex(x, x2, vx, vy, left, right);
            }
        }
        // close the fan on the first rim point
        if (flat) GL11.glVertex2f(x, y + r);
        else vertex(x, x2, x, y + r, left, right);
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    private static void vertex(float x0, float x1, float vx, float vy, int left, int right) {
        int c = Colors.lerp(left, right, (vx - x0) / Math.max(1f, x1 - x0));
        GL11.glColor4f(r(c), g(c), b(c), a(c));
        GL11.glVertex2f(vx, vy);
    }

    /**
     * Soft radial light: {@code color} at the centre fading to fully transparent at the radius.
     * Plain smooth-shaded triangles only (no shaders / framebuffers), so it also runs on GL wrappers.
     */
    public static void glow(float cx, float cy, float radius, int color) {
        if (a(color) <= 0.004f) return;
        begin2D();
        GlStateManager.shadeModel(7425);
        int stride = radius < 24f ? 2 : 1; // small glows (mouse trail) don't need 28 segments
        int mid = Colors.mulAlpha(color, 0.38f);
        int none = Colors.mulAlpha(color, 0f);
        float rm = radius * 0.5f;
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glColor4f(r(color), g(color), b(color), a(color));
        GL11.glVertex2f(cx, cy);
        GL11.glColor4f(r(mid), g(mid), b(mid), a(mid));
        for (int i = 0; i <= GLOW_SEG; i += stride) {
            GL11.glVertex2f(cx + GLOW_COS[i] * rm, cy + GLOW_SIN[i] * rm);
        }
        GL11.glEnd();
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int i = 0; i <= GLOW_SEG; i += stride) {
            float ca = GLOW_COS[i], sa = GLOW_SIN[i];
            GL11.glColor4f(r(mid), g(mid), b(mid), a(mid));
            GL11.glVertex2f(cx + ca * rm, cy + sa * rm);
            GL11.glColor4f(r(none), g(none), b(none), 0f);
            GL11.glVertex2f(cx + ca * radius, cy + sa * radius);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /** Thin rounded outline whose colour blends from {@code topLeft} to {@code bottomRight} along the diagonal. */
    public static void roundedOutline(float x, float y, float x2, float y2, float radius, float thickness, int topLeft, int bottomRight) {
        if (x2 <= x || y2 <= y) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        float ri = Math.max(0.01f, r - thickness);
        float invW = 1f / (x2 - x), invH = 1f / (y2 - y);
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int n = 0; n <= 4 * (SEG + 1); n++) {
            int c = (n / (SEG + 1)) % 4, i = n % (SEG + 1);
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            float ca = CORNER_COS[c][i], sa = CORNER_SIN[c][i];
            float ox = ccx + ca * r, oy = ccy + sa * r;
            float t = ((ox - x) * invW + (oy - y) * invH) * 0.5f;
            int col = Colors.lerp(topLeft, bottomRight, t);
            GL11.glColor4f(r(col), g(col), b(col), a(col));
            GL11.glVertex2f(ox, oy);
            GL11.glVertex2f(ccx + ca * ri, ccy + sa * ri);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /** Rounded rectangle with a vertical colour gradient (top -> bottom). */
    public static void roundedRectV(float x, float y, float x2, float y2, float radius, int top, int bottom) {
        if (x2 <= x || y2 <= y) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        float invH = 1f / Math.max(1f, y2 - y);
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        int mid = Colors.lerp(top, bottom, 0.5f);
        GL11.glColor4f(r(mid), g(mid), b(mid), a(mid));
        GL11.glVertex2f((x + x2) / 2f, (y + y2) / 2f);
        for (int n = 0; n <= 4 * (SEG + 1); n++) {
            int c = (n / (SEG + 1)) % 4, i = n % (SEG + 1);
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            float vx = ccx + CORNER_COS[c][i] * r, vy = ccy + CORNER_SIN[c][i] * r;
            int col = Colors.lerp(top, bottom, (vy - y) * invH);
            GL11.glColor4f(r(col), g(col), b(col), a(col));
            GL11.glVertex2f(vx, vy);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /**
     * Directional rim light along a rounded rectangle's edge, the building block of the Liquid Glass look.
     * The light comes from direction (lx, ly) (unit vector, e.g. -0.7,-0.7 = top-left): the edge facing the light
     * is brightest, the opposite edge catches a weaker bounce ({@code opp}), the sides keep {@code ambient}.
     * The band is thicker where it is brighter, and fades from {@code outerA} at the edge to {@code innerA}
     * inside. One smooth-shaded triangle strip, no textures or shaders.
     */
    public static void rimLight(float x, float y, float x2, float y2, float radius, float thick, int rgb,
                                float outerA, float innerA, float lx, float ly, float ambient, float opp) {
        if (x2 <= x || y2 <= y || outerA <= 0.5f) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        float hx = (x2 - x) / 2f, hy = (y2 - y) / 2f, cx = x + hx, cy = y + hy;
        float cr = r(rgb), cg = g(rgb), cb = b(rgb);
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int n = 0; n <= 4 * (SEG + 1); n++) {
            int c = (n / (SEG + 1)) % 4, i = n % (SEG + 1);
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            float ca = CORNER_COS[c][i], sa = CORNER_SIN[c][i];
            float ox = ccx + ca * r, oy = ccy + sa * r;
            float dx = (ox - cx) / hx, dy = (oy - cy) / hy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            float sl = len > 1e-4f ? (dx * lx + dy * ly) / len : 0f;
            float lit = sl > 0f ? sl * sl : opp * sl * sl;
            float inten = ambient + (1f - ambient) * Math.min(1f, lit);
            float t = Math.min(thick * (0.65f + 0.7f * inten), r * 0.9f);
            float ri = Math.max(0.01f, r - t);
            GL11.glColor4f(cr, cg, cb, outerA * inten / 255f);
            GL11.glVertex2f(ox, oy);
            GL11.glColor4f(cr, cg, cb, innerA * inten / 255f);
            GL11.glVertex2f(ccx + ca * ri, ccy + sa * ri);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /** One vertex of the glass body: vertical "thickness" gradient plus a light sweep coming from (lx, ly). */
    private static void glassVertex(float vx, float vy, float cx, float cy, float hx, float hy, float y, float invH,
                                    int top, int bottom, int sweep, float lx, float ly) {
        int c = Colors.lerp(top, bottom, (vy - y) * invH);
        float s = ((vx - cx) / hx) * lx + ((vy - cy) / hy) * ly;
        float f = 0.5f + 0.4f * s;
        f = f < 0f ? 0f : (f > 1f ? 1f : f);
        c = Colors.lerp(c, sweep, f * f);
        GL11.glColor4f(r(c), g(c), b(c), a(c));
        GL11.glVertex2f(vx, vy);
    }

    /** Glass body: one triangle fan, denser towards the bottom and lit softly from the light direction. */
    private static void glassBody(float x, float y, float x2, float y2, float r, int top, int bottom, int sweep, float lx, float ly) {
        float hx = (x2 - x) / 2f, hy = (y2 - y) / 2f, cx = x + hx, cy = y + hy;
        float invH = 1f / Math.max(1f, y2 - y);
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        glassVertex(cx, cy, cx, cy, hx, hy, y, invH, top, bottom, sweep, lx, ly);
        for (int n = 0; n <= 4 * (SEG + 1); n++) {
            int c = (n / (SEG + 1)) % 4, i = n % (SEG + 1);
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            glassVertex(ccx + CORNER_COS[c][i] * r, ccy + CORNER_SIN[c][i] * r, cx, cy, hx, hy, y, invH, top, bottom, sweep, lx, ly);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /**
     * Dispersion: a thin band just inside the edge that goes from {@code outerRgb} (at the edge) to {@code innerRgb},
     * like the colour split a thick glass edge makes. Strongest where the edge faces towards or away from the light.
     */
    public static void rimFringe(float x, float y, float x2, float y2, float radius, float thick, float inset,
                                 int outerRgb, int innerRgb, float alpha, float lx, float ly) {
        if (x2 <= x || y2 <= y || alpha <= 0.5f) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        float hx = (x2 - x) / 2f, hy = (y2 - y) / 2f, cx = x + hx, cy = y + hy;
        float ro = Math.max(0.01f, r - inset), ri = Math.max(0.01f, r - inset - thick);
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int n = 0; n <= 4 * (SEG + 1); n++) {
            int c = (n / (SEG + 1)) % 4, i = n % (SEG + 1);
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            float ca = CORNER_COS[c][i], sa = CORNER_SIN[c][i];
            float dx = (ccx + ca * r - cx) / hx, dy = (ccy + sa * r - cy) / hy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            float sl = len > 1e-4f ? (dx * lx + dy * ly) / len : 0f;
            float inten = 0.25f + 0.75f * sl * sl;
            GL11.glColor4f(r(outerRgb), g(outerRgb), b(outerRgb), alpha * inten / 255f);
            GL11.glVertex2f(ccx + ca * ro, ccy + sa * ro);
            GL11.glColor4f(r(innerRgb), g(innerRgb), b(innerRgb), alpha * inten * 0.3f / 255f);
            GL11.glVertex2f(ccx + ca * ri, ccy + sa * ri);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /**
     * Liquid Glass pane modelled on Figma's Glass effect (light angle, light, refraction, depth, dispersion, frost,
     * splay): a clear frosted body that is denser at the bottom and lit softly from the light direction, a bevel
     * (bright refraction band on the lit edge, dark one on the far edge, which is what gives the glass thickness),
     * a rainbow dispersion fringe, a gloss, and a specular rim that is brightest at the two corners on the light axis.
     * Everything is plain smooth-shaded triangles with alpha blending (no blur shader, framebuffer copy, stencil or
     * texture read), which is all a fixed-function GL renderer such as Krypton / GL4ES needs.
     *
     * @param fill      body colour (ARGB)
     * @param sheenAlpha strength of the top gloss (0..255)
     * @param specAlpha strength of the specular rim at the lit corners (0..255)
     * @param glowAlpha strength of the refraction bevel (0..255)
     */
    public static void glassPanel(float x, float y, float x2, float y2, float radius, int fill, int sheenAlpha,
                                  int specAlpha, int glowAlpha, float lx, float ly) {
        float w = x2 - x, h = y2 - y;
        if (w <= 0f || h <= 0f) return;
        float r = Math.min(radius, Math.min(w, h) / 2f);
        float ll = (float) Math.sqrt(lx * lx + ly * ly);
        if (ll < 1e-4f) { lx = -0.7071f; ly = -0.7071f; } else { lx /= ll; ly /= ll; }
        boolean lite = Math.min(w, h) < 16f; // tiny panes (HUD keys, small buttons) skip the costly extras

        // body (frost): clear, denser towards the bottom, with a soft sweep of light from the lit corner
        int fa = (fill >>> 24) & 255;
        int bottom = Colors.withAlpha(Colors.lerp(Colors.opaque(fill), 0xFF0A0B10, 0.5f), (int) (fa * 0.95f));
        int sweep = Colors.withAlpha(0xFFFFFF, fa + (int) (specAlpha * 0.09f));
        glassBody(x, y, x2, y2, r, fill, bottom, sweep, lx, ly);

        // gloss: a wide soft highlight on the upper part, kept inside the corner arcs
        if (sheenAlpha > 0) {
            float inset = Math.min(r * 0.7f, w / 4f);
            gradientV(x + inset, y + 1.2f, x2 - inset, y + h * 0.42f, Colors.withAlpha(0xFFFFFF, sheenAlpha), 0x00FFFFFF);
        }
        if (!lite && glowAlpha > 0) {
            // depth: the edge that faces away from the light is darkened, so the pane reads as a thick slab
            rimLight(x, y, x2, y2, r, Math.min(5f, h * 0.22f), 0x03040A, glowAlpha * 1.3f, 0f, -lx, -ly, 0.3f, 0.12f);
            // refraction: light gathers in a soft band inside the edge, strongest towards the light
            rimLight(x, y, x2, y2, r, Math.min(6f, h * 0.24f), 0xFFFFFF, glowAlpha, 0f, lx, ly, 0.3f, 0.7f);
        }
        // dispersion: warm-to-cool colour split just inside the rim
        if (!lite && specAlpha > 0) {
            rimFringe(x, y, x2, y2, r, Math.min(2.6f, h * 0.14f), 0.9f, 0xFF8FB8, 0x7FD8FF, specAlpha * 0.16f, lx, ly);
        }
        // specular rim: bright at the corners facing the light, dim on the sides
        rimLight(x, y, x2, y2, r, 1.4f, 0xFFFFFF, specAlpha, specAlpha * 0.5f, lx, ly, 0.2f, 0.6f);
    }

    /**
     * Panel for the coloured (non-glass) themes: a dark body that is a little lighter on top, an accent wash that
     * grows with {@code lit} (hover / enabled), a top sheen, a dark bevel on the bottom-right edge for depth, an
     * accent rim that blends from {@code rim1} to {@code rim2} and a small specular line on the top-left.
     * Same primitives as the glass pane (smooth-shaded triangles + alpha), so it is as cheap and as GL-wrapper safe.
     *
     * @param top    body colour at the top (ARGB); {@code bottom} at the bottom
     * @param rim1   accent RGB at the top-left of the rim; {@code rim2} at the bottom-right
     * @param alpha  overall fade (0..1)
     */
    public static void themedPanel(float x, float y, float x2, float y2, float radius, int top, int bottom,
                                   int rim1, int rim2, float lit, float alpha) {
        float w = x2 - x, h = y2 - y;
        if (w <= 0f || h <= 0f || alpha <= 0.004f) return;
        float r = Math.min(radius, Math.min(w, h) / 2f);
        boolean lite = Math.min(w, h) < 16f;
        roundedRectV(x, y, x2, y2, r, Colors.mulAlpha(top, alpha), Colors.mulAlpha(bottom, alpha));
        if (lit > 0.02f) {
            roundedRectV(x, y, x2, y2, r, Colors.mulAlpha(Colors.withAlpha(rim1, (int) (62 * lit)), alpha),
                    Colors.mulAlpha(Colors.withAlpha(rim2, (int) (96 * lit)), alpha));
        }
        float inset = Math.min(r * 0.7f, w / 4f);
        gradientV(x + inset, y + 1.2f, x2 - inset, y + h * 0.45f,
                Colors.mulAlpha(Colors.withAlpha(0xFFFFFF, (int) (14 + 24 * lit)), alpha), 0x00FFFFFF);
        if (!lite) {
            rimLight(x, y, x2, y2, r, Math.min(4f, h * 0.2f), 0x02030A, alpha * 46f, 0f, 0.7071f, 0.7071f, 0.2f, 0.1f);
        }
        roundedOutline(x, y, x2, y2, r, 1f, Colors.mulAlpha(Colors.withAlpha(rim1, (int) (100 + 110 * lit)), alpha),
                Colors.mulAlpha(Colors.withAlpha(rim2, (int) (45 + 90 * lit)), alpha));
        rimLight(x, y, x2, y2, r, 1f, 0xFFFFFF, alpha * (60f + 80f * lit), alpha * (20f + 30f * lit),
                -0.7071f, -0.7071f, 0.04f, 0.45f);
    }

    public static void glassPanel(float x, float y, float x2, float y2, float radius, int fill, int sheenAlpha,
                                  int specAlpha, int glowAlpha) {
        glassPanel(x, y, x2, y2, radius, fill, sheenAlpha, specAlpha, glowAlpha, -0.7071f, -0.7071f);
    }

    public static void circle(float cx, float cy, float radius, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(cx, cy);
        for (int i = 0; i <= 24; i++) {
            double ang = i * Math.PI * 2 / 24;
            GL11.glVertex2f(cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius);
        }
        GL11.glEnd();
        end2D();
    }

    public static void ring(float cx, float cy, float radius, float lineWidth, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(lineWidth);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i < 40; i++) {
            double ang = i * Math.PI * 2 / 40;
            GL11.glVertex2f(cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius);
        }
        GL11.glEnd();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(1f);
        end2D();
    }

    /** Small filled triangle pointing right when rotation is 0 (degrees, clockwise on screen). */
    public static void triangle(float cx, float cy, float size, float rotationDeg, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glBegin(GL11.GL_TRIANGLES);
        double rot = Math.toRadians(rotationDeg);
        double[] angles = { 0, Math.toRadians(140), Math.toRadians(220) };
        for (double ang : angles) {
            double an = ang + rot;
            GL11.glVertex2f(cx + (float) Math.cos(an) * size, cy + (float) Math.sin(an) * size);
        }
        GL11.glEnd();
        end2D();
    }

    // ---- text --------------------------------------------------------------------------------

    public static int width(String s) {
        return mc.fontRendererObj.getStringWidth(s);
    }

    /** Draws shadowed text. Colours with alpha below ~4 would be drawn opaque by vanilla, so skip them. */
    /** Set by HudModule while it draws, so every HUD text follows the module's "Text Shadow" setting. */
    public static boolean hudShadow = true;
    /** True only while a HUD module is drawing. */
    public static boolean inHud = false;

    public static void string(String s, float x, float y, int color) {
        if (((color >>> 24) & 255) < 5) return;
        mc.fontRendererObj.drawString(s, x, y, color, !inHud || hudShadow);
    }

    public static void stringFlat(String s, float x, float y, int color) {
        if (((color >>> 24) & 255) < 5) return;
        mc.fontRendererObj.drawString(s, x, y, color, inHud && hudShadow);
    }

    // ---- scissor -----------------------------------------------------------------------------

    /** Clips drawing to a rectangle given in GUI-scaled coordinates. Call endScissor() afterwards. */
    public static void scissor(float x, float y, float w, float h) {
        int f = new ScaledResolution(mc).getScaleFactor();
        int sx = Math.round(x * f);
        int sw = Math.max(0, Math.round(w * f));
        int sh = Math.max(0, Math.round(h * f));
        int sy = mc.displayHeight - Math.round((y + h) * f);
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(sx, sy, sw, sh);
    }

    public static void endScissor() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }
}
