package com.lumen.client.util;

import com.lumen.client.gui.LumenFont;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

/** Small 2D drawing helpers used by the ClickGUI and the HUD. All colours are ARGB. */
public final class RenderUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private RenderUtil() {}

    private static float a(int c) { return ((c >> 24) & 255) / 255f; }
    private static float r(int c) { return ((c >> 16) & 255) / 255f; }
    private static float g(int c) { return ((c >> 8) & 255) / 255f; }
    private static float b(int c) { return (c & 255) / 255f; }

    private static void begin2D() {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    }

    private static void end2D() {
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public static void rect(float x, float y, float x2, float y2, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION);
        wr.pos(x, y2, 0).endVertex();
        wr.pos(x2, y2, 0).endVertex();
        wr.pos(x2, y, 0).endVertex();
        wr.pos(x, y, 0).endVertex();
        t.draw();
        end2D();
    }

    public static void rectOutline(float x, float y, float x2, float y2, float thickness, int color) {
        rect(x, y, x2, y + thickness, color);
        rect(x, y2 - thickness, x2, y2, color);
        rect(x, y + thickness, x + thickness, y2 - thickness, color);
        rect(x2 - thickness, y + thickness, x2, y2 - thickness, color);
    }

    private static void quad(float x, float y, float x2, float y2, int tl, int tr, int br, int bl) {
        begin2D();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x2, y, 0).color(Colors.channel(tr, 16), Colors.channel(tr, 8), Colors.channel(tr, 0), Colors.channel(tr, 24)).endVertex();
        wr.pos(x, y, 0).color(Colors.channel(tl, 16), Colors.channel(tl, 8), Colors.channel(tl, 0), Colors.channel(tl, 24)).endVertex();
        wr.pos(x, y2, 0).color(Colors.channel(bl, 16), Colors.channel(bl, 8), Colors.channel(bl, 0), Colors.channel(bl, 24)).endVertex();
        wr.pos(x2, y2, 0).color(Colors.channel(br, 16), Colors.channel(br, 8), Colors.channel(br, 0), Colors.channel(br, 24)).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    public static void gradientV(float x, float y, float x2, float y2, int top, int bottom) {
        quad(x, y, x2, y2, top, top, bottom, bottom);
    }

    public static void gradientH(float x, float y, float x2, float y2, int left, int right) {
        quad(x, y, x2, y2, left, right, right, left);
    }

    public static void roundedRect(float x, float y, float x2, float y2, float radius, int color) {
        roundedRectH(x, y, x2, y2, radius, color, color);
    }

    /** Rounded rectangle with a horizontal colour gradient. */
    public static void roundedRectH(float x, float y, float x2, float y2, float radius, int left, int right) {
        if (x2 <= x || y2 <= y) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        vertex(x, x2, (x + x2) / 2f, (y + y2) / 2f, left, right);
        int seg = 6;
        float[][] corners = {
                { x + r, y + r, 180f },
                { x2 - r, y + r, 270f },
                { x2 - r, y2 - r, 0f },
                { x + r, y2 - r, 90f }
        };
        for (float[] c : corners) {
            for (int i = 0; i <= seg; i++) {
                double ang = Math.toRadians(c[2] + i * (90f / seg));
                vertex(x, x2, c[0] + (float) Math.cos(ang) * r, c[1] + (float) Math.sin(ang) * r, left, right);
            }
        }
        vertex(x, x2, x + r - r, y + r, left, right); // close the fan on the first rim point
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    private static void vertex(float x0, float x1, float vx, float vy, int left, int right) {
        int c = Colors.lerp(left, right, (vx - x0) / Math.max(1f, x1 - x0));
        GL11.glColor4f(r(c), g(c), b(c), a(c));
        GL11.glVertex2f(vx, vy);
    }

    public static void circle(float cx, float cy, float radius, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(cx, cy);
        for (int i = 0; i <= 24; i++) {
            double ang = i * Math.PI * 2 / 24;
            GL11.glVertex2f(cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius);
        }
        GL11.glEnd();
        end2D();
    }

    public static void ring(float cx, float cy, float radius, float lineWidth, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(lineWidth);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i < 40; i++) {
            double ang = i * Math.PI * 2 / 40;
            GL11.glVertex2f(cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius);
        }
        GL11.glEnd();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(1f);
        end2D();
    }

    /** Small filled triangle pointing right when rotation is 0 (degrees, clockwise on screen). */
    public static void triangle(float cx, float cy, float size, float rotationDeg, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glBegin(GL11.GL_TRIANGLES);
        double rot = Math.toRadians(rotationDeg);
        double[] angles = { 0, Math.toRadians(140), Math.toRadians(220) };
        for (double ang : angles) {
            double an = ang + rot;
            GL11.glVertex2f(cx + (float) Math.cos(an) * size, cy + (float) Math.sin(an) * size);
        }
        GL11.glEnd();
        end2D();
    }

    // ---- text --------------------------------------------------------------------------------

    /** HUD text is laid out for the 8px vanilla font; the client font is scaled to match. */
    private static final float HUD_K = 8f / LumenFont.EM;

    public static int width(String s) {
        if (LumenFont.isCustom()) return Math.round(LumenFont.width(s) * HUD_K);
        return mc.fontRendererObj.getStringWidth(s);
    }

    /** Draws shadowed text. Colours with alpha below ~4 would be drawn opaque by vanilla, so skip them. */
    public static void string(String s, float x, float y, int color) {
        if (((color >>> 24) & 255) < 5) return;
        if (LumenFont.isCustom()) {
            drawCustom(s, x, y, color, true);
            return;
        }
        mc.fontRendererObj.drawStringWithShadow(s, x, y, color);
    }

    public static void stringFlat(String s, float x, float y, int color) {
        if (((color >>> 24) & 255) < 5) return;
        if (LumenFont.isCustom()) {
            drawCustom(s, x, y, color, false);
            return;
        }
        mc.fontRendererObj.drawString(s, x, y, color, false);
    }

    private static void drawCustom(String s, float x, float y, int color, boolean shadow) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(HUD_K, HUD_K, 1f);
        LumenFont.draw(s, 0f, 0f, color, shadow);
        GlStateManager.popMatrix();
    }

    public static void stringCentered(String s, float cx, float y, int color) {
        string(s, cx - width(s) / 2f, y, color);
    }

    // ---- scissor -----------------------------------------------------------------------------

    /** Clips drawing to a rectangle given in GUI-scaled coordinates. Call endScissor() afterwards. */
    public static void scissor(float x, float y, float w, float h) {
        int f = new ScaledResolution(mc).getScaleFactor();
        int sx = Math.round(x * f);
        int sw = Math.max(0, Math.round(w * f));
        int sh = Math.max(0, Math.round(h * f));
        int sy = mc.displayHeight - Math.round((y + h) * f);
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(sx, sy, sw, sh);
    }

    public static void endScissor() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }
}
