package com.lumen.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

/** Small 2D drawing helpers used by the ClickGUI and the HUD. All colours are ARGB. */
public final class RenderUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private RenderUtil() {}

    // Precomputed corner / circle geometry: the old code called cos/sin for every vertex of every shape every frame.
    private static final int SEG = 6;
    private static final float[][] CORNER_COS = new float[4][SEG + 1];
    private static final float[][] CORNER_SIN = new float[4][SEG + 1];
    private static final int GLOW_SEG = 28;
    private static final float[] GLOW_COS = new float[GLOW_SEG + 1];
    private static final float[] GLOW_SIN = new float[GLOW_SEG + 1];

    static {
        float[] start = { 180f, 270f, 0f, 90f };
        for (int c = 0; c < 4; c++) {
            for (int i = 0; i <= SEG; i++) {
                double ang = Math.toRadians(start[c] + i * (90f / SEG));
                CORNER_COS[c][i] = (float) Math.cos(ang);
                CORNER_SIN[c][i] = (float) Math.sin(ang);
            }
        }
        for (int i = 0; i <= GLOW_SEG; i++) {
            double ang = i * Math.PI * 2 / GLOW_SEG;
            GLOW_COS[i] = (float) Math.cos(ang);
            GLOW_SIN[i] = (float) Math.sin(ang);
        }
    }

    private static float a(int c) { return ((c >> 24) & 255) / 255f; }
    private static float r(int c) { return ((c >> 16) & 255) / 255f; }
    private static float g(int c) { return ((c >> 8) & 255) / 255f; }
    private static float b(int c) { return (c & 255) / 255f; }

    private static void begin2D() {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
    }

    private static void end2D() {
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public static void rect(float x, float y, float x2, float y2, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION);
        wr.pos(x, y2, 0).endVertex();
        wr.pos(x2, y2, 0).endVertex();
        wr.pos(x2, y, 0).endVertex();
        wr.pos(x, y, 0).endVertex();
        t.draw();
        end2D();
    }

    public static void rectOutline(float x, float y, float x2, float y2, float thickness, int color) {
        rect(x, y, x2, y + thickness, color);
        rect(x, y2 - thickness, x2, y2, color);
        rect(x, y + thickness, x + thickness, y2 - thickness, color);
        rect(x2 - thickness, y + thickness, x2, y2 - thickness, color);
    }

    private static void quad(float x, float y, float x2, float y2, int tl, int tr, int br, int bl) {
        begin2D();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x2, y, 0).color(Colors.channel(tr, 16), Colors.channel(tr, 8), Colors.channel(tr, 0), Colors.channel(tr, 24)).endVertex();
        wr.pos(x, y, 0).color(Colors.channel(tl, 16), Colors.channel(tl, 8), Colors.channel(tl, 0), Colors.channel(tl, 24)).endVertex();
        wr.pos(x, y2, 0).color(Colors.channel(bl, 16), Colors.channel(bl, 8), Colors.channel(bl, 0), Colors.channel(bl, 24)).endVertex();
        wr.pos(x2, y2, 0).color(Colors.channel(br, 16), Colors.channel(br, 8), Colors.channel(br, 0), Colors.channel(br, 24)).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    public static void gradientV(float x, float y, float x2, float y2, int top, int bottom) {
        quad(x, y, x2, y2, top, top, bottom, bottom);
    }

    public static void gradientH(float x, float y, float x2, float y2, int left, int right) {
        quad(x, y, x2, y2, left, right, right, left);
    }

    public static void roundedRect(float x, float y, float x2, float y2, float radius, int color) {
        roundedRectH(x, y, x2, y2, radius, color, color);
    }

    /** Rounded rectangle with a horizontal colour gradient. */
    public static void roundedRectH(float x, float y, float x2, float y2, float radius, int left, int right) {
        if (x2 <= x || y2 <= y) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        begin2D();
        GlStateManager.shadeModel(7425);
        boolean flat = left == right; // one colour: set it once instead of per vertex
        if (flat) GL11.glColor4f(r(left), g(left), b(left), a(left));
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        if (flat) GL11.glVertex2f((x + x2) / 2f, (y + y2) / 2f);
        else vertex(x, x2, (x + x2) / 2f, (y + y2) / 2f, left, right);
        for (int c = 0; c < 4; c++) {
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            for (int i = 0; i <= SEG; i++) {
                float vx = ccx + CORNER_COS[c][i] * r, vy = ccy + CORNER_SIN[c][i] * r;
                if (flat) GL11.glVertex2f(vx, vy);
                else vertex(x, x2, vx, vy, left, right);
            }
        }
        // close the fan on the first rim point
        if (flat) GL11.glVertex2f(x, y + r);
        else vertex(x, x2, x, y + r, left, right);
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    private static void vertex(float x0, float x1, float vx, float vy, int left, int right) {
        int c = Colors.lerp(left, right, (vx - x0) / Math.max(1f, x1 - x0));
        GL11.glColor4f(r(c), g(c), b(c), a(c));
        GL11.glVertex2f(vx, vy);
    }

    /**
     * Soft radial light: {@code color} at the centre fading to fully transparent at the radius.
     * Plain smooth-shaded triangles only (no shaders / framebuffers), so it also runs on GL wrappers.
     */
    public static void glow(float cx, float cy, float radius, int color) {
        if (a(color) <= 0.004f) return;
        begin2D();
        GlStateManager.shadeModel(7425);
        int stride = radius < 24f ? 2 : 1; // small glows (mouse trail) don't need 28 segments
        int mid = Colors.mulAlpha(color, 0.38f);
        int none = Colors.mulAlpha(color, 0f);
        float rm = radius * 0.5f;
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glColor4f(r(color), g(color), b(color), a(color));
        GL11.glVertex2f(cx, cy);
        GL11.glColor4f(r(mid), g(mid), b(mid), a(mid));
        for (int i = 0; i <= GLOW_SEG; i += stride) {
            GL11.glVertex2f(cx + GLOW_COS[i] * rm, cy + GLOW_SIN[i] * rm);
        }
        GL11.glEnd();
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int i = 0; i <= GLOW_SEG; i += stride) {
            float ca = GLOW_COS[i], sa = GLOW_SIN[i];
            GL11.glColor4f(r(mid), g(mid), b(mid), a(mid));
            GL11.glVertex2f(cx + ca * rm, cy + sa * rm);
            GL11.glColor4f(r(none), g(none), b(none), 0f);
            GL11.glVertex2f(cx + ca * radius, cy + sa * radius);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /** Thin rounded outline whose colour blends from {@code topLeft} to {@code bottomRight} along the diagonal. */
    public static void roundedOutline(float x, float y, float x2, float y2, float radius, float thickness, int topLeft, int bottomRight) {
        if (x2 <= x || y2 <= y) return;
        float r = Math.min(radius, Math.min((x2 - x) / 2f, (y2 - y) / 2f));
        float ri = Math.max(0.01f, r - thickness);
        float invW = 1f / (x2 - x), invH = 1f / (y2 - y);
        begin2D();
        GlStateManager.shadeModel(7425);
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        for (int n = 0; n <= 4 * (SEG + 1); n++) {
            int c = (n / (SEG + 1)) % 4, i = n % (SEG + 1);
            float ccx = (c == 0 || c == 3) ? x + r : x2 - r;
            float ccy = c < 2 ? y + r : y2 - r;
            float ca = CORNER_COS[c][i], sa = CORNER_SIN[c][i];
            float ox = ccx + ca * r, oy = ccy + sa * r;
            float t = ((ox - x) * invW + (oy - y) * invH) * 0.5f;
            int col = Colors.lerp(topLeft, bottomRight, t);
            GL11.glColor4f(r(col), g(col), b(col), a(col));
            GL11.glVertex2f(ox, oy);
            GL11.glVertex2f(ccx + ca * ri, ccy + sa * ri);
        }
        GL11.glEnd();
        GlStateManager.shadeModel(7424);
        end2D();
    }

    /**
     * A frosted glass pane: translucent fill, a soft top sheen and a lit rim. The blur is faked with
     * layered translucent shapes, which is all a plain GL 1.x renderer needs.
     */
    public static void glassPanel(float x, float y, float x2, float y2, float radius, int fill, int sheenAlpha, int rimTL, int rimBR) {
        roundedRect(x, y, x2, y2, radius, fill);
        float h = y2 - y;
        float inset = Math.min(radius * 0.55f, (x2 - x) / 4f);
        gradientV(x + inset, y + 1f, x2 - inset, y + h * 0.5f, Colors.withAlpha(0xFFFFFF, sheenAlpha), 0x00FFFFFF);
        roundedOutline(x, y, x2, y2, radius, 1f, rimTL, rimBR);
    }

    public static void circle(float cx, float cy, float radius, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(cx, cy);
        for (int i = 0; i <= 24; i++) {
            double ang = i * Math.PI * 2 / 24;
            GL11.glVertex2f(cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius);
        }
        GL11.glEnd();
        end2D();
    }

    public static void ring(float cx, float cy, float radius, float lineWidth, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(lineWidth);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i < 40; i++) {
            double ang = i * Math.PI * 2 / 40;
            GL11.glVertex2f(cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius);
        }
        GL11.glEnd();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(1f);
        end2D();
    }

    /** Small filled triangle pointing right when rotation is 0 (degrees, clockwise on screen). */
    public static void triangle(float cx, float cy, float size, float rotationDeg, int color) {
        begin2D();
        GlStateManager.color(r(color), g(color), b(color), a(color));
        GL11.glBegin(GL11.GL_TRIANGLES);
        double rot = Math.toRadians(rotationDeg);
        double[] angles = { 0, Math.toRadians(140), Math.toRadians(220) };
        for (double ang : angles) {
            double an = ang + rot;
            GL11.glVertex2f(cx + (float) Math.cos(an) * size, cy + (float) Math.sin(an) * size);
        }
        GL11.glEnd();
        end2D();
    }

    // ---- text --------------------------------------------------------------------------------

    public static int width(String s) {
        return mc.fontRendererObj.getStringWidth(s);
    }

    /** Draws shadowed text. Colours with alpha below ~4 would be drawn opaque by vanilla, so skip them. */
    /** Set by HudModule while it draws, so every HUD text follows the module's "Text Shadow" setting. */
    public static boolean hudShadow = true;
    /** True only while a HUD module is drawing. */
    public static boolean inHud = false;

    public static void string(String s, float x, float y, int color) {
        if (((color >>> 24) & 255) < 5) return;
        mc.fontRendererObj.drawString(s, x, y, color, !inHud || hudShadow);
    }

    public static void stringFlat(String s, float x, float y, int color) {
        if (((color >>> 24) & 255) < 5) return;
        mc.fontRendererObj.drawString(s, x, y, color, inHud && hudShadow);
    }

    // ---- scissor -----------------------------------------------------------------------------

    /** Clips drawing to a rectangle given in GUI-scaled coordinates. Call endScissor() afterwards. */
    public static void scissor(float x, float y, float w, float h) {
        int f = new ScaledResolution(mc).getScaleFactor();
        int sx = Math.round(x * f);
        int sw = Math.max(0, Math.round(w * f));
        int sh = Math.max(0, Math.round(h * f));
        int sy = mc.displayHeight - Math.round((y + h) * f);
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(sx, sy, sw, sh);
    }

    public static void endScissor() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }
}
