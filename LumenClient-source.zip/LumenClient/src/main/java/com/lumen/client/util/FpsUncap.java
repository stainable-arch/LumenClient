package com.lumen.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.lang.reflect.Field;

/**
 * Removes vanilla's 30 fps cap on menus (title screen, world / server lists, ... everything shown while
 * no world is loaded).
 *
 * Vanilla only calls Display.sync(...) while the frame-rate limit is below the slider's maximum. In menus the
 * limit is hard-coded to 30, so we lower the slider's maximum to 30 for as long as such a screen is open;
 * the check then fails and the loop runs uncapped (V-Sync still applies if you have it on). In game, and on the
 * video settings screen (whose slider needs the real maximum), the original value is put back, so your own
 * FPS limit keeps working. The field is found by type and value, so it works with any mappings.
 */
public final class FpsUncap {
    public static final FpsUncap INSTANCE = new FpsUncap();

    private Field maxField;
    private float realMax;
    private boolean failed;
    private boolean uncapped;

    private FpsUncap() {}

    private void init() {
        try {
            // GameSettings.Options has valueMin / valueStep / valueMax as float fields; the largest value of
            // FRAMERATE_LIMIT is its maximum (260)
            Field best = null;
            float bestVal = -1f;
            for (Field f : GameSettings.Options.class.getDeclaredFields()) {
                if (f.getType() != float.class || java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                float v = f.getFloat(GameSettings.Options.FRAMERATE_LIMIT);
                if (v > bestVal) {
                    bestVal = v;
                    best = f;
                }
            }
            if (best == null || bestVal <= 30f) {
                failed = true;
                return;
            }
            maxField = best;
            realMax = bestVal;
        } catch (Throwable t) {
            failed = true;
        }
    }

    private void set(boolean uncap) {
        if (uncap == uncapped) return;
        try {
            maxField.setFloat(GameSettings.Options.FRAMERATE_LIMIT, uncap ? 30f : realMax);
            uncapped = uncap;
        } catch (Throwable t) {
            failed = true;
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START || failed) return;
        if (maxField == null) {
            init();
            if (failed) return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        boolean menu = mc.theWorld == null && mc.currentScreen != null;
        // the video settings slider is built from this maximum, so it must see the real one
        if (menu && mc.currentScreen.getClass().getSimpleName().toLowerCase().contains("video")) menu = false;
        set(menu);
    }
}
