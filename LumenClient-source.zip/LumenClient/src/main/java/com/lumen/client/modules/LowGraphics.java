package com.lumen.client.modules;

import com.lumen.client.ClientSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Backs ClickGUI > Settings > Performance > Low Graphics. Forces the cheapest video settings while the master
 * switch is on, each one switchable. When a sub-option (or the master) is switched off, the value the game had
 * before is put back. Only vanilla GameSettings fields are touched, so it works with OptiFine too. The game saves
 * options.txt on exit, so quit with Low Graphics off if you want your own video settings kept.
 */
public final class LowGraphics {
    public static final LowGraphics INSTANCE = new LowGraphics();

    private final Minecraft mc = Minecraft.getMinecraft();
    private boolean fastOn, cloudsOn, aoOn, partOn, shadowOn, distOn;
    private boolean oFancy, oShadows;
    private int oClouds, oAo, oPart, oDist;
    private int tick = 19;

    private LowGraphics() {}

    private void reloadRenderers() {
        if (mc.renderGlobal != null && mc.theWorld != null) mc.renderGlobal.loadRenderers();
    }

    private void restoreAll() {
        GameSettings g = mc.gameSettings;
        boolean reload = false;
        if (fastOn) { g.fancyGraphics = oFancy; reload = true; }
        if (cloudsOn) g.clouds = oClouds;
        if (aoOn) { g.ambientOcclusion = oAo; reload = true; }
        if (partOn) g.particleSetting = oPart;
        if (shadowOn) g.entityShadows = oShadows;
        if (distOn) { g.renderDistanceChunks = oDist; reload = true; }
        fastOn = cloudsOn = aoOn = partOn = shadowOn = distOn = false;
        if (reload) reloadRenderers();
        tick = 19;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.gameSettings == null) return;
        if (!ClientSettings.lowGraphics.value) {
            if (fastOn || cloudsOn || aoOn || partOn || shadowOn || distOn) restoreAll();
            return;
        }
        if (ClientSettings.lgNoWeather.value && mc.theWorld != null) {
            mc.theWorld.setRainStrength(0f);
            mc.theWorld.setThunderStrength(0f);
        }
        if (++tick < 20) return;
        tick = 0;
        GameSettings g = mc.gameSettings;
        boolean reload = false;

        if (ClientSettings.lgFast.value) {
            if (!fastOn) { oFancy = g.fancyGraphics; fastOn = true; }
            if (g.fancyGraphics) { g.fancyGraphics = false; reload = true; }
        } else if (fastOn) { g.fancyGraphics = oFancy; fastOn = false; reload = true; }

        if (ClientSettings.lgNoClouds.value) {
            if (!cloudsOn) { oClouds = g.clouds; cloudsOn = true; }
            g.clouds = 0;
        } else if (cloudsOn) { g.clouds = oClouds; cloudsOn = false; }

        if (ClientSettings.lgNoAo.value) {
            if (!aoOn) { oAo = g.ambientOcclusion; aoOn = true; }
            if (g.ambientOcclusion != 0) { g.ambientOcclusion = 0; reload = true; }
        } else if (aoOn) { g.ambientOcclusion = oAo; aoOn = false; reload = true; }

        if (ClientSettings.lgParticles.value) {
            if (!partOn) { oPart = g.particleSetting; partOn = true; }
            g.particleSetting = 2;
        } else if (partOn) { g.particleSetting = oPart; partOn = false; }

        if (ClientSettings.lgNoShadows.value) {
            if (!shadowOn) { oShadows = g.entityShadows; shadowOn = true; }
            g.entityShadows = false;
        } else if (shadowOn) { g.entityShadows = oShadows; shadowOn = false; }

        if (ClientSettings.lgCapDist.value) {
            if (!distOn) { oDist = g.renderDistanceChunks; distOn = true; }
            int cap = ClientSettings.lgMaxChunks.getInt();
            if (g.renderDistanceChunks > cap) { g.renderDistanceChunks = cap; reload = true; }
        } else if (distOn) { g.renderDistanceChunks = oDist; distOn = false; reload = true; }

        if (reload) reloadRenderers();
    }
}
