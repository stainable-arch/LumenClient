package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.fx.ParticleSystem;
import com.lumen.client.gui.Sounds;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import net.minecraft.block.BlockBed;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * When a bed disappears (you broke it) a cloud of cute custom particles spreads out:
 * hearts, stars, sparkles and bubbles in pastel colours.
 *
 * Detection is fully client side: while you hold attack on a bed we remember its position;
 * when that block stops being a bed, we burst. "Nearby" mode also reacts to beds that vanish
 * within ~12 blocks (other players, explosions).
 */
public class BedVisuals extends Module {
    private final ModeSetting trigger = add(new ModeSetting("Trigger", "Mine", "Mine", "Nearby"));
    private final ModeSetting palette = add(new ModeSetting("Colors", "Pastel", "Pastel", "Pink", "Rainbow", "Theme"));
    private final ModeSetting shape = add(new ModeSetting("Shape", "Mixed", "Mixed", "Hearts", "Stars", "Sparkles"));
    private final NumberSetting amount = add(new NumberSetting("Amount", 60, 10, 160, 5));
    private final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.5, 2.0, 0.1));
    private final NumberSetting glow = add(new NumberSetting("Glow", 1, 0, 10, 1));
    private final BooleanSetting sound = add(new BooleanSetting("Sound", true));

    private static final int[] PASTEL = { 0xFF9EC8, 0xC9A6FF, 0x9ADBFF, 0xB5FFD9, 0xFFF3A6, 0xFFFFFF, 0xFFB38A };
    private static final int[] PINK = { 0xFF6FA8, 0xFF9EC8, 0xFFC2DB, 0xFFFFFF, 0xFF4F94 };

    private final Random rand = new Random();
    private final Set<BlockPos> known = new HashSet<BlockPos>();
    private BlockPos tracked;
    private int trackedTick;
    private int tick;
    private BlockPos lastBurstPos;
    private int lastBurstTick = -1000;

    public BedVisuals() {
        super("Bed Visuals", "Cute custom particles spread out when a bed is broken.", Category.VISUALS);
    }

    @Override
    protected void onDisable() {
        tracked = null;
        known.clear();
    }

    private boolean isBed(World w, BlockPos p) {
        return w.getBlockState(p).getBlock() instanceof BlockBed;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        World w = mc.theWorld;
        if (w == null || mc.thePlayer == null) {
            tracked = null;
            known.clear();
            return;
        }
        tick++;

        MovingObjectPosition mop = mc.objectMouseOver;
        if (mc.currentScreen == null && mc.gameSettings.keyBindAttack.isKeyDown()
                && mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            BlockPos bp = mop.getBlockPos();
            if (isBed(w, bp)) {
                tracked = bp;
                trackedTick = tick;
            }
        }
        if (tracked != null) {
            if (tick - trackedTick > 80) {
                tracked = null;
            } else if (!isBed(w, tracked)) {
                burst(tracked);
                tracked = null;
            }
        }

        if (trigger.is("Nearby") && tick % 10 == 0) {
            scanNearby(w);
        } else if (!trigger.is("Nearby") && !known.isEmpty()) {
            known.clear();
        }
    }

    private void scanNearby(World w) {
        BlockPos me = new BlockPos(mc.thePlayer);
        Set<BlockPos> now = new HashSet<BlockPos>();
        int r = 12;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -6; dy <= 6; dy++) {
                    BlockPos p = me.add(dx, dy, dz);
                    if (isBed(w, p)) now.add(p);
                }
            }
        }
        for (BlockPos old : known) {
            if (!now.contains(old) && w.isBlockLoaded(old) && !isBed(w, old)) {
                burst(old);
            }
        }
        known.clear();
        known.addAll(now);
    }

    private void burst(BlockPos pos) {
        // a bed has two halves that vanish together: only celebrate once
        if (lastBurstPos != null && tick - lastBurstTick < 20) {
            int dx = lastBurstPos.getX() - pos.getX();
            int dy = lastBurstPos.getY() - pos.getY();
            int dz = lastBurstPos.getZ() - pos.getZ();
            if (dx * dx + dy * dy + dz * dz < 9) return;
        }
        lastBurstPos = pos;
        lastBurstTick = tick;

        double cx = pos.getX() + 0.5;
        double cy = pos.getY() + 0.45;
        double cz = pos.getZ() + 0.5;
        int n = amount.getInt();
        for (int i = 0; i < n; i++) {
            boolean ring = i < n * 0.35;
            double ang = rand.nextDouble() * Math.PI * 2;
            double speed = ring ? 0.06 + rand.nextDouble() * 0.05 : 0.015 + rand.nextDouble() * 0.05;
            double vx = Math.cos(ang) * speed;
            double vz = Math.sin(ang) * speed;
            double vy = ring ? 0.02 + rand.nextDouble() * 0.03 : 0.05 + rand.nextDouble() * 0.11;
            float sz = (float) ((0.07 + rand.nextDouble() * 0.10) * size.value);
            ParticleSystem.INSTANCE.spawn(new ParticleSystem.Particle(
                    cx + (rand.nextDouble() - 0.5) * 0.9, cy + rand.nextDouble() * 0.25, cz + (rand.nextDouble() - 0.5) * 0.9,
                    vx, vy, vz, sz, 30 + rand.nextInt(32), pickSprite(), pickColor())
                    .physics(-0.0015f, 0.93f, 0.0035f)
                    .spin((float) rand.nextGaussian() * 4f)
                    .glow(glow.getFloat() / 10f));
        }
        if (sound.value) {
            Sounds.play("random.orb", 1.7f);
            Sounds.play("note.pling", 1.9f);
        }
    }

    private int pickSprite() {
        if (shape.is("Hearts")) return ParticleSystem.HEART;
        if (shape.is("Stars")) return ParticleSystem.STAR;
        if (shape.is("Sparkles")) return ParticleSystem.SPARKLE;
        float f = rand.nextFloat();
        if (f < 0.42f) return ParticleSystem.HEART;
        if (f < 0.62f) return ParticleSystem.STAR;
        if (f < 0.92f) return ParticleSystem.SPARKLE;
        return ParticleSystem.BUBBLE;
    }

    private int pickColor() {
        if (palette.is("Pink")) return PINK[rand.nextInt(PINK.length)];
        if (palette.is("Rainbow")) return Colors.hsb(rand.nextFloat(), 0.45f, 1f);
        if (palette.is("Theme")) return Colors.gradient(Theme.current(), rand.nextFloat());
        return PASTEL[rand.nextInt(PASTEL.length)];
    }
}
