package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.NumberSetting;

/** Client customization settings exposed in the Client category. */
public class ClientSettingsModule extends Module {
    public final ModeSetting auraColor = add(new ModeSetting("Aura Color", "Theme", "Theme", "White", "Black", "Pink", "Blue", "Rainbow"));
    public final NumberSetting auraSize = add(new NumberSetting("Aura Size", 1.0, 0.5, 3.0, 0.1));
    public final BooleanSetting characterAura = add(new BooleanSetting("Character Aura", false));
    public final BooleanSetting claudeCape = add(new BooleanSetting("Claude Cape", false));
    public final BooleanSetting capeGlow = add(new BooleanSetting("Cape Glow", true));

    public ClientSettingsModule() {
        super("Settings", "Client cosmetics and visual preferences.", Category.CLIENT);
    }
}
