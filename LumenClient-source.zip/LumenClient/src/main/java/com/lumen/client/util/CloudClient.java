package com.lumen.client.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lumen.client.ClientSettings;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;

/**
 * Talks to the Lumen config cloud server (see CLOUD_API.md for the REST API).
 *
 * Everything runs on a background thread and the callback is delivered on the game thread.
 * Identity is your Minecraft account: the client joins a server id with Mojang's session server and
 * the cloud server verifies that join, so nobody can pose as someone else. The resulting token is
 * only kept in memory.
 */
public final class CloudClient {
    public interface Callback {
        /** Exactly one of result / error is non-null. */
        void done(JsonElement result, String error);
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int MAX_BODY = 512 * 1024;
    private static volatile String token;

    private CloudClient() {}

    public static boolean configured() {
        return !ClientSettings.cloudUrl.isEmpty();
    }

    public static void list(String query, boolean mine, Callback cb) {
        String path = mine ? "/v1/my/configs" : "/v1/configs?q=" + enc(query == null ? "" : query);
        call("GET", path, null, mine, cb);
    }

    public static void get(String id, Callback cb) {
        call("GET", "/v1/configs/" + enc(id), null, false, cb);
    }

    public static void upload(String name, String description, boolean isPublic, JsonObject data, Callback cb) {
        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        body.addProperty("description", description);
        body.addProperty("visibility", isPublic ? "public" : "private");
        body.add("data", data);
        call("POST", "/v1/configs", body, true, cb);
    }

    public static void delete(String id, Callback cb) {
        call("DELETE", "/v1/configs/" + enc(id), null, true, cb);
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static void call(final String method, final String path, final JsonObject body, final boolean auth, final Callback cb) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                JsonElement result = null;
                String error = null;
                try {
                    result = execute(method, path, body, auth);
                } catch (Exception ex) {
                    error = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                }
                final JsonElement r = result;
                final String err = error;
                Minecraft.getMinecraft().addScheduledTask(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(r, err);
                    }
                });
            }
        }, "Lumen-Cloud");
        t.setDaemon(true);
        t.start();
    }

    private static JsonElement execute(String method, String path, JsonObject body, boolean auth) throws Exception {
        if (!configured()) throw new Exception("No cloud server set. Use /lumen cloud url <address>");
        if (auth && token == null) login();
        try {
            return http(method, path, body, auth || token != null);
        } catch (HttpError e) {
            if (e.code == 401 && auth) {
                // token expired: sign in again once
                token = null;
                login();
                return http(method, path, body, true);
            }
            throw e;
        }
    }

    private static void login() throws Exception {
        JsonElement ch = http("GET", "/v1/auth/challenge", null, false);
        String serverId = ch.getAsJsonObject().get("serverId").getAsString();

        Minecraft mc = Minecraft.getMinecraft();
        GameProfile profile = mc.getSession().getProfile();
        try {
            mc.getSessionService().joinServer(profile, mc.getSession().getToken(), serverId);
        } catch (Exception ex) {
            throw new Exception("Minecraft sign-in failed (offline / cracked account?)");
        }
        JsonObject req = new JsonObject();
        req.addProperty("name", profile.getName());
        req.addProperty("uuid", profile.getId() == null ? "" : profile.getId().toString().replace("-", ""));
        req.addProperty("serverId", serverId);
        JsonElement res = http("POST", "/v1/auth/login", req, false);
        token = res.getAsJsonObject().get("token").getAsString();
    }

    private static final class HttpError extends Exception {
        final int code;

        HttpError(int code, String msg) {
            super(msg);
            this.code = code;
        }
    }

    private static JsonElement http(String method, String path, JsonObject body, boolean sendToken) throws Exception {
        String base = ClientSettings.cloudUrl;
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        HttpURLConnection c = (HttpURLConnection) new URL(base + path).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", "LumenClient");
            c.setRequestProperty("Accept", "application/json");
            if (sendToken && token != null) c.setRequestProperty("Authorization", "Bearer " + token);
            if (body != null) {
                byte[] data = body.toString().getBytes(UTF8);
                if (data.length > MAX_BODY) throw new Exception("Config is too large to upload");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                OutputStream os = c.getOutputStream();
                try {
                    os.write(data);
                } finally {
                    os.close();
                }
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = in == null ? "" : readAll(in);
            JsonElement json = null;
            try {
                if (!text.isEmpty()) json = new JsonParser().parse(text);
            } catch (Exception ignored) {
                // not JSON
            }
            if (code >= 400) {
                String msg = "Server error " + code;
                if (json != null && json.isJsonObject() && json.getAsJsonObject().has("error")) {
                    msg = json.getAsJsonObject().get("error").getAsString();
                }
                throw new HttpError(code, msg);
            }
            if (json == null) json = new JsonObject();
            return json;
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > 2 * MAX_BODY) throw new Exception("Response too large");
            }
            return new String(out.toByteArray(), UTF8);
        } finally {
            in.close();
        }
    }
}
