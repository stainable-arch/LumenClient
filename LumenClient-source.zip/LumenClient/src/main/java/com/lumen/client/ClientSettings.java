package com.lumen.client;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.LumenFont;

/** Global client toggles that are not tied to a single module. */
public final class ClientSettings {
    public static boolean aurora = true;
    public static boolean sounds = true;
    /** Cosmetics for Lumen users (currently the Lumen cape; no options yet). */
    public static boolean cosmetics = true;
    /** Cosmetics option: the black cape with a white "claude" in the Winkle font. */
    public static final BooleanSetting cape = new BooleanSetting("Black cape", true);
    /** Cosmetics option: a Tung Tung Tung Sahur pet that walks beside the player. */
    public static final BooleanSetting sahurPet = new BooleanSetting("Tung Tung Sahur pet", false);
    /** "cute": a picture in the bottom-left of the ClickGUI (Settings page). */
    public static boolean cute = false;
    public static final NumberSetting cuteScale = new NumberSetting("Scale", 1.0, 0.3, 3.0, 0.05);
    /** Top-left corner of the picture as a fraction of the screen; negative = default bottom-left spot. */
    public static float cuteX = -1f, cuteY = -1f;
    /** Resource pack screen: packs can be dragged between and inside the lists. */
    public static boolean packDraggable = true;
    /** Font of the menus: locked to Winkle. The HUD always uses the vanilla font. */
    public static String font = "Winkle";

    /** Hypixel API key used by the Level Head module (set with /lumen apikey). */
    public static String hypixelKey = "";

    /** Voxyl (bedwarspractice.club) API key used by Level Head's Bedwars Practice source (set with /lumen voxylkey). */
    public static String voxylKey = "";

    /** Base URL of the config cloud server (set with /lumen cloud url <url>). */
    public static String cloudUrl = "";

    /** Checkboxes of the Options screen (gear button, top right of the ClickGUI), in display order. */
    public static final java.util.List<BooleanSetting> OPTIONS = new java.util.ArrayList<BooleanSetting>();

    /** Registers a new checkbox for the Options screen. Its label doubles as the config key. */
    public static BooleanSetting option(String label, boolean def) {
        BooleanSetting b = new BooleanSetting(label, def);
        OPTIONS.add(b);
        return b;
    }

    // ---- add new Options checkboxes below, e.g.:
    // public static final BooleanSetting exampleOption = option("Example", false);

    /** Off = no grass, ferns, flowers or double plants are rendered. */
    public static final BooleanSetting renderFoliage = option("Render Foliage", true);

    /** On = the camera does not bob while walking; the hand keeps bobbing. */
    public static final BooleanSetting minimalViewBobbing = option("Minimal View Bobbing", false);

    /** On = no camera shake when you take damage. */
    public static final BooleanSetting noHurtCam = option("No Hurt Cam", false);

    private ClientSettings() {}

    /** The menu font is locked to Winkle: any requested name (e.g. from an old config) is ignored. */
    public static void setFont(String name) {
        font = "Winkle";
        LumenFont.setFace("Winkle");
    }

    public static void cycleFont(int dir) {
        // locked to Winkle
    }
}
