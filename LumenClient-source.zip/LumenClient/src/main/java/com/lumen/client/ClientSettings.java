package com.lumen.client;

import com.lumen.client.gui.LumenFont;
import com.lumen.client.gui.Sounds;

/** Global client toggles that are not tied to a single module. */
public final class ClientSettings {
    public static boolean aurora = true;
    /** Master switch for all UI sounds. */
    public static boolean sounds = true;
    /** Sound pack of the UI sounds (one of Sounds.PACKS); the main one is the creamy keyboard. */
    public static String soundPack = Sounds.DEFAULT_PACK;
    /** UI sound volume, 0..1 (on top of Minecraft's master volume). */
    public static float soundVolume = Sounds.DEFAULT_VOLUME;
    /** Random pitch variation per sound, 0..Sounds.MAX_VARIATION (fraction). */
    public static float soundVariation = Sounds.DEFAULT_VARIATION;
    /** Key sounds while typing in the menu's search box. */
    public static boolean typeSounds = true;
    /** Font of the ClickGUI (one of LumenFont.FACES). The HUD always uses the vanilla font. */
    public static String font = "Winkle";

    private ClientSettings() {}

    public static void setFont(String name) {
        for (String f : LumenFont.FACES) {
            if (f.equalsIgnoreCase(name)) {
                font = f;
                LumenFont.setFace(f);
                return;
            }
        }
    }

    public static void cycleFont(int dir) {
        int i = 0;
        for (int k = 0; k < LumenFont.FACES.length; k++) {
            if (LumenFont.FACES[k].equalsIgnoreCase(font)) i = k;
        }
        int n = LumenFont.FACES.length;
        setFont(LumenFont.FACES[(i + dir + n) % n]);
    }

    /** Selects a sound pack by name (case-insensitive); unknown names are ignored. */
    public static void setSoundPack(String name) {
        for (String p : Sounds.PACKS) {
            if (p.equalsIgnoreCase(name)) {
                soundPack = p;
                return;
            }
        }
    }

    public static void cycleSoundPack(int dir) {
        int i = 0;
        for (int k = 0; k < Sounds.PACKS.length; k++) {
            if (Sounds.PACKS[k].equalsIgnoreCase(soundPack)) i = k;
        }
        int n = Sounds.PACKS.length;
        soundPack = Sounds.PACKS[(i + dir + n) % n];
    }
}
