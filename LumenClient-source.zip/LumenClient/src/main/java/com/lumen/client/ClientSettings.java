package com.lumen.client;

import com.lumen.client.gui.LumenFont;

/** Global client toggles that are not tied to a single module. */
public final class ClientSettings {
    public static boolean aurora = true;
    public static boolean sounds = true;
    /** Font of the ClickGUI (one of LumenFont.FACES). The HUD always uses the vanilla font. */
    public static String font = "Winkle";

    /** Hypixel API key used by the Level Head module (set with /lumen apikey). */
    public static String hypixelKey = "";

    /** Base URL of the config cloud server (set with /lumen cloud url <url>). */
    public static String cloudUrl = "";

    private ClientSettings() {}

    public static void setFont(String name) {
        for (String f : LumenFont.FACES) {
            if (f.equalsIgnoreCase(name)) {
                font = f;
                LumenFont.setFace(f);
                return;
            }
        }
    }

    public static void cycleFont(int dir) {
        int i = 0;
        for (int k = 0; k < LumenFont.FACES.length; k++) {
            if (LumenFont.FACES[k].equalsIgnoreCase(font)) i = k;
        }
        int n = LumenFont.FACES.length;
        setFont(LumenFont.FACES[(i + dir + n) % n]);
    }
}
