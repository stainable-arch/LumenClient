package com.lumen.client;

/** Global client toggles that are not tied to a single module. */
public final class ClientSettings {
    public static boolean aurora = true;
    public static boolean sounds = true;

    private ClientSettings() {}
}
