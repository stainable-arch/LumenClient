package com.lumen.client;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.LumenFont;

/** Global client toggles that are not tied to a single module. */
public final class ClientSettings {
    public static boolean aurora = true;
    public static boolean sounds = true;
    /** Cosmetics for Lumen users (currently the Lumen cape; no options yet). */
    public static boolean cosmetics = true;
    /** Cosmetics option: the black cape with a white "claude" in the Winkle font. */
    public static final BooleanSetting cape = new BooleanSetting("Black cape", true);
    /** Cosmetics option: a Tung Tung Tung Sahur pet that walks beside the player. */
    public static final BooleanSetting sahurPet = new BooleanSetting("Tung Tung Sahur pet", false);
    /** "cute": a picture in the bottom-left of the ClickGUI (Settings page). */
    public static boolean cute = false;
    public static final NumberSetting cuteScale = new NumberSetting("Scale", 1.0, 0.3, 3.0, 0.05);
    /** Top-left corner of the picture as a fraction of the screen; negative = default bottom-left spot. */
    public static float cuteX = -1f, cuteY = -1f;
    /** Resource pack screen: packs can be dragged between and inside the lists. */
    public static boolean packDraggable = true;
    /** Font of the ClickGUI (one of LumenFont.FACES). The HUD always uses the vanilla font. */
    public static String font = "Winkle";

    /** Hypixel API key used by the Level Head module (set with /lumen apikey). */
    public static String hypixelKey = "";

    /** Voxyl (bedwarspractice.club) API key used by Level Head's Bedwars Practice source (set with /lumen voxylkey). */
    public static String voxylKey = "";

    /** Base URL of the config cloud server (set with /lumen cloud url <url>). */
    public static String cloudUrl = "";

    private ClientSettings() {}

    public static void setFont(String name) {
        for (String f : LumenFont.FACES) {
            if (f.equalsIgnoreCase(name)) {
                font = f;
                LumenFont.setFace(f);
                return;
            }
        }
    }

    public static void cycleFont(int dir) {
        int i = 0;
        for (int k = 0; k < LumenFont.FACES.length; k++) {
            if (LumenFont.FACES[k].equalsIgnoreCase(font)) i = k;
        }
        int n = LumenFont.FACES.length;
        setFont(LumenFont.FACES[(i + dir + n) % n]);
    }
}
