package com.lumen.client.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumberSetting extends Setting {
    public double value;
    public final double min, max, step;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = def;
    }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        if (step > 0) {
            v = Math.round((v - min) / step) * step + min;
        }
        value = Math.max(min, Math.min(max, v));
    }

    public float getFloat() {
        return (float) value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public double fraction() {
        return (value - min) / (max - min);
    }

    public String display() {
        if (step >= 1) return String.valueOf(getInt());
        return String.format(Locale.ROOT, step >= 0.1 ? "%.1f" : "%.2f", value);
    }

    @Override
    public int height() {
        return 20;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(Double.valueOf(value));
    }

    @Override
    public void load(JsonElement e) {
        if (e != null && e.isJsonPrimitive()) {
            set(e.getAsDouble());
        }
    }
}
