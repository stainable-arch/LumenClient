package com.lumen.client;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;

import java.util.Arrays;
import java.util.List;

/** Client-side chat command "/lumen" (alias "/lc") that opens the ClickGUI. */
public class LumenCommand extends CommandBase {
    @Override
    public String getCommandName() {
        return "lumen";
    }

    @Override
    public List<String> getCommandAliases() {
        return Arrays.asList("lc");
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/lumen";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        // the chat screen closes right after a command, so open the GUI on the next tick
        ClientEvents.openGuiRequested = true;
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }
}
