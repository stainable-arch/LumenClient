package com.lumen.client;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.modules.LevelHead;

import net.minecraft.util.BlockPos;

import java.util.Arrays;
import java.util.List;

/** Client-side chat command "/lumen" (alias "/lc") that opens the ClickGUI. */
public class LumenCommand extends CommandBase {
    @Override
    public String getCommandName() {
        return "lumen";
    }

    @Override
    public List<String> getCommandAliases() {
        return Arrays.asList("lc");
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/lumen  (opens the menu)   /lumen key <your key>   /lhelp";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        // simple commands (the older long forms below keep working)
        if (args.length >= 1 && args[0].equalsIgnoreCase("key")) {
            handleKey(sender, args);
            return;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("apikey")) {
            handleApiKey(sender, args);
            return;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("voxylkey")) {
            handleVoxylKey(sender, args);
            return;
        }
        // the chat screen closes right after a command, so open the GUI on the next tick
        ClientEvents.openGuiRequested = true;
    }

    /** The /lhelp text. */
    static void sendHelp(ICommandSender sender) {
        reply(sender, "\u00a7f/lumen\u00a7r  opens the menu");
        reply(sender, "\u00a7f/lumen key <your key>\u00a7r  saves your Level Head key (Hypixel or Bedwars Practice, detected automatically)");
        reply(sender, "\u00a7f/lumen key remove\u00a7r  forgets your saved keys");
    }

    private static void reply(ICommandSender sender, String msg) {
        sender.addChatMessage(new ChatComponentText("\u00a7b[Lumen] \u00a7r" + msg));
    }

    /** /lumen apikey <key> sets the Hypixel API key used by Level Head; "clear" removes it. */
    private static void handleApiKey(ICommandSender sender, String[] args) {
        if (args.length < 2) {
            reply(sender, "Hypixel API key: " + (ClientSettings.hypixelKey.isEmpty() ? "\u00a7cnot set" : "\u00a7aset")
                    + "\u00a7r. Usage: /lumen apikey <key>  (free key at developer.hypixel.net)");
            return;
        }
        String k = args[1].trim();
        if (k.equalsIgnoreCase("clear")) {
            ClientSettings.hypixelKey = "";
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "API key removed.");
        } else if (k.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) {
            ClientSettings.hypixelKey = k;
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "\u00a7aAPI key saved.");
        } else {
            reply(sender, "\u00a7cThat doesn't look like a Hypixel API key (it should look like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).");
        }
    }

    /** /lumen key <key>: a Hypixel key looks like xxxxxxxx-xxxx-..., anything else is taken as a Voxyl key. */
    private static void handleKey(ICommandSender sender, String[] args) {
        if (args.length < 2) {
            reply(sender, "Hypixel key: " + (ClientSettings.hypixelKey.isEmpty() ? "\u00a7cnot set" : "\u00a7aset")
                    + "\u00a7r, Bedwars Practice key: " + (ClientSettings.voxylKey.isEmpty() ? "\u00a7cnot set" : "\u00a7aset")
                    + "\u00a7r. Save one with \u00a7f/lumen key <your key>");
            return;
        }
        String k = args[1].trim();
        if (k.equalsIgnoreCase("remove") || k.equalsIgnoreCase("clear")) {
            ClientSettings.hypixelKey = "";
            ClientSettings.voxylKey = "";
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "Keys removed.");
        } else if (k.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) {
            handleApiKey(sender, new String[] { "apikey", k });
        } else {
            handleVoxylKey(sender, new String[] { "voxylkey", k });
        }
    }

    /** /lumen voxylkey <key> sets the Voxyl (bedwarspractice.club) API key used by Level Head; "clear" removes it. */
    private static void handleVoxylKey(ICommandSender sender, String[] args) {
        if (args.length < 2) {
            reply(sender, "Voxyl API key: " + (ClientSettings.voxylKey.isEmpty() ? "\u00a7cnot set" : "\u00a7aset")
                    + "\u00a7r. Usage: /lumen voxylkey <key>");
            return;
        }
        String k = args[1].trim();
        if (k.equalsIgnoreCase("clear")) {
            ClientSettings.voxylKey = "";
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "Voxyl key removed.");
        } else if (k.matches("[0-9a-zA-Z\\-_]{8,80}")) {
            ClientSettings.voxylKey = k;
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "\u00a7aVoxyl key saved.");
        } else {
            reply(sender, "\u00a7cThat doesn't look like a Voxyl API key.");
        }
    }

    @Override
    public List<String> addTabCompletionOptions(ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) return getListOfStringsMatchingLastWord(args, "key");
        return null;
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }
}
