package com.lumen.client;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.modules.LevelHead;

import java.util.Arrays;
import java.util.List;

/** Client-side chat command "/lumen" (alias "/lc") that opens the ClickGUI. */
public class LumenCommand extends CommandBase {
    @Override
    public String getCommandName() {
        return "lumen";
    }

    @Override
    public List<String> getCommandAliases() {
        return Arrays.asList("lc");
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/lumen [apikey <hypixel key>|apikey clear|cloud|cloud url <address>]";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        if (args.length >= 1 && args[0].equalsIgnoreCase("apikey")) {
            handleApiKey(sender, args);
            return;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("cloud")) {
            handleCloud(sender, args);
            return;
        }
        // the chat screen closes right after a command, so open the GUI on the next tick
        ClientEvents.openGuiRequested = true;
    }

    private static void reply(ICommandSender sender, String msg) {
        sender.addChatMessage(new ChatComponentText("\u00a7b[Lumen] \u00a7r" + msg));
    }

    /** /lumen apikey <key> sets the Hypixel API key used by Level Head; "clear" removes it. */
    private static void handleApiKey(ICommandSender sender, String[] args) {
        if (args.length < 2) {
            reply(sender, "Hypixel API key: " + (ClientSettings.hypixelKey.isEmpty() ? "\u00a7cnot set" : "\u00a7aset")
                    + "\u00a7r. Usage: /lumen apikey <key>  (free key at developer.hypixel.net)");
            return;
        }
        String k = args[1].trim();
        if (k.equalsIgnoreCase("clear")) {
            ClientSettings.hypixelKey = "";
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "API key removed.");
        } else if (k.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) {
            ClientSettings.hypixelKey = k;
            LevelHead.resetCache();
            ConfigManager.save();
            reply(sender, "\u00a7aAPI key saved.");
        } else {
            reply(sender, "\u00a7cThat doesn't look like a Hypixel API key (it should look like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).");
        }
    }

    /** /lumen cloud opens the config cloud; /lumen cloud url <address> sets the server. */
    private static void handleCloud(ICommandSender sender, String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("url")) {
            if (args.length < 3) {
                reply(sender, "Cloud server: " + (ClientSettings.cloudUrl.isEmpty() ? "\u00a7cnot set" : ClientSettings.cloudUrl));
                return;
            }
            String u = args[2].trim();
            if (u.equalsIgnoreCase("clear")) {
                ClientSettings.cloudUrl = "";
            } else if (u.startsWith("http://") || u.startsWith("https://")) {
                ClientSettings.cloudUrl = u;
            } else {
                reply(sender, "\u00a7cThe address must start with http:// or https://");
                return;
            }
            ConfigManager.save();
            reply(sender, "\u00a7aCloud server saved.");
            return;
        }
        ClientEvents.openCloudRequested = true;
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }
}
