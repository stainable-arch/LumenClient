package com.lumen.client.fx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The client's own particle engine. Particles are billboards textured with the procedurally
 * generated SpriteSheet and drawn in RenderWorldLastEvent, so they don't depend on vanilla's
 * particle atlas, resource packs, or OptiFine's particle settings.
 */
public final class ParticleSystem {
    public static final ParticleSystem INSTANCE = new ParticleSystem();

    public static final int HEART = 0, STAR = 1, SPARKLE = 2, BUBBLE = 3;
    private static final int MAX_PARTICLES = 1200;

    public static final class Particle {
        double x, y, z, px, py, pz, vx, vy, vz;
        float size, rot, prevRot, spin, phase;
        float gravity, drag = 0.96f, sway, glow;
        int age, maxAge, sprite, r, g, b;

        public Particle(double x, double y, double z, double vx, double vy, double vz,
                        float size, int maxAge, int sprite, int rgb) {
            this.x = this.px = x;
            this.y = this.py = y;
            this.z = this.pz = z;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.size = size;
            this.maxAge = maxAge;
            this.sprite = sprite;
            this.r = (rgb >> 16) & 255;
            this.g = (rgb >> 8) & 255;
            this.b = rgb & 255;
            this.phase = (float) (Math.random() * Math.PI * 2);
            this.rot = (float) (Math.random() * 40 - 20);
        }

        /** Positive gravity pulls down, negative makes the particle float upwards. */
        public Particle physics(float gravity, float drag, float sway) {
            this.gravity = gravity;
            this.drag = drag;
            this.sway = sway;
            return this;
        }

        /** Glow strength 0..1 (0 = none). */
        public Particle glow(float amount) {
            this.glow = Math.max(0f, Math.min(1f, amount));
            return this;
        }

        public Particle spin(float degreesPerTick) {
            this.spin = degreesPerTick;
            return this;
        }

        void update() {
            px = x;
            py = y;
            pz = z;
            prevRot = rot;
            age++;
            vx *= drag;
            vy *= drag;
            vz *= drag;
            vy -= gravity;
            vx += Math.sin(age * 0.35 + phase) * sway;
            vz += Math.cos(age * 0.31 + phase) * sway;
            x += vx;
            y += vy;
            z += vz;
            rot += spin;
        }
    }

    private final List<Particle> particles = new ArrayList<Particle>();
    private ResourceLocation texture;
    private boolean textureFailed;

    private ParticleSystem() {}

    public void spawn(Particle p) {
        if (particles.size() < MAX_PARTICLES) {
            particles.add(p);
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || particles.isEmpty()) return;
        if (Minecraft.getMinecraft().theWorld == null) {
            particles.clear();
            return;
        }
        for (Iterator<Particle> it = particles.iterator(); it.hasNext(); ) {
            Particle p = it.next();
            p.update();
            if (p.age >= p.maxAge) it.remove();
        }
    }

    private boolean ensureTexture(Minecraft mc) {
        if (texture != null) return true;
        if (textureFailed) return false;
        try {
            DynamicTexture dt = new DynamicTexture(SpriteSheet.generate());
            texture = mc.getTextureManager().getDynamicTextureLocation("lumenclient_particles", dt);
            GlStateManager.bindTexture(dt.getGlTextureId());
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            return true;
        } catch (Throwable t) {
            textureFailed = true;
            t.printStackTrace();
            return false;
        }
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent e) {
        if (particles.isEmpty()) return;
        Minecraft mc = Minecraft.getMinecraft();
        Entity view = mc.getRenderViewEntity();
        if (view == null || !ensureTexture(mc)) return;

        float pt = e.partialTicks;
        double cx = view.lastTickPosX + (view.posX - view.lastTickPosX) * pt;
        double cy = view.lastTickPosY + (view.posY - view.lastTickPosY) * pt;
        double cz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * pt;

        RenderManager rm = mc.getRenderManager();
        float yaw = rm.playerViewY;
        float pitch = rm.playerViewX * (mc.gameSettings.thirdPersonView == 2 ? -1f : 1f);

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.003921569F);
        GlStateManager.depthMask(false);
        mc.getTextureManager().bindTexture(texture);

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();

        for (Particle p : particles) {
            float life = p.age + pt;
            float pop = Math.min(1f, life / 4f);
            float grow = 1f + 2.2f * (float) Math.pow(pop - 1f, 3) + 1.2f * (float) Math.pow(pop - 1f, 2); // ease-out-back
            float fade = Math.max(0f, Math.min(1f, (p.maxAge - life) / 10f));
            float s = p.size * grow * (0.55f + 0.45f * fade);
            if (p.sprite == SPARKLE) {
                s *= 0.82f + 0.18f * (float) Math.sin(life * 0.9f + p.phase);
            }
            int alpha = (int) (255 * fade);
            if (alpha < 3 || s <= 0f) continue;

            double ix = p.px + (p.x - p.px) * pt - cx;
            double iy = p.py + (p.y - p.py) * pt - cy;
            double iz = p.pz + (p.z - p.pz) * pt - cz;
            float rot = p.prevRot + (p.rot - p.prevRot) * pt;

            // cells are twice as wide as the shape they hold (the extra room is for the glow)
            float q = s * 2f;

            GlStateManager.pushMatrix();
            GlStateManager.translate(ix, iy, iz);
            GlStateManager.rotate(-yaw, 0f, 1f, 0f);
            GlStateManager.rotate(pitch, 1f, 0f, 0f);
            GlStateManager.rotate(rot, 0f, 0f, 1f);

            if (p.glow > 0f) {
                // additive glow: a tight halo plus a wide one, brighter and bigger with a higher setting
                GlStateManager.blendFunc(770, 1);
                float g = p.glow;
                quad(tess, wr, p.sprite + SpriteSheet.GLOW_OFFSET, q * (1.05f + 0.35f * g), p, Math.min(255, (int) (alpha * (0.10f + 0.50f * g))));
                quad(tess, wr, p.sprite + SpriteSheet.GLOW_OFFSET, q * (1.2f + 0.6f * g), p, Math.min(255, (int) (alpha * (0.05f + 0.30f * g))));
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            }
            quad(tess, wr, p.sprite, q, p, alpha);
            GlStateManager.popMatrix();
        }

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.alphaFunc(516, 0.1F);
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    /** One camera-facing textured square (cell `cell` of the sprite sheet), half-size h, centred on the origin. */
    private static void quad(Tessellator tess, WorldRenderer wr, int cell, float h, Particle p, int alpha) {
        float u0 = cell / (float) SpriteSheet.COUNT;
        float u1 = (cell + 1) / (float) SpriteSheet.COUNT;
        wr.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
        // local +x points to the screen's left (same convention as vanilla name tags), so u is mirrored
        wr.pos(h, h, 0).tex(u0, 0).color(p.r, p.g, p.b, alpha).endVertex();
        wr.pos(-h, h, 0).tex(u1, 0).color(p.r, p.g, p.b, alpha).endVertex();
        wr.pos(-h, -h, 0).tex(u1, 1).color(p.r, p.g, p.b, alpha).endVertex();
        wr.pos(h, -h, 0).tex(u0, 1).color(p.r, p.g, p.b, alpha).endVertex();
        tess.draw();
    }
}
