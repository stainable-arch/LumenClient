package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;

/**
 * Shared drawing for the "Liquid Glass" theme: a drifting glow backdrop and frosted panes.
 * Only plain smooth-shaded triangles/quads and alpha blending, so it also runs on GL wrappers.
 */
public final class GlassFx {
    private GlassFx() {}

    public static boolean on() {
        return Theme.current().glass;
    }

    /**
     * Dark neutral veil (no drifting blobs).
     * {@code solid} = fully opaque base (title screen); otherwise the world still shows through.
     */
    public static void backdrop(int w, int h, float alpha, long now, boolean solid) {
        backdrop(w, h, alpha, now, solid, 0f, 0f);
    }

    /** Same, with the glows shifted by (ox, oy) pixels (used for mouse parallax). */
    public static void backdrop(int w, int h, float alpha, long now, boolean solid, float ox, float oy) {
        int topA = solid ? 255 : 105, botA = solid ? 255 : 135;
        RenderUtil.gradientV(0, 0, w, h, Colors.mulAlpha(Colors.withAlpha(0x0E0F13, topA), alpha),
                Colors.mulAlpha(Colors.withAlpha(0x1A1C23, botA), alpha));
    }

    /**
     * Soft drifting colour glows in the theme colours, for the classic (non-glass) themes: gives the
     * dark backgrounds some depth without a veil. {@code strength} 1 = default.
     */
    public static void ambient(int w, int h, float strength, long now) {
        ambient(w, h, strength, now, 0f, 0f);
    }

    public static void ambient(int w, int h, float strength, long now, float ox, float oy) {
        Theme th = Theme.current();
        float t = (now % 50000L) / 50000f * (float) Math.PI * 2f;
        float r = Math.max(w, h) * 0.5f;
        RenderUtil.glow(ox + w * (0.2f + 0.1f * (float) Math.sin(t)), oy + h * (0.25f + 0.08f * (float) Math.cos(t * 2f)), r,
                Colors.withAlpha(th.c1, (int) (34 * strength)));
        RenderUtil.glow(ox * 1.5f + w * (0.82f + 0.08f * (float) Math.cos(t * 1.5f)), oy * 1.5f + h * (0.8f + 0.08f * (float) Math.sin(t)), r * 0.9f,
                Colors.withAlpha(th.c3, (int) (32 * strength)));
    }

    /** A frosted pane. {@code lit} (0..1) = hover / enabled / selected: brighter fill, tinted and stronger rim. */
    public static void pane(float x, float y, float x2, float y2, float radius, float alpha, float lit) {
        Theme th = Theme.current();
        int c1 = Colors.opaque(th.c1);
        int fill = Colors.lerp(Colors.withAlpha(0xF4F6FA, 11), Colors.withAlpha(0xFFFFFF, 40), lit);
        RenderUtil.glassPanel(x, y, x2, y2, radius,
                Colors.mulAlpha(fill, alpha), (int) (alpha * (16 + 22 * lit)),
                Colors.mulAlpha(Colors.withAlpha(0xFFFFFF, (int) (90 + 80 * lit)), alpha),
                Colors.mulAlpha(Colors.withAlpha(Colors.lerp(0xFFFFFFFF, c1, 0.6f), (int) (18 + 50 * lit)), alpha));
    }
}
