package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;

/**
 * Shared drawing for the "Liquid Glass" theme: a drifting glow backdrop and frosted panes.
 * Only plain smooth-shaded triangles/quads and alpha blending, so it also runs on GL wrappers.
 */
public final class GlassFx {
    private GlassFx() {}

    public static boolean on() {
        return Theme.current().glass;
    }

    /**
     * Dark neutral veil (no drifting blobs).
     * {@code solid} = fully opaque base (title screen); otherwise the world still shows through.
     */
    public static void backdrop(int w, int h, float alpha, long now, boolean solid) {
        backdrop(w, h, alpha, now, solid, 0f, 0f);
    }

    /** Same, with the glows shifted by (ox, oy) pixels (used for mouse parallax). */
    public static void backdrop(int w, int h, float alpha, long now, boolean solid, float ox, float oy) {
        int topA = solid ? 255 : 88, botA = solid ? 255 : 122;
        RenderUtil.gradientV(0, 0, w, h, Colors.mulAlpha(Colors.withAlpha(0x0E0F13, topA), alpha),
                Colors.mulAlpha(Colors.withAlpha(0x1A1C23, botA), alpha));
        if (solid) {
            // faint, slow colour glows: glass is only visible when there is something coloured behind it
            float t = (now % 60000L) / 60000f * (float) Math.PI * 2f;
            float r = Math.max(w, h) * 0.55f;
            RenderUtil.glow(ox + w * (0.25f + 0.06f * (float) Math.sin(t)), oy + h * (0.3f + 0.05f * (float) Math.cos(t)), r,
                    Colors.mulAlpha(Colors.withAlpha(0x5C7CFF, 34), alpha));
            RenderUtil.glow(ox * 1.5f + w * (0.78f + 0.05f * (float) Math.cos(t * 1.3f)), oy * 1.5f + h * (0.75f + 0.05f * (float) Math.sin(t)), r * 0.85f,
                    Colors.mulAlpha(Colors.withAlpha(0xFF8CB8, 26), alpha));
        }
    }

    /**
     * Soft drifting colour glows in the theme colours, for the classic (non-glass) themes: gives the
     * dark backgrounds some depth without a veil. {@code strength} 1 = default.
     */
    public static void ambient(int w, int h, float strength, long now) {
        ambient(w, h, strength, now, 0f, 0f);
    }

    public static void ambient(int w, int h, float strength, long now, float ox, float oy) {
        Theme th = Theme.current();
        float t = (now % 50000L) / 50000f * (float) Math.PI * 2f;
        float r = Math.max(w, h) * 0.55f;
        RenderUtil.glow(ox + w * (0.2f + 0.1f * (float) Math.sin(t)), oy + h * (0.25f + 0.08f * (float) Math.cos(t * 2f)), r,
                Colors.withAlpha(th.c1, (int) (40 * strength)));
        RenderUtil.glow(ox * 1.5f + w * (0.82f + 0.08f * (float) Math.cos(t * 1.5f)), oy * 1.5f + h * (0.8f + 0.08f * (float) Math.sin(t)), r * 0.95f,
                Colors.withAlpha(th.c3, (int) (38 * strength)));
        // a third, slower glow in the middle accent colour so the backdrop never looks like a two-blob gradient
        RenderUtil.glow(ox * 1.2f + w * (0.55f + 0.12f * (float) Math.sin(t * 0.5f + 1f)), oy * 1.2f + h * (0.5f + 0.1f * (float) Math.cos(t * 0.5f)), r * 0.7f,
                Colors.withAlpha(th.c2, (int) (22 * strength)));
    }

    /**
     * Panel for the coloured themes (see {@link RenderUtil#themedPanel}). {@code base} is the body colour (ARGB):
     * the top gets lighter and the bottom darker from it. {@code lit} (0..1) = hover / enabled; {@code alpha} = fade.
     */
    public static void classicPane(float x, float y, float x2, float y2, float radius, int base, int rim1, int rim2,
                                   float lit, float alpha) {
        int a0 = (base >>> 24) & 255;
        int top = Colors.withAlpha(Colors.lerp(base, 0xFFFFFFFF, 0.07f + 0.05f * lit), a0);
        int bot = Colors.withAlpha(Colors.lerp(base, 0xFF000000, 0.28f), a0);
        RenderUtil.themedPanel(x, y, x2, y2, radius, top, bot, rim1 & 0xFFFFFF, rim2 & 0xFFFFFF, lit, alpha);
    }

    /** Soft shadow for the coloured themes: like {@link #shadow} but faintly tinted with the accent colour. */
    public static void classicShadow(float x, float y, float x2, float y2, float radius, int accentRgb, float alpha) {
        int tint = Colors.lerp(0xFF000000, Colors.opaque(accentRgb), 0.16f) & 0xFFFFFF;
        for (int i = 0; i < 5; i++) {
            float t = i / 4f, k = (1f - t) * (1f - t);
            float grow = 1.5f + t * 12f, dy = 2f + t * 6f;
            RenderUtil.roundedRect(x - grow, y - grow + dy, x2 + grow, y2 + grow + dy, radius + grow,
                    Colors.mulAlpha(Colors.withAlpha(tint, 6 + (int) (26 * k)), alpha));
        }
    }

    /**
     * A Liquid Glass pane. {@code lit} (0..1) = hover / enabled / selected: the body fills with more light and the
     * specular rim and inner glow get stronger, like an iOS glass control being pressed. Corners are rounder than
     * the radius passed in (capsule-like), capped at half the pane's height.
     */
    public static void pane(float x, float y, float x2, float y2, float radius, float alpha, float lit) {
        pane(x, y, x2, y2, radius, alpha, lit, -0.7071f, -0.7071f);
    }

    /** Same, with the light coming from direction (lx, ly) instead of the top-left. */
    public static void pane(float x, float y, float x2, float y2, float radius, float alpha, float lit, float lx, float ly) {
        float rr = Math.min(radius * 1.4f, Math.min(x2 - x, y2 - y) / 2f);
        int fill = Colors.lerp(Colors.withAlpha(0xF4F6FA, 13), Colors.withAlpha(0xFFFFFF, 42), lit);
        RenderUtil.glassPanel(x, y, x2, y2, rr,
                Colors.mulAlpha(fill, alpha),
                (int) (alpha * (10 + 16 * lit)),
                (int) (alpha * (205 + 50 * lit)),
                (int) (alpha * (26 + 36 * lit)),
                lx, ly);
    }

    /** Soft, diffuse drop shadow under a floating glass window: stacked translucent shapes with a quadratic falloff. */
    public static void shadow(float x, float y, float x2, float y2, float radius, float alpha) {
        for (int i = 0; i < 5; i++) {
            float t = i / 4f, k = (1f - t) * (1f - t);
            float grow = 1.5f + t * 15f, dy = 2f + t * 8f;
            RenderUtil.roundedRect(x - grow, y - grow + dy, x2 + grow, y2 + grow + dy, radius + grow,
                    Colors.mulAlpha(Colors.withAlpha(0x000000, 3 + (int) (13 * k)), alpha));
        }
    }
}
