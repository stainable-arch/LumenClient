package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.LumenClient;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ColorSetting;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.core.Setting;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * ClickGUI "v4": one frosted column per category (HUD, Combat, Visuals and a Settings column) with a search
 * pill underneath. Layout based on the "Minecraft Hack GUI" Figma community file; only Lumen's own modules and
 * settings are listed.
 *
 * Left click a row = on/off (rows without a switch open their options instead), right click = open its options.
 * Mouse wheel over a column scrolls it.
 */
public class ClickGuiV4 extends GuiScreen {
    // layout (GUI units at ui = 1)
    private static final float PW = 105f, GAP = 8f, HEAD_H = 31f, SECT_GAP = 6f, PAD = 6f;
    private static final float ROW_H = 17.5f, ROW_GAP = 4f, SET_PAD_X = 6f, SET_PAD_Y = 5f, SET_GAP = 4f;
    private static final float BIND_H = 7f, OPT_H = 6.5f;
    private static final float T_NAME = 0.62f, T_OPT = 0.52f, T_HEAD = 0.7f;
    private static final float SEARCH_W = 109f, SEARCH_H = 21f;

    private static final int HIT_SEARCH = 0, HIT_ENTRY = 1, HIT_BOOL = 2, HIT_MODE = 3, HIT_NUM = 4, HIT_COLOR = 5, HIT_BIND = 6;

    private static final int BG = 0xE0181818;      // module / pill background (88 %)
    private static final int PANEL = 0xD0181818;   // column background (72 %)
    private static final int W04 = 0x0AFFFFFF, W12 = 0x1FFFFFFF, W24 = 0x3DFFFFFF, W36 = 0x5CFFFFFF, W48 = 0x7AFFFFFF;

    /** Expanded state of the Settings column rows (module rows use Module.expanded). */
    private static final Map<String, Boolean> EXPANDED = new HashMap<String, Boolean>();

    private static final class Entry {
        final Module mod;
        final String name;
        java.util.function.BooleanSupplier on;
        Runnable toggle;
        Runnable action;
        boolean bindable;
        final List<Setting> settings = new ArrayList<Setting>();
        float toggleAnim, expandAnim;

        Entry(Module mod, String name) {
            this.mod = mod;
            this.name = name;
        }

        boolean isOn() {
            return on != null && on.getAsBoolean();
        }

        boolean expanded() {
            if (mod != null) return mod.expanded;
            Boolean b = EXPANDED.get(name);
            return b != null && b.booleanValue();
        }

        void setExpanded(boolean v) {
            if (mod != null) mod.expanded = v;
            else EXPANDED.put(name, Boolean.valueOf(v));
        }

        boolean expandable() {
            return !settings.isEmpty() || bindable;
        }
    }

    private static final class Hit {
        final int type;
        final float x, y, w, h;
        final float clipY1, clipY2;
        Entry entry;
        Setting setting;
        int arg;

        Hit(int type, float x, float y, float w, float h, float clipY1, float clipY2) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.clipY1 = clipY1;
            this.clipY2 = clipY2;
        }

        boolean contains(float mx, float my) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h && my >= clipY1 && my <= clipY2;
        }
    }

    private final List<Hit> hits = new ArrayList<Hit>();
    private final List<String> titles = new ArrayList<String>();
    private final List<List<Entry>> columns = new ArrayList<List<Entry>>();
    private float[] scroll, targetScroll, contentH;
    private ModeSetting themeMode;

    private float ui = 1f, vW, vH;
    private float x0, y0, panelH;
    private float clipTop = -1e9f, clipBottom = 1e9f;

    private float fade, e;
    private boolean closing;
    private long lastFrame = System.currentTimeMillis();

    private Setting dragging;
    private float dragX, dragW;
    private int dragChannel;
    private Module binding;
    private boolean searchFocused;
    private String search = "";

    // ------------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------------

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
        buildColumns();
    }

    @Override
    public void onGuiClosed() {
        ConfigManager.save();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void updateScreen() {
        if (closing && fade <= 0.001f) {
            mc.displayGuiScreen(null);
        }
    }

    private void beginClose() {
        if (!closing) {
            closing = true;
            Sounds.close();
        }
    }

    private void buildColumns() {
        titles.clear();
        columns.clear();
        for (Category c : Category.values()) {
            List<Entry> list = new ArrayList<Entry>();
            for (final Module m : ModuleManager.byCategory(c)) {
                Entry en = new Entry(m, m.name);
                en.on = new java.util.function.BooleanSupplier() {
                    @Override
                    public boolean getAsBoolean() {
                        return m.isEnabled();
                    }
                };
                en.toggle = new Runnable() {
                    @Override
                    public void run() {
                        m.toggle();
                    }
                };
                en.bindable = true;
                en.settings.addAll(m.settings);
                list.add(en);
            }
            titles.add(c.label);
            columns.add(list);
        }

        // Settings column
        List<Entry> st = new ArrayList<Entry>();
        Entry gui = new Entry(null, "Gui");
        gui.settings.add(ClientSettings.gui);
        st.add(gui);

        String[] names = new String[Theme.ALL.size()];
        for (int i = 0; i < names.length; i++) names[i] = Theme.ALL.get(i).name;
        themeMode = new ModeSetting("Theme", Theme.current().name, names);
        Entry theme = new Entry(null, "Theme");
        theme.settings.add(themeMode);
        st.add(theme);

        Entry sounds = new Entry(null, "Sounds");
        sounds.on = new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return ClientSettings.sounds;
            }
        };
        sounds.toggle = new Runnable() {
            @Override
            public void run() {
                ClientSettings.sounds = !ClientSettings.sounds;
            }
        };
        st.add(sounds);

        Entry cosm = new Entry(null, "Cosmetics");
        cosm.on = new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return ClientSettings.cosmetics;
            }
        };
        cosm.toggle = new Runnable() {
            @Override
            public void run() {
                ClientSettings.cosmetics = !ClientSettings.cosmetics;
            }
        };
        cosm.settings.add(ClientSettings.cape);
        cosm.settings.add(ClientSettings.sahurPet);
        st.add(cosm);

        Entry cute = new Entry(null, "Cute");
        cute.on = new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return ClientSettings.cute;
            }
        };
        cute.toggle = new Runnable() {
            @Override
            public void run() {
                ClientSettings.cute = !ClientSettings.cute;
            }
        };
        cute.settings.add(ClientSettings.cuteScale);
        st.add(cute);

        Entry packs = new Entry(null, "Draggable Packs");
        packs.on = new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return ClientSettings.packDraggable;
            }
        };
        packs.toggle = new Runnable() {
            @Override
            public void run() {
                ClientSettings.packDraggable = !ClientSettings.packDraggable;
            }
        };
        st.add(packs);

        Entry opts = new Entry(null, "Options");
        opts.settings.addAll(ClientSettings.OPTIONS);
        st.add(opts);

        Entry hud = new Entry(null, "HUD Editor");
        hud.action = new Runnable() {
            @Override
            public void run() {
                if (mc.theWorld != null) mc.displayGuiScreen(new HudEditor());
            }
        };
        st.add(hud);

        titles.add("Settings");
        columns.add(st);

        int n = columns.size();
        scroll = new float[n];
        targetScroll = new float[n];
        contentH = new float[n];
        for (List<Entry> col : columns) {
            for (Entry en : col) {
                en.toggleAnim = en.isOn() ? 1f : 0f;
                en.expandAnim = en.expanded() ? 1f : 0f;
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------------------------------

    private int fa(int color) {
        return Colors.mulAlpha(color, e);
    }

    private static float ease(float dt, float rate) {
        return 1f - (float) Math.exp(-dt * rate);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, false);
        GlStateManager.popMatrix();
    }

    private static float textW(String s, float scale) {
        return LumenFont.width(s) * scale;
    }

    /** Draws {@code s} vertically centred inside a row starting at y with height h. */
    private static void textMid(String s, float x, float y, float h, float scale, int color) {
        text(s, x, y + (h - LumenFont.EM * scale) / 2f, scale, color);
    }

    private Hit addHit(int type, float x, float y, float w, float h) {
        Hit hit = new Hit(type, x, y, w, h, clipTop, clipBottom);
        hits.add(hit);
        return hit;
    }

    private void scissorUi(float x, float y, float w, float h) {
        RenderUtil.scissor(x * ui, y * ui, Math.max(0f, w) * ui, Math.max(0f, h) * ui);
    }

    private List<Entry> visibleEntries(int col) {
        String q = search.trim().toLowerCase(Locale.ROOT);
        List<Entry> src = columns.get(col);
        if (q.length() == 0) return src;
        List<Entry> out = new ArrayList<Entry>();
        for (Entry en : src) {
            if (en.name.toLowerCase(Locale.ROOT).contains(q)) out.add(en);
        }
        return out;
    }

    private static float rowH(Setting s) {
        if (s instanceof BooleanSetting) return 7f;
        if (s instanceof NumberSetting) return 12f;
        if (s instanceof ModeSetting) return 8f + ((ModeSetting) s).modes.length * OPT_H;
        if (s instanceof ColorSetting) return 8f + 3f * 7f;
        return s.height() * 0.5f;
    }

    private static float settingsBlockH(Entry en) {
        float total = 0f;
        int n = 0;
        for (Setting s : en.settings) {
            if (s.visAnim > 0.01f) {
                total += rowH(s) * s.visAnim;
                n++;
            }
        }
        if (en.bindable) {
            total += BIND_H;
            n++;
        }
        if (n == 0) return 0f;
        return total + (n - 1) * SET_GAP + SET_PAD_Y * 2f;
    }

    private static float entryHeight(Entry en) {
        return ROW_H + settingsBlockH(en) * en.expandAnim;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = closing ? Math.max(0f, fade - dt * 6f) : Math.min(1f, fade + dt * 4.5f);
        e = 1f - (float) Math.pow(1f - fade, 3);

        hits.clear();
        clipTop = -1e9f;
        clipBottom = 1e9f;

        int cols = columns.size();
        ui = Math.max(0.65f, Math.min(1.6f, width / 468f));
        vW = width / ui;
        vH = height / ui;
        final float mx = mouseX / ui, my = mouseY / ui;

        panelH = Math.max(120f, Math.min(277f, vH - 120f));
        float total = cols * PW + (cols - 1) * GAP;
        x0 = (vW - total) / 2f;
        y0 = (vH - panelH) / 2f - 10f + (1f - e) * 8f;

        // animations
        float step = ease(dt, 14f);
        themeMode.index = Theme.index();
        for (List<Entry> col : columns) {
            for (Entry en : col) {
                en.toggleAnim += ((en.isOn() ? 1f : 0f) - en.toggleAnim) * step;
                en.expandAnim += ((en.expanded() ? 1f : 0f) - en.expandAnim) * step;
                for (Setting s : en.settings) {
                    float t = s.visible() ? 1f : 0f;
                    s.visAnim += (t - s.visAnim) * step;
                    if (Math.abs(t - s.visAnim) < 0.01f) s.visAnim = t;
                    if (s instanceof BooleanSetting) {
                        s.anim += ((((BooleanSetting) s).value ? 1f : 0f) - s.anim) * step;
                    }
                }
            }
        }
        updateDragging(mx, my);

        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (mc.theWorld == null) {
            GlassFx.backdrop(width, height, e, now, false);
        }
        RenderUtil.rect(0, 0, width, height, fa(0x52000000));

        GlStateManager.pushMatrix();
        GlStateManager.scale(ui, ui, 1f);
        for (int c = 0; c < cols; c++) {
            drawColumn(c, x0 + c * (PW + GAP), mx, my, dt);
        }
        drawSearch(mx, my);
        GlStateManager.popMatrix();

        RenderUtil.endScissor();
        GlStateManager.enableBlend();
    }

    private void drawColumn(int c, float px, float mx, float my, float dt) {
        // category button
        RenderUtil.roundedRect(px, y0, px + PW, y0 + HEAD_H, 10f, fa(PANEL));
        RenderUtil.roundedOutline(px, y0, px + PW, y0 + HEAD_H, 10f, 0.5f, fa(W04), fa(W04));
        float bx = px + PAD, by = y0 + PAD, bw = PW - 2f * PAD, bh = HEAD_H - 2f * PAD;
        RenderUtil.roundedRect(bx, by, bx + bw, by + bh, 5f, fa(BG));
        RenderUtil.roundedRect(bx, by, bx + bw, by + bh, 5f, fa(0x14FFFFFF));
        RenderUtil.roundedOutline(bx, by, bx + bw, by + bh, 5f, 0.4f, fa(0xFFFFFFFF), fa(0xFFFFFFFF));
        String title = titles.get(c);
        float tw = textW(title, T_HEAD);
        float startX = bx + (bw - (7f + 4f + tw)) / 2f;
        float iy = by + (bh - 7f) / 2f;
        for (int i = 0; i < 4; i++) {
            float ix = startX + (i % 2) * 4f, iyy = iy + (i / 2) * 4f;
            RenderUtil.roundedRect(ix, iyy, ix + 3f, iyy + 3f, 0.8f, fa(0xFFFFFFFF));
        }
        textMid(title, startX + 11f, by, bh, T_HEAD, fa(0xFFFFFFFF));

        // module list
        float bodyY = y0 + HEAD_H + SECT_GAP;
        float bodyH = panelH - HEAD_H - SECT_GAP;
        RenderUtil.roundedRect(px, bodyY, px + PW, bodyY + bodyH, 10f, fa(PANEL));
        RenderUtil.roundedOutline(px, bodyY, px + PW, bodyY + bodyH, 10f, 0.5f, fa(W04), fa(W04));

        targetScroll[c] = Math.max(0f, Math.min(Math.max(0f, contentH[c] - bodyH), targetScroll[c]));
        scroll[c] += (targetScroll[c] - scroll[c]) * ease(dt, 12f);
        if (Math.abs(targetScroll[c] - scroll[c]) < 0.05f) scroll[c] = targetScroll[c];

        clipTop = bodyY;
        clipBottom = bodyY + bodyH;
        scissorUi(px, bodyY, PW, bodyH);

        List<Entry> list = visibleEntries(c);
        float startY = bodyY + PAD - scroll[c];
        float y = startY;
        for (Entry en : list) {
            float h = entryHeight(en);
            if (y + h > bodyY && y < bodyY + bodyH) {
                drawEntry(en, px + PAD, y, PW - 2f * PAD, h, mx, my, bodyY, bodyH, px);
            }
            y += h + ROW_GAP;
        }
        contentH[c] = (y - startY) + (list.isEmpty() ? 0f : -ROW_GAP) + 2f * PAD;

        RenderUtil.endScissor();
        clipTop = -1e9f;
        clipBottom = 1e9f;
    }

    private void drawEntry(Entry en, float rx, float ry, float rw, float h, float mx, float my,
                           float bodyY, float bodyH, float colX) {
        float ta = en.toggleAnim;
        boolean hover = mx >= rx && mx <= rx + rw && my >= ry && my <= ry + ROW_H && my >= bodyY && my <= bodyY + bodyH;
        float r = 5f;

        RenderUtil.roundedRect(rx, ry, rx + rw, ry + h, r, fa(BG));
        int over = (int) (10f * ta + (hover ? 9f : 0f));
        if (over > 0) RenderUtil.roundedRect(rx, ry, rx + rw, ry + h, r, fa(Colors.withAlpha(0xFFFFFF, over)));
        int border = Colors.withAlpha(0xFFFFFF, (int) (10f + 245f * ta));
        RenderUtil.roundedOutline(rx, ry, rx + rw, ry + h, r, 0.4f, fa(border), fa(border));
        if (ta > 0.02f) {
            // faint inner glow
            RenderUtil.roundedOutline(rx + 0.8f, ry + 0.8f, rx + rw - 0.8f, ry + h - 0.8f, r - 0.8f, 1.2f,
                    fa(Colors.withAlpha(0xFFFFFF, (int) (20f * ta))), fa(Colors.withAlpha(0xFFFFFF, (int) (20f * ta))));
        }

        int nameCol = Colors.lerp(W48, 0xFFFFFFFF, ta);
        if (en.toggle == null) nameCol = Colors.lerp(W48, 0xFFFFFFFF, Math.max(en.expandAnim, hover ? 0.6f : 0f));
        nameCol = fa(nameCol);

        // grip dots
        float dx = rx + 6f, dy = ry + (ROW_H - 5f) / 2f;
        for (int i = 0; i < 6; i++) {
            float cx = dx + (i % 2) * 2.2f, cy = dy + (i / 2) * 2.2f;
            RenderUtil.rect(cx, cy, cx + 0.9f, cy + 0.9f, nameCol);
        }
        textMid(en.name, rx + 6f + 5f + 2f, ry, ROW_H, T_NAME, nameCol);

        // switch or arrow
        if (en.toggle != null) {
            float tx = rx + rw - 6f - 10f, ty = ry + (ROW_H - 6f) / 2f;
            RenderUtil.roundedRect(tx, ty, tx + 10f, ty + 6f, 3f, fa(Colors.lerp(W12, W36, ta)));
            float kx = tx + 1f + 4f * ta;
            RenderUtil.roundedRect(kx, ty + 1f, kx + 4f, ty + 5f, 2f, fa(Colors.lerp(W24, 0xFFFFFFFF, ta)));
        } else if (en.expandable()) {
            RenderUtil.triangle(rx + rw - 8f, ry + ROW_H / 2f, 2f, 90f * en.expandAnim, fa(Colors.lerp(W36, 0xFFFFFFFF, en.expandAnim)));
        }
        addHit(HIT_ENTRY, rx, ry, rw, ROW_H).entry = en;

        // options
        if (en.expandAnim > 0.01f && h > ROW_H + 0.5f) {
            float y1 = Math.max(ry + ROW_H, bodyY), y2 = Math.min(ry + h, bodyY + bodyH);
            if (y2 > y1) {
                scissorUi(colX, y1, PW, y2 - y1);
                boolean interactive = en.expandAnim > 0.9f && !closing;
                float a = en.expandAnim;
                float sy = ry + ROW_H + SET_PAD_Y;
                float sx = rx + SET_PAD_X, sw = rw - 2f * SET_PAD_X;
                for (Setting s : en.settings) {
                    if (s.visAnim <= 0.01f) continue;
                    drawSetting(en, s, sx, sy, sw, a * s.visAnim, interactive);
                    sy += rowH(s) * s.visAnim + SET_GAP;
                }
                if (en.bindable) {
                    drawBind(en, sx, sy, sw, a, interactive);
                }
                scissorUi(colX, bodyY, PW, bodyH);
            }
        }
    }

    private void drawSetting(Entry en, Setting s, float x, float y, float w, float a, boolean interactive) {
        int hi = Colors.mulAlpha(0xFFFFFFFF, a);
        int lo = Colors.mulAlpha(W48, a);
        int dim = Colors.mulAlpha(W36, a);
        if (s instanceof BooleanSetting) {
            BooleanSetting b = (BooleanSetting) s;
            float an = s.anim;
            textMid(s.name, x, y, 7f, T_NAME, fa(Colors.lerp(lo, hi, an)));
            float cx = x + w - 6f, cy = y + 0.5f;
            RenderUtil.roundedRect(cx, cy, cx + 6f, cy + 6f, 2f, fa(Colors.mulAlpha(Colors.lerp(0x08FFFFFF, W36, an), a)));
            if (an > 0.05f) {
                RenderUtil.roundedRect(cx + 1.7f, cy + 1.7f, cx + 4.3f, cy + 4.3f, 0.8f, fa(Colors.mulAlpha(0xFFFFFFFF, a * an)));
            }
            if (interactive) {
                Hit hit = addHit(HIT_BOOL, x, y, w, 7f);
                hit.setting = b;
            }
        } else if (s instanceof NumberSetting) {
            NumberSetting n = (NumberSetting) s;
            textMid(s.name, x, y, 6f, T_NAME, fa(hi));
            String v = n.display();
            textMid(v, x + w - textW(v, T_NAME), y, 6f, T_NAME, fa(dim));
            float ty = y + 8f;
            float f = (float) Math.max(0.0, Math.min(1.0, n.fraction()));
            RenderUtil.roundedRect(x, ty, x + w, ty + 2f, 1f, fa(Colors.mulAlpha(W12, a)));
            RenderUtil.roundedRect(x, ty, x + Math.max(2f, w * f), ty + 2f, 1f, fa(Colors.mulAlpha(W36, a)));
            RenderUtil.circle(x + Math.max(1.5f, Math.min(w - 1.5f, w * f)), ty + 1f, 1.7f, fa(hi));
            if (interactive) {
                Hit hit = addHit(HIT_NUM, x, y, w, 12f);
                hit.setting = n;
            }
        } else if (s instanceof ModeSetting) {
            ModeSetting m = (ModeSetting) s;
            textMid(s.name, x, y, 6f, T_NAME, fa(lo));
            String v = m.get();
            textMid(v, x + w - textW(v, T_NAME), y, 6f, T_NAME, fa(Colors.mulAlpha(W24, a)));
            float oy = y + 8f;
            for (int i = 0; i < m.modes.length; i++) {
                boolean sel = m.index == i;
                textMid(m.modes[i], x, oy, OPT_H, T_OPT, fa(sel ? hi : dim));
                float rcx = x + w - 2.5f, rcy = oy + OPT_H / 2f;
                if (sel) {
                    RenderUtil.circle(rcx, rcy, 2.5f, fa(Colors.mulAlpha(W12, a)));
                    RenderUtil.circle(rcx, rcy, 1f, fa(hi));
                } else {
                    RenderUtil.circle(rcx, rcy, 2.5f, fa(Colors.mulAlpha(0x0AFFFFFF, a)));
                }
                if (interactive) {
                    Hit hit = addHit(HIT_MODE, x, oy, w, OPT_H);
                    hit.setting = m;
                    hit.arg = i;
                }
                oy += OPT_H;
            }
        } else if (s instanceof ColorSetting) {
            ColorSetting cs = (ColorSetting) s;
            textMid(s.name, x, y, 6f, T_NAME, fa(hi));
            RenderUtil.roundedRect(x + w - 10f, y + 1f, x + w, y + 5f, 1.5f, fa(Colors.mulAlpha(Colors.opaque(cs.rgb()), a)));
            float[] vals = { cs.hue, cs.sat, cs.val };
            String[] labels = { "H", "S", "B" };
            for (int ch = 0; ch < 3; ch++) {
                float ty = y + 8f + ch * 7f;
                textMid(labels[ch], x, ty, 4f, T_OPT, fa(dim));
                float tx = x + 7f, tw = w - 7f;
                float f = Math.max(0f, Math.min(1f, vals[ch]));
                RenderUtil.roundedRect(tx, ty + 1f, tx + tw, ty + 3f, 1f, fa(Colors.mulAlpha(W12, a)));
                RenderUtil.roundedRect(tx, ty + 1f, tx + Math.max(2f, tw * f), ty + 3f, 1f, fa(Colors.mulAlpha(W36, a)));
                RenderUtil.circle(tx + Math.max(1.5f, Math.min(tw - 1.5f, tw * f)), ty + 2f, 1.7f, fa(hi));
                if (interactive) {
                    Hit hit = addHit(HIT_COLOR, tx, ty - 1f, tw, 6f);
                    hit.setting = cs;
                    hit.arg = ch;
                }
            }
        }
    }

    private void drawBind(Entry en, float x, float y, float w, float a, boolean interactive) {
        boolean listening = binding == en.mod;
        String key = listening ? "..." : (en.mod.key == Keyboard.KEY_NONE ? "None" : Keyboard.getKeyName(en.mod.key));
        textMid("Bind", x, y, BIND_H, T_NAME, fa(Colors.mulAlpha(W48, a)));
        textMid(key, x + w - textW(key, T_NAME), y, BIND_H, T_NAME,
                fa(Colors.mulAlpha(listening ? 0xFFFFFFFF : W36, a)));
        if (interactive) addHit(HIT_BIND, x, y, w, BIND_H).entry = en;
    }

    private void drawSearch(float mx, float my) {
        float sx = (vW - SEARCH_W) / 2f, sy = y0 + panelH + 24f;
        boolean hover = mx >= sx && mx <= sx + SEARCH_W && my >= sy && my <= sy + SEARCH_H;
        RenderUtil.roundedRect(sx, sy, sx + SEARCH_W, sy + SEARCH_H, 10f, fa(BG));
        int border = searchFocused ? W24 : W04;
        RenderUtil.roundedOutline(sx, sy, sx + SEARCH_W, sy + SEARCH_H, 10f, 0.5f, fa(border), fa(border));
        if (hover && !searchFocused) {
            RenderUtil.roundedRect(sx, sy, sx + SEARCH_W, sy + SEARCH_H, 10f, fa(0x0AFFFFFF));
        }
        String shown;
        int col;
        if (search.length() == 0 && !searchFocused) {
            shown = "Search for module...";
            col = W36;
        } else {
            shown = search + (searchFocused && (System.currentTimeMillis() / 500L) % 2L == 0L ? "|" : "");
            col = 0xFFFFFFFF;
        }
        textMid(shown, sx + 8f, sy, SEARCH_H, T_NAME, fa(col));
        float cx = sx + SEARCH_W - 11f, cy = sy + SEARCH_H / 2f - 0.5f;
        RenderUtil.ring(cx, cy, 2.3f, 0.8f, fa(W36));
        RenderUtil.rect(cx + 1.8f, cy + 1.8f, cx + 3.4f, cy + 3.4f, fa(W36));
        addHit(HIT_SEARCH, sx, sy, SEARCH_W, SEARCH_H);
    }

    private void updateDragging(float mx, float my) {
        if (!Mouse.isButtonDown(0)) {
            dragging = null;
            return;
        }
        applyDrag(mx);
    }

    private void applyDrag(float mx) {
        if (dragging == null || dragW <= 0f) return;
        double f = Math.max(0.0, Math.min(1.0, (mx - dragX) / dragW));
        if (dragging instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) dragging;
            ns.set(ns.min + f * (ns.max - ns.min));
        } else if (dragging instanceof ColorSetting) {
            ColorSetting cs = (ColorSetting) dragging;
            if (dragChannel == 0) cs.hue = (float) f;
            else if (dragChannel == 1) cs.sat = (float) f;
            else cs.val = (float) f;
        }
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    @Override
    public void handleMouseInput() throws IOException {
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0 && !closing && scroll != null) {
            float mx = Mouse.getEventX() * width / (float) mc.displayWidth / ui;
            for (int c = 0; c < columns.size(); c++) {
                float px = x0 + c * (PW + GAP);
                if (mx >= px && mx <= px + PW) {
                    targetScroll[c] = Math.max(0f, targetScroll[c] - Integer.signum(wheel) * 18f);
                    break;
                }
            }
        }
        super.handleMouseInput();
    }

    private Hit findHit(float mx, float my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) return h;
        }
        return null;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (closing) return;
        if (binding != null) binding = null;
        searchFocused = false;
        if (button != 0 && button != 1) return;

        final float mx = mouseX / ui, my = mouseY / ui;
        Hit hit = findHit(mx, my);
        if (hit == null) return;

        switch (hit.type) {
            case HIT_SEARCH:
                searchFocused = true;
                Sounds.click();
                break;
            case HIT_ENTRY: {
                Entry en = hit.entry;
                if (button == 1) {
                    if (en.expandable()) {
                        en.setExpanded(!en.expanded());
                        Sounds.expand(en.expanded());
                    }
                } else if (en.toggle != null) {
                    en.toggle.run();
                    Sounds.toggle(en.isOn());
                } else if (en.action != null) {
                    Sounds.click();
                    en.action.run();
                } else if (en.expandable()) {
                    en.setExpanded(!en.expanded());
                    Sounds.expand(en.expanded());
                }
                break;
            }
            case HIT_BOOL:
                if (button == 0) {
                    ((BooleanSetting) hit.setting).toggle();
                    Sounds.toggle(((BooleanSetting) hit.setting).value);
                }
                break;
            case HIT_MODE: {
                if (button != 0) break;
                ModeSetting m = (ModeSetting) hit.setting;
                m.index = hit.arg;
                Sounds.click();
                if (m == themeMode) {
                    Theme.set(hit.arg);
                } else if (m == ClientSettings.gui && !m.is("v4")) {
                    ConfigManager.save();
                    mc.displayGuiScreen(GuiScreens.clickGui());
                }
                break;
            }
            case HIT_NUM:
            case HIT_COLOR:
                if (button != 0) break;
                dragging = hit.setting;
                dragChannel = hit.arg;
                dragX = hit.x;
                dragW = hit.w;
                applyDrag(mx);
                break;
            case HIT_BIND:
                if (button == 0) {
                    binding = hit.entry.mod;
                    Sounds.click();
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (closing) return;
        if (binding != null) {
            boolean clear = keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_BACK || keyCode == Keyboard.KEY_DELETE;
            binding.key = clear ? Keyboard.KEY_NONE : keyCode;
            binding = null;
            Sounds.click();
            return;
        }
        if (searchFocused) {
            if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_RETURN) {
                searchFocused = false;
            } else if (keyCode == Keyboard.KEY_BACK) {
                if (search.length() > 0) {
                    search = search.substring(0, search.length() - 1);
                    for (int i = 0; i < targetScroll.length; i++) targetScroll[i] = 0f;
                }
            } else if (typedChar >= 32 && typedChar != 127 && search.length() < 24) {
                search = search + typedChar;
                for (int i = 0; i < targetScroll.length; i++) targetScroll[i] = 0f;
            }
            return;
        }
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == LumenClient.openGuiKey.getKeyCode()) {
            beginClose();
        }
    }
}
