package com.lumen.client.modules;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.LumenUsers;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Puts a small themed "Lumen" badge next to the name tag of players who use Lumen Client.
 * "Render Self" also shows it on your own name tag (visible in third person).
 */
public class LumenIndicator extends Module {
    private final BooleanSetting renderSelf = add(new BooleanSetting("Render Self", true));
    private final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.6, 2.0, 0.1));

    private static final String LABEL = "Lumen";

    public LumenIndicator() {
        super("Lumen Indicator", "Shows a badge on the name tags of Lumen Client users.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onSpecials(RenderLivingEvent.Specials.Post e) {
        EntityLivingBase ent = e.entity;
        if (!(ent instanceof EntityPlayer) || mc.thePlayer == null) return;
        boolean self = ent == mc.thePlayer;
        if (self && !renderSelf.value) return;
        if (!LumenUsers.isLumenUser(ent.getUniqueID())) return;
        if (ent.isInvisible() || ent.isDead) return;
        if (ent.getDistanceSqToEntity(mc.thePlayer) > 64.0 * 64.0) return;
        draw((EntityPlayer) ent, e.x, e.y, e.z, self);
    }

    private void draw(EntityPlayer p, double x, double y, double z, boolean self) {
        FontRenderer fr = mc.fontRendererObj;
        RenderManager rm = mc.getRenderManager();
        float sc = scale.getFloat();
        float s = 0.016666668f * 1.6f;
        String name = p.getDisplayName().getFormattedText();
        int nameW = fr.getStringWidth(name);
        int badgeW = fr.getStringWidth(LABEL) + 6;
        int c1 = 0xFF000000 | Theme.current().c1;
        int c3 = 0xFF000000 | Theme.current().c3;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y + p.height + 0.5f - (p.isSneaking() ? 0.25f : 0f), (float) z);
        GL11.glNormal3f(0f, 1f, 0f);
        GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
        GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
        GlStateManager.scale(-s, -s, s);
        GlStateManager.disableLighting();
        GlStateManager.depthMask(false);
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // your own tag isn't drawn by vanilla, so for self draw the name too, centred with the badge
        float total = badgeW + 3 + (self ? nameW : 0);
        float left = self ? -total / 2f : -nameW / 2f - 3 - badgeW;
        float bx = left;

        // badge scales around its own centre so it stays next to the name
        GlStateManager.translate(bx + badgeW / 2f, 4f, 0f);
        GlStateManager.scale(sc, sc, 1f);
        GlStateManager.translate(-badgeW / 2f, -4f, 0f);

        GlStateManager.disableTexture2D();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(0, -1, 0).color(r(c1), g(c1), b(c1), 220).endVertex();
        wr.pos(0, 9, 0).color(r(c1), g(c1), b(c1), 220).endVertex();
        wr.pos(badgeW, 9, 0).color(r(c3), g(c3), b(c3), 220).endVertex();
        wr.pos(badgeW, -1, 0).color(r(c3), g(c3), b(c3), 220).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableTexture2D();

        fr.drawString(LABEL, 3, 0, 0xFF0B1020);
        if (self) {
            fr.drawString(name, badgeW + 3, 0, 0xFFFFFFFF);
        }

        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    private static int r(int c) { return (c >> 16) & 255; }
    private static int g(int c) { return (c >> 8) & 255; }
    private static int b(int c) { return c & 255; }
}
