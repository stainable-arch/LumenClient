package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.LumenClient;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.core.HudModule;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.core.Setting;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * The ClickGUI. Left-click a module to toggle it, right-click it to expand its settings.
 * Drag panels by their header, drag enabled HUD elements anywhere on empty space.
 */
public class ClickGui extends GuiScreen {
    private static final float W = 130f;
    private static final float HEADER_H = 22f;
    private static final float ROW_H = 18f;
    private static final float BIND_H = 14f;

    private static final int HIT_BG = 0, HIT_HEADER = 1, HIT_MODULE = 2, HIT_BOOL = 3, HIT_MODE = 4,
            HIT_NUMBER = 5, HIT_BIND = 6, HIT_THEME = 7, HIT_AURORA = 8, HIT_SOUNDS = 9;

    /** Panel positions survive closing and re-opening the GUI. */
    private static final Map<Category, float[]> SAVED = new EnumMap<Category, float[]>(Category.class);

    private static final class Panel {
        final Category cat;
        float x, y;
        boolean collapsed, dragging;
        float dx, dy;

        Panel(Category cat, float x, float y) {
            this.cat = cat;
            this.x = x;
            this.y = y;
        }
    }

    /** A clickable rectangle registered while drawing; mouse clicks look these up. */
    private static final class Hit {
        final int type;
        final float x, y, w, h;
        Module module;
        Setting setting;
        Panel panel;
        int arg;
        float trackX, trackW;

        Hit(int type, float x, float y, float w, float h) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        boolean contains(float mx, float my) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h;
        }
    }

    private static final class Ripple {
        final float x, y;
        final long start;

        Ripple(float x, float y, long start) {
            this.x = x;
            this.y = y;
            this.start = start;
        }
    }

    private final List<Panel> panels = new ArrayList<Panel>();
    private final List<Hit> hits = new ArrayList<Hit>();
    private final List<Ripple> ripples = new ArrayList<Ripple>();

    private Setting draggingSlider;
    private float sliderX, sliderW;
    private Module binding;
    private HudModule draggingHud;
    private float hudOffX, hudOffY;
    private Module hoverModule;

    private float fade;
    private boolean closing;
    private long lastFrame = System.currentTimeMillis();

    // ------------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------------

    @Override
    public void initGui() {
        super.initGui();
        if (panels.isEmpty()) {
            Category[] cats = Category.values();
            float total = cats.length * W + (cats.length - 1) * 14f;
            float startX = Math.max(10f, (width - total) / 2f);
            for (int i = 0; i < cats.length; i++) {
                float[] saved = SAVED.get(cats[i]);
                float px = saved != null ? saved[0] : startX + i * (W + 14f);
                float py = saved != null ? saved[1] : 30f;
                panels.add(new Panel(cats[i], px, py));
            }
            Sounds.open();
        }
        for (Module m : ModuleManager.modules) {
            m.toggleAnim = m.isEnabled() ? 1f : 0f;
            m.expandAnim = m.expanded ? 1f : 0f;
        }
    }

    @Override
    public void onGuiClosed() {
        for (Panel p : panels) {
            SAVED.put(p.cat, new float[] { p.x, p.y });
        }
        ConfigManager.save();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void updateScreen() {
        if (closing && fade <= 0.001f) {
            mc.displayGuiScreen(null);
        }
    }

    private void beginClose() {
        if (!closing) {
            closing = true;
            Sounds.close();
        }
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        fade = closing ? Math.max(0f, fade - dt * 6f) : Math.min(1f, fade + dt * 4.5f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        hits.clear();
        hoverModule = null;

        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        drawBackground(e, now);
        drawHudPreview();
        updateDragging(mouseX, mouseY);
        drawHudOutlines(mouseX, mouseY, e, now);
        drawTitle(e, now);

        for (Panel p : panels) {
            drawPanel(p, mouseX, mouseY, e, dt);
        }
        drawThemeBar(e, dt);
        drawRipples(e, now);
        drawTooltip(mouseX, mouseY, e);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawBackground(float e, long now) {
        Theme th = Theme.current();
        int top = Colors.mulAlpha(Colors.withAlpha(Colors.opaque(th.bg), 215), e);
        int bot = Colors.mulAlpha(Colors.withAlpha(Colors.lerp(Colors.opaque(th.bg), Colors.opaque(th.c3), 0.22f), 228), e);
        RenderUtil.gradientV(0, 0, width, height, top, bot);
        if (ClientSettings.aurora) {
            Aurora.draw(width, height, e, now);
        }
    }

    private void updateDragging(int mouseX, int mouseY) {
        if (!Mouse.isButtonDown(0)) {
            draggingSlider = null;
            draggingHud = null;
            for (Panel p : panels) p.dragging = false;
            return;
        }
        for (Panel p : panels) {
            if (p.dragging) {
                p.x = Math.max(0, Math.min(width - W, mouseX - p.dx));
                p.y = Math.max(0, Math.min(height - HEADER_H, mouseY - p.dy));
            }
        }
        if (draggingHud != null) {
            draggingHud.x = Math.max(0, Math.min(width - draggingHud.scaledWidth(), mouseX - hudOffX));
            draggingHud.y = Math.max(0, Math.min(height - draggingHud.scaledHeight(), mouseY - hudOffY));
        }
        if (draggingSlider instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) draggingSlider;
            double f = Math.max(0.0, Math.min(1.0, (mouseX - sliderX) / sliderW));
            ns.set(ns.min + f * (ns.max - ns.min));
        }
    }

    /** The in-game overlay is dimmed by the GUI background, so draw the HUD elements again on top. */
    private void drawHudPreview() {
        ScaledResolution sr = new ScaledResolution(mc);
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled() && m instanceof HudModule) {
                ((HudModule) m).renderHud(sr);
            }
        }
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
    }

    private void drawHudOutlines(int mouseX, int mouseY, float e, long now) {
        Theme th = Theme.current();
        float pulse = 0.55f + 0.45f * (float) Math.sin(now / 350.0);
        for (Module m : ModuleManager.modules) {
            if (!(m instanceof HudModule) || !m.isEnabled()) continue;
            HudModule h = (HudModule) m;
            float w = h.scaledWidth(), hh = h.scaledHeight();
            if (w <= 0 || hh <= 0) continue;
            boolean inside = mouseX >= h.x && mouseX <= h.x + w && mouseY >= h.y && mouseY <= h.y + hh;
            boolean dragging = draggingHud == h;
            int col = Colors.mulAlpha(Colors.withAlpha(th.c1, dragging ? 255 : (inside ? (int) (255 * pulse) : 110)), e);
            RenderUtil.rectOutline(h.x - 1.5f, h.y - 1.5f, h.x + w + 1.5f, h.y + hh + 1.5f, 1f, col);
            if (inside || dragging) {
                RenderUtil.string(h.name, h.x, h.y - 10f, Colors.mulAlpha(0xFFE8ECF4, e));
            }
        }
    }

    private void drawTitle(float e, long now) {
        Theme th = Theme.current();
        String title = "LUMEN CLIENT";
        float scale = 1.6f;
        float tw = RenderUtil.width(title) * scale;
        GlStateManager.pushMatrix();
        GlStateManager.translate((width - tw) / 2f, 8f, 0f);
        GlStateManager.scale(scale, scale, 1f);
        float cx = 0;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            float t = (now % 5000L) / 5000f + i * 0.045f;
            RenderUtil.string(ch, cx, 0, Colors.mulAlpha(Colors.gradient(th, t), e));
            cx += RenderUtil.width(ch);
        }
        GlStateManager.popMatrix();
    }

    private static float settingsHeight(Module m) {
        float h = 6f + BIND_H;
        for (Setting s : m.settings) h += s.height();
        return h;
    }

    private static float moduleHeight(Module m) {
        return ROW_H + settingsHeight(m) * m.expandAnim;
    }

    private Hit addHit(int type, float x, float y, float w, float h) {
        Hit hit = new Hit(type, x, y, w, h);
        hits.add(hit);
        return hit;
    }

    private void drawPanel(Panel p, int mx, int my, float e, float dt) {
        Theme th = Theme.current();
        List<Module> mods = ModuleManager.byCategory(p.cat);
        float step = Math.min(1f, dt * 14f);

        for (Module m : mods) {
            m.toggleAnim += ((m.isEnabled() ? 1f : 0f) - m.toggleAnim) * step;
            m.expandAnim += ((m.expanded ? 1f : 0f) - m.expandAnim) * step;
        }

        float totalH = HEADER_H;
        if (!p.collapsed) {
            for (Module m : mods) totalH += moduleHeight(m);
            totalH += 4f;
        }

        // body + header
        int body = Colors.mulAlpha(Colors.withAlpha(Colors.lerp(0xFF0B0F1E, Colors.opaque(th.c3), 0.10f), 218), e);
        RenderUtil.roundedRect(p.x, p.y, p.x + W, p.y + totalH, 6f, body);
        RenderUtil.roundedRectH(p.x, p.y, p.x + W, p.y + HEADER_H, 6f,
                Colors.mulAlpha(Colors.withAlpha(th.c1, 120), e), Colors.mulAlpha(Colors.withAlpha(th.c3, 120), e));
        RenderUtil.gradientH(p.x + 4, p.y + HEADER_H - 1, p.x + W - 4, p.y + HEADER_H,
                Colors.mulAlpha(Colors.withAlpha(th.c1, 255), e), Colors.mulAlpha(Colors.withAlpha(th.c2, 255), e));

        int enabledCount = 0;
        for (Module m : mods) if (m.isEnabled()) enabledCount++;
        RenderUtil.string(p.cat.label, p.x + 8, p.y + 7, Colors.mulAlpha(0xFFFFFFFF, e));
        String count = enabledCount + "/" + mods.size();
        RenderUtil.string(count, p.x + W - 8 - RenderUtil.width(count), p.y + 7, Colors.mulAlpha(0xFFB9C0D0, e));

        addHit(HIT_BG, p.x, p.y, W, totalH).panel = p;
        Hit header = addHit(HIT_HEADER, p.x, p.y, W, HEADER_H);
        header.panel = p;

        if (p.collapsed) return;

        float cy = p.y + HEADER_H + 2f;
        for (Module m : mods) {
            boolean hov = mx >= p.x + 3 && mx <= p.x + W - 3 && my >= cy && my < cy + ROW_H;
            if (hov) hoverModule = m;

            float x1 = p.x + 3f, x2 = p.x + W - 3f;
            if (m.toggleAnim > 0.01f) {
                RenderUtil.roundedRectH(x1, cy, x2, cy + ROW_H - 1f, 4f,
                        Colors.mulAlpha(Colors.withAlpha(th.c1, 175), e * m.toggleAnim),
                        Colors.mulAlpha(Colors.withAlpha(th.c2, 175), e * m.toggleAnim));
            }
            if (hov) {
                RenderUtil.roundedRect(x1, cy, x2, cy + ROW_H - 1f, 4f, Colors.mulAlpha(0x1CFFFFFF, e));
            }
            int nameColor = Colors.lerp(0xFFAEB4C2, 0xFFFFFFFF, m.toggleAnim);
            RenderUtil.string(m.name, p.x + 9, cy + 5f, Colors.mulAlpha(nameColor, e));
            RenderUtil.triangle(p.x + W - 12f, cy + (ROW_H - 1f) / 2f, 3.2f, 90f * m.expandAnim,
                    Colors.mulAlpha(0xCCFFFFFF, e));

            Hit hit = addHit(HIT_MODULE, x1, cy, x2 - x1, ROW_H);
            hit.module = m;

            float setH = settingsHeight(m);
            if (m.expandAnim > 0.005f) {
                float areaH = setH * m.expandAnim;
                float sy = cy + ROW_H - 1f;
                RenderUtil.scissor(p.x, sy, W, areaH);
                RenderUtil.rect(p.x + 3, sy, p.x + W - 3, sy + areaH, Colors.mulAlpha(0x66000000, e));
                boolean interactive = m.expandAnim > 0.97f && !closing;
                float ry = sy + 3f;
                for (Setting s : m.settings) {
                    drawSetting(s, m, p.x + 8, ry, W - 16, e, dt, interactive);
                    ry += s.height();
                }
                drawBind(m, p.x + 8, ry, W - 16, e, interactive);
                RenderUtil.endScissor();
            }
            cy += ROW_H + setH * m.expandAnim;
        }
    }

    private void drawSetting(Setting s, Module m, float x, float y, float w, float e, float dt, boolean interactive) {
        Theme th = Theme.current();
        int label = Colors.mulAlpha(0xFFC3C9D6, e);
        float step = Math.min(1f, dt * 16f);

        if (s instanceof BooleanSetting) {
            BooleanSetting b = (BooleanSetting) s;
            b.anim += ((b.value ? 1f : 0f) - b.anim) * step;
            RenderUtil.string(b.name, x, y + 3f, label);
            float tx = x + w - 16f, ty = y + 3f;
            RenderUtil.roundedRect(tx, ty, tx + 16f, ty + 8f, 4f,
                    Colors.mulAlpha(Colors.lerp(0xFF3A4052, Colors.opaque(th.c1), b.anim), e));
            float kx = tx + 1f + 8f * b.anim;
            RenderUtil.roundedRect(kx, ty + 1f, kx + 6f, ty + 7f, 3f, Colors.mulAlpha(0xFFFFFFFF, e));
            if (interactive) {
                Hit h = addHit(HIT_BOOL, x - 2, y, w + 4, 14);
                h.module = m;
                h.setting = s;
            }
        } else if (s instanceof ModeSetting) {
            ModeSetting ms = (ModeSetting) s;
            RenderUtil.string(ms.name, x, y + 3f, label);
            String v = ms.get();
            RenderUtil.string(v, x + w - RenderUtil.width(v), y + 3f, Colors.mulAlpha(Colors.opaque(th.c1), e));
            if (interactive) {
                Hit h = addHit(HIT_MODE, x - 2, y, w + 4, 14);
                h.module = m;
                h.setting = s;
            }
        } else if (s instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) s;
            RenderUtil.string(ns.name, x, y + 2f, label);
            String v = ns.display();
            RenderUtil.string(v, x + w - RenderUtil.width(v), y + 2f, Colors.mulAlpha(Colors.opaque(th.c1), e));
            float fw = Math.max(3f, w * (float) ns.fraction());
            RenderUtil.roundedRect(x, y + 13f, x + w, y + 16f, 1.5f, Colors.mulAlpha(0x55FFFFFF, e));
            RenderUtil.roundedRectH(x, y + 13f, x + fw, y + 16f, 1.5f,
                    Colors.mulAlpha(Colors.opaque(th.c1), e), Colors.mulAlpha(Colors.opaque(th.c2), e));
            RenderUtil.circle(x + fw, y + 14.5f, 3.2f, Colors.mulAlpha(0xFFFFFFFF, e));
            if (interactive) {
                Hit h = addHit(HIT_NUMBER, x - 2, y + 8, w + 4, 11);
                h.module = m;
                h.setting = s;
                h.trackX = x;
                h.trackW = w;
            }
        }
    }

    private void drawBind(Module m, float x, float y, float w, float e, boolean interactive) {
        Theme th = Theme.current();
        RenderUtil.string("Bind", x, y + 3f, Colors.mulAlpha(0xFFC3C9D6, e));
        String v;
        if (binding == m) {
            v = "press a key...";
        } else if (m.key == Keyboard.KEY_NONE) {
            v = "None";
        } else {
            String name = Keyboard.getKeyName(m.key);
            v = name == null ? "?" : name;
        }
        RenderUtil.string(v, x + w - RenderUtil.width(v), y + 3f, Colors.mulAlpha(Colors.opaque(th.c1), e));
        if (interactive) {
            Hit h = addHit(HIT_BIND, x - 2, y, w + 4, BIND_H);
            h.module = m;
        }
    }

    private void drawThemeBar(float e, float dt) {
        List<Theme> all = Theme.ALL;
        float chipH = 16f, gap = 5f;
        float[] cw = new float[all.size()];
        String auroraLabel = "Aurora " + (ClientSettings.aurora ? "ON" : "OFF");
        String soundLabel = "Sounds " + (ClientSettings.sounds ? "ON" : "OFF");
        float pad = 14f;
        float total, aw, sw;
        while (true) {
            total = 0f;
            for (int i = 0; i < all.size(); i++) {
                cw[i] = RenderUtil.width(all.get(i).name) + pad;
                total += cw[i] + gap;
            }
            aw = RenderUtil.width(auroraLabel) + pad;
            sw = RenderUtil.width(soundLabel) + pad;
            total += 8f + aw + gap + sw;
            if (total <= width - 30f || pad <= 4f) break;
            pad -= 2f; // small screens (high GUI scale): shrink the chips
        }

        float x = (width - total) / 2f;
        float y = height - 30f;
        RenderUtil.roundedRect(x - 10f, y - 6f, x + total + 10f, y + chipH + 6f, 9f, Colors.mulAlpha(0xC80B0F1E, e));
        RenderUtil.stringCentered("Right Shift / Esc closes  -  tap a module's arrow (or right-click) for settings",
                width / 2f, y - 18f, Colors.mulAlpha(0xFF9AA3B5, e));

        for (int i = 0; i < all.size(); i++) {
            Theme t = all.get(i);
            boolean sel = i == Theme.index();
            if (sel) {
                RenderUtil.roundedRect(x - 1.5f, y - 1.5f, x + cw[i] + 1.5f, y + chipH + 1.5f, 6f, Colors.mulAlpha(0xFFFFFFFF, e));
            }
            RenderUtil.roundedRectH(x, y, x + cw[i], y + chipH, 5f,
                    Colors.mulAlpha(Colors.withAlpha(t.c1, 235), e), Colors.mulAlpha(Colors.withAlpha(t.c2, 235), e));
            RenderUtil.stringCentered(t.name, x + cw[i] / 2f, y + 4f, Colors.mulAlpha(0xFFFFFFFF, e));
            addHit(HIT_THEME, x, y, cw[i], chipH).arg = i;
            x += cw[i] + gap;
        }
        x += 8f;
        toggleChip(auroraLabel, ClientSettings.aurora, x, y, aw, chipH, e, HIT_AURORA);
        x += aw + gap;
        toggleChip(soundLabel, ClientSettings.sounds, x, y, sw, chipH, e, HIT_SOUNDS);
    }

    private void toggleChip(String label, boolean on, float x, float y, float w, float h, float e, int hitType) {
        Theme th = Theme.current();
        int col = on ? Colors.withAlpha(th.c1, 200) : 0xFF3A4052;
        RenderUtil.roundedRect(x, y, x + w, y + h, 5f, Colors.mulAlpha(col, e));
        RenderUtil.stringCentered(label, x + w / 2f, y + 4f, Colors.mulAlpha(on ? 0xFF0B1020 : 0xFFD6DBE6, e));
        addHit(hitType, x, y, w, h);
    }

    private void drawRipples(float e, long now) {
        Theme th = Theme.current();
        for (Iterator<Ripple> it = ripples.iterator(); it.hasNext(); ) {
            Ripple r = it.next();
            float age = (now - r.start) / 450f;
            if (age >= 1f) {
                it.remove();
                continue;
            }
            float ease = 1f - (float) Math.pow(1f - age, 3);
            int a = (int) (170 * (1f - age) * e);
            RenderUtil.ring(r.x, r.y, 3f + 26f * ease, 1.6f, Colors.withAlpha(th.c2, a));
        }
    }

    private void drawTooltip(int mx, int my, float e) {
        if (hoverModule == null || draggingSlider != null || closing) return;
        String text = hoverModule.description;
        float tw = RenderUtil.width(text) + 10f;
        float x = Math.min(mx + 10f, width - tw - 4f);
        float y = Math.min(my + 10f, height - 18f);
        RenderUtil.roundedRect(x, y, x + tw, y + 15f, 4f, Colors.mulAlpha(0xE60B0F1E, e));
        RenderUtil.string(text, x + 5f, y + 3.5f, Colors.mulAlpha(0xFFE8ECF4, e));
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    private Hit findHit(float mx, float my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) return h;
        }
        return null;
    }

    private void bringToFront(Panel p) {
        panels.remove(p);
        panels.add(p);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (closing) return;
        ripples.add(new Ripple(mouseX, mouseY, System.currentTimeMillis()));
        if (binding != null) {
            binding = null; // clicking elsewhere cancels key binding
        }

        Hit hit = findHit(mouseX, mouseY);
        if (hit == null) {
            if (button == 0) startHudDrag(mouseX, mouseY);
            return;
        }

        switch (hit.type) {
            case HIT_BG:
                bringToFront(hit.panel);
                break;
            case HIT_HEADER:
                bringToFront(hit.panel);
                if (button == 0) {
                    hit.panel.dragging = true;
                    hit.panel.dx = mouseX - hit.panel.x;
                    hit.panel.dy = mouseY - hit.panel.y;
                } else if (button == 1) {
                    hit.panel.collapsed = !hit.panel.collapsed;
                    Sounds.expand(!hit.panel.collapsed);
                }
                break;
            case HIT_MODULE:
                if (button == 0 && mouseX >= hit.x + hit.w - 22f) {
                    // left-click on the arrow = expand (so touch screens don't need right-click)
                    hit.module.expanded = !hit.module.expanded;
                    Sounds.expand(hit.module.expanded);
                } else if (button == 0) {
                    hit.module.toggle();
                    Sounds.toggle(hit.module.isEnabled());
                } else if (button == 1) {
                    hit.module.expanded = !hit.module.expanded;
                    Sounds.expand(hit.module.expanded);
                }
                break;
            case HIT_BOOL:
                ((BooleanSetting) hit.setting).toggle();
                Sounds.click();
                break;
            case HIT_MODE:
                ((ModeSetting) hit.setting).cycle(button == 1 ? -1 : 1);
                Sounds.click();
                break;
            case HIT_NUMBER:
                if (button == 0) {
                    draggingSlider = hit.setting;
                    sliderX = hit.trackX;
                    sliderW = hit.trackW;
                    NumberSetting ns = (NumberSetting) hit.setting;
                    double f = Math.max(0.0, Math.min(1.0, (mouseX - sliderX) / sliderW));
                    ns.set(ns.min + f * (ns.max - ns.min));
                    Sounds.click();
                }
                break;
            case HIT_BIND:
                binding = hit.module;
                Sounds.click();
                break;
            case HIT_THEME:
                Theme.set(hit.arg);
                Sounds.theme(hit.arg);
                break;
            case HIT_AURORA:
                ClientSettings.aurora = !ClientSettings.aurora;
                Sounds.click();
                break;
            case HIT_SOUNDS:
                ClientSettings.sounds = !ClientSettings.sounds;
                Sounds.click();
                break;
            default:
                break;
        }
    }

    private void startHudDrag(int mx, int my) {
        for (int i = ModuleManager.modules.size() - 1; i >= 0; i--) {
            Module m = ModuleManager.modules.get(i);
            if (!(m instanceof HudModule) || !m.isEnabled()) continue;
            HudModule h = (HudModule) m;
            if (mx >= h.x && mx <= h.x + h.scaledWidth() && my >= h.y && my <= h.y + h.scaledHeight()) {
                draggingHud = h;
                hudOffX = mx - h.x;
                hudOffY = my - h.y;
                return;
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (closing) return;
        if (binding != null) {
            boolean clear = keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_BACK || keyCode == Keyboard.KEY_DELETE;
            binding.key = clear ? Keyboard.KEY_NONE : keyCode;
            binding = null;
            Sounds.click();
            return;
        }
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == LumenClient.openGuiKey.getKeyCode()) {
            beginClose();
        }
    }
}
