package com.lumen.client.gui;

import com.lumen.client.ClientSettings;
import com.lumen.client.LumenClient;
import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.Category;
import com.lumen.client.core.ConfigManager;
import com.lumen.client.core.HudModule;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModuleManager;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.core.Setting;
import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The ClickGUI: one centred window with a sidebar (module categories + general pages) and a scrollable
 * content area (module cards, settings, themes, keybinds).
 *
 * Click a card = on/off, click its arrow (or right-click the card) = expand its settings.
 * Drag the content to scroll (touch friendly) or use the mouse wheel. Click outside the window and
 * drag to move enabled HUD elements.
 */
public class ClickGui extends GuiScreen {
    private static final float CARD_H = 30f;
    private static final float ROW_GAP = 5f;
    private static final float BIND_H = 14f;
    private static final float SIDE_ITEM_H = 16f;
    private static final float SCROLL_PAD = 6f;

    private static final int PAGE_MODULES = 0, PAGE_SETTINGS = 1, PAGE_THEME = 2, PAGE_KEYBINDS = 3;

    private static final int HIT_BG = 0, HIT_CAT = 1, HIT_PAGE = 2, HIT_SEARCH = 3, HIT_VIEW = 4, HIT_CARD = 5,
            HIT_BOOL = 6, HIT_MODE = 7, HIT_NUMBER = 8, HIT_BIND = 9, HIT_THEME = 10, HIT_AURORA = 11,
            HIT_SOUNDS = 12, HIT_FONT = 13;

    /** Page / category / view choice survive closing and re-opening the GUI. */
    private static int page = PAGE_MODULES;
    private static int catIndex = 0;
    private static boolean gridView = false;

    /** A clickable rectangle registered while drawing; mouse clicks look these up. */
    private static final class Hit {
        final int type;
        final float x, y, w, h;
        boolean content; // lives inside the scrolling viewport
        Module module;
        Setting setting;
        int arg;
        float trackX, trackW;

        Hit(int type, float x, float y, float w, float h) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        boolean contains(float mx, float my) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h;
        }
    }

    private final List<Hit> hits = new ArrayList<Hit>();
    private boolean contentMode;

    // layout (recomputed every frame)
    private float wx, wy, ww, wh;
    private float vx, vy, vw, vh;
    private float e;
    private float dtNow;

    /** Whole-GUI scale on top of Minecraft's GUI scale. Layout and hit-testing happen in this scaled space. */
    private static final float UI_MAX = 1.5f;
    private float ui = 1f;
    private float vW, vH; // screen size in scaled space

    // scrolling
    private float scroll, targetScroll, contentH;
    private boolean pressActive, dragScrolling;
    private int pressY, pressButton;
    private float pressScroll;
    private Hit pressHit;

    // interaction state
    private Setting draggingSlider;
    private float sliderX, sliderW;
    private Module binding;
    private boolean searchFocused;
    private String search = "";
    private float auroraAnim = ClientSettings.aurora ? 1f : 0f;
    private float soundsAnim = ClientSettings.sounds ? 1f : 0f;

    private float fade;
    private boolean closing;
    private long lastFrame = System.currentTimeMillis();

    // ------------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------------

    @Override
    public void initGui() {
        super.initGui();
        Sounds.open();
        for (Module m : ModuleManager.modules) {
            m.toggleAnim = m.isEnabled() ? 1f : 0f;
            m.expandAnim = m.expanded ? 1f : 0f;
        }
        auroraAnim = ClientSettings.aurora ? 1f : 0f;
        soundsAnim = ClientSettings.sounds ? 1f : 0f;
    }

    @Override
    public void onGuiClosed() {
        ConfigManager.save();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void updateScreen() {
        if (closing && fade <= 0.001f) {
            mc.displayGuiScreen(null);
        }
    }

    private void beginClose() {
        if (!closing) {
            closing = true;
            Sounds.close();
        }
    }

    // ------------------------------------------------------------------------------------------
    // small helpers
    // ------------------------------------------------------------------------------------------

    /**
     * Re-colours one of the GUI's dark surface shades with the current theme: the brightness of the
     * original shade is kept, the hue comes from the theme's colours.
     */
    private static int sf(int shade) {
        Theme th = Theme.current();
        int tint = Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
        int mx = Math.max(Colors.channel(shade, 16), Math.max(Colors.channel(shade, 8), Colors.channel(shade, 0)));
        float f = Math.min(1f, mx / 255f * 0.95f);
        return Colors.lerp(0xFF000000, tint, f);
    }

    private int fa(int color) {
        return Colors.mulAlpha(color, e);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    /** Unscaled shadowed text in the ClickGUI font. */
    private static void str(String s, float x, float y, int color) {
        LumenFont.draw(s, x, y, color, true);
    }

    private static void strC(String s, float cx, float y, int color) {
        LumenFont.draw(s, cx - LumenFont.width(s) / 2f, y, color, true);
    }

    private float textW(String s, float scale) {
        return LumenFont.width(s) * scale;
    }

    private String trim(String s, float maxW, float scale) {
        if (textW(s, scale) <= maxW) return s;
        return LumenFont.trim(s, Math.max(0f, maxW / scale));
    }

    /** First word in italics (tinted), the rest plain white. */
    private void titleText(String title, float x, float y, float scale, int tint) {
        int sp = title.indexOf(' ');
        String first = sp < 0 ? title : title.substring(0, sp);
        String rest = sp < 0 ? "" : title.substring(sp);
        String it = "\u00a7o" + first;
        text(it, x, y, scale, tint);
        if (rest.length() > 0) {
            text(rest, x + textW(it, scale), y, scale, fa(0xFFFFFFFF));
        }
    }

    private Hit addHit(int type, float x, float y, float w, float h) {
        Hit hit = new Hit(type, x, y, w, h);
        hit.content = contentMode;
        hits.add(hit);
        return hit;
    }

    private void clipTo(float x, float y, float w, float h) {
        float x1 = Math.max(x, vx), y1 = Math.max(y, vy);
        float x2 = Math.min(x + w, vx + vw), y2 = Math.min(y + h, vy + vh);
        RenderUtil.scissor(x1 * ui, y1 * ui, Math.max(0f, x2 - x1) * ui, Math.max(0f, y2 - y1) * ui);
    }

    private void viewClip() {
        RenderUtil.scissor(vx * ui, vy * ui, vw * ui, vh * ui);
    }

    private static float settingsHeight(Module m) {
        float h = 8f + BIND_H;
        for (Setting s : m.settings) h += s.height();
        return h;
    }

    private static float moduleHeight(Module m) {
        return CARD_H + settingsHeight(m) * m.expandAnim;
    }

    private void resetScroll() {
        scroll = 0f;
        targetScroll = 0f;
        contentH = 0f;
    }

    private float maxScroll() {
        return Math.max(0f, contentH - vh + 2f);
    }

    private boolean inViewport(float mx, float my) {
        return mx >= vx && mx <= vx + vw && my >= vy && my <= vy + vh;
    }

    private List<Module> visibleModules() {
        String q = search.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<Module>();
        if (q.length() == 0) {
            return ModuleManager.byCategory(Category.values()[catIndex]);
        }
        for (Module m : ModuleManager.modules) {
            if (m.name.toLowerCase(Locale.ROOT).contains(q) || m.description.toLowerCase(Locale.ROOT).contains(q)) {
                out.add(m);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        dtNow = dt;
        fade = closing ? Math.max(0f, fade - dt * 6f) : Math.min(1f, fade + dt * 4.5f);
        e = 1f - (float) Math.pow(1f - fade, 3);

        hits.clear();
        contentMode = false;

        // the menu is drawn UI_MAX-bounded larger than vanilla GUI units, but never bigger than the screen allows
        ui = Math.max(1f, Math.min(UI_MAX, Math.min(width / 340f, height / 200f)));
        vW = width / ui;
        vH = height / ui;
        final float mx = mouseX / ui, my = mouseY / ui;

        // animations
        float step = Math.min(1f, dt * 14f);
        for (Module m : ModuleManager.modules) {
            m.toggleAnim += ((m.isEnabled() ? 1f : 0f) - m.toggleAnim) * step;
            m.expandAnim += ((m.expanded ? 1f : 0f) - m.expandAnim) * step;
        }
        auroraAnim += ((ClientSettings.aurora ? 1f : 0f) - auroraAnim) * step;
        soundsAnim += ((ClientSettings.sounds ? 1f : 0f) - soundsAnim) * step;

        // layout
        ww = Math.min(vW - 8f, Math.max(300f, Math.min(470f, vW * 0.9f)));
        wh = Math.min(vH - 8f, Math.max(190f, Math.min(290f, vH * 0.92f)));
        wx = (vW - ww) / 2f;
        wy = (vH - wh) / 2f + (1f - e) * 8f;
        float sbW = ww < 360f ? 76f : 88f;
        float mainX = wx + 6f + sbW + 8f;
        float mainR = wx + ww - 8f;
        vx = mainX;
        vw = mainR - mainX;
        vy = wy + 46f;
        vh = wy + wh - 8f - vy;

        targetScroll = Math.max(0f, Math.min(maxScroll(), targetScroll));
        scroll += (targetScroll - scroll) * Math.min(1f, dt * 16f);
        if (Math.abs(targetScroll - scroll) < 0.05f) scroll = targetScroll;

        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        drawBackground(now);
        if (mc.theWorld != null) drawHudPreview();
        updateDragging(mx);

        GlStateManager.pushMatrix();
        GlStateManager.scale(ui, ui, 1f);
        drawWindow(sbW);
        addHit(HIT_BG, wx, wy, ww, wh);
        drawSidebar(sbW, mx, my);
        drawHeader(mainR, mx, my, now);

        // content
        contentMode = true;
        viewClip();
        float top = vy - scroll;
        float used;
        switch (page) {
            case PAGE_SETTINGS:
                used = drawSettingsPage(top, mx, my);
                break;
            case PAGE_THEME:
                used = drawThemePage(top, mx, my);
                break;
            case PAGE_KEYBINDS:
                used = drawKeybindsPage(top, mx, my);
                break;
            default:
                used = drawModulesPage(top, mx, my);
                break;
        }
        RenderUtil.endScissor();
        contentMode = false;
        contentH = used;
        drawScrollbar();
        GlStateManager.popMatrix();

        // pencil button in the bottom-left corner of the screen: opens the HUD editor
        if (mc.theWorld != null) HudEditor.drawButton(height, mouseX, mouseY, e, false);

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawBackground(long now) {
        Theme th = Theme.current();
        int top = Colors.mulAlpha(Colors.withAlpha(sf(0xFF0A0B16), 215), e);
        int bot = Colors.mulAlpha(Colors.withAlpha(Colors.lerp(sf(0xFF0A0B16), Colors.opaque(th.c3), 0.08f), 235), e);
        RenderUtil.gradientV(0, 0, width, height, top, bot);
        if (ClientSettings.aurora) {
            Aurora.draw(width, height, e * 0.5f, now);
        }
    }

    private void updateDragging(float scaledMouseX) {
        if (!Mouse.isButtonDown(0)) {
            draggingSlider = null;
            return;
        }
        if (draggingSlider instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) draggingSlider;
            double f = Math.max(0.0, Math.min(1.0, (scaledMouseX - sliderX) / sliderW));
            ns.set(ns.min + f * (ns.max - ns.min));
        }
    }

    /** The in-game overlay is dimmed by the GUI background, so draw the HUD elements again on top. */
    private void drawHudPreview() {
        ScaledResolution sr = new ScaledResolution(mc);
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled() && m instanceof HudModule) {
                ((HudModule) m).renderHud(sr);
            }
        }
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
    }

    private void drawWindow(float sbW) {
        Theme th = Theme.current();
        // soft shadow
        RenderUtil.roundedRect(wx - 3f, wy - 3f, wx + ww + 3f, wy + wh + 3f, 11f, fa(0x38000000));
        // border + body
        int border = Colors.lerp(sf(0xFF1B1F42), Colors.opaque(th.c1), 0.18f);
        RenderUtil.roundedRect(wx, wy, wx + ww, wy + wh, 9f, fa(border));
        int body = Colors.lerp(sf(0xFF0C0D1A), Colors.opaque(th.c3), 0.035f);
        RenderUtil.roundedRect(wx + 1f, wy + 1f, wx + ww - 1f, wy + wh - 1f, 8f, fa(Colors.withAlpha(body, 250)));
        // sidebar panel
        float sx = wx + 6f, sy = wy + 6f;
        RenderUtil.roundedRect(sx, sy, sx + sbW, wy + wh - 6f, 7f, fa(sf(0xFF14173A)));
        RenderUtil.roundedRect(sx + 1f, sy + 1f, sx + sbW - 1f, wy + wh - 7f, 6f,
                fa(Colors.withAlpha(Colors.lerp(sf(0xFF080918), Colors.opaque(th.c3), 0.03f), 252)));
    }

    // ---- sidebar --------------------------------------------------------------------------------

    private void drawSidebar(float sbW, float mx, float my) {
        Theme th = Theme.current();
        float sx = wx + 6f, sy = wy + 6f;
        float cy = sy + 9f;

        // logo
        RenderUtil.roundedRectH(sx + 8f, cy, sx + 22f, cy + 14f, 4f, fa(Colors.opaque(th.c1)), fa(Colors.opaque(th.c3)));
        strC("L", sx + 15f, cy + 3.5f, fa(0xFF0B1020));
        text("Lumen", sx + 27f, cy - 0.5f, 0.95f, fa(0xFFFFFFFF));
        text("\u00a7oClient", sx + 27f + textW("Lumen ", 0.95f), cy - 0.5f, 0.95f,
                fa(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f)));
        text("RELEASE " + LumenClient.VERSION, sx + 27f, cy + 9f, 0.55f, fa(0xFF6D7497));
        cy += 26f;

        text("MODULES", sx + 9f, cy, 0.6f, fa(0xFF6D7497));
        cy += 10f;
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int total = ModuleManager.byCategory(cats[i]).size();
            boolean sel = page == PAGE_MODULES && catIndex == i;
            sideItem(cats[i].label, String.valueOf(total), sel, sx, cy, sbW, mx, my);
            addHit(HIT_CAT, sx + 3f, cy, sbW - 6f, SIDE_ITEM_H).arg = i;
            cy += SIDE_ITEM_H + 1f;
        }
        cy += 6f;
        text("GENERAL", sx + 9f, cy, 0.6f, fa(0xFF6D7497));
        cy += 10f;
        String[] names = { null, "Settings", "Theme", "Keybinds" };
        for (int p = PAGE_SETTINGS; p <= PAGE_KEYBINDS; p++) {
            sideItem(names[p], null, page == p, sx, cy, sbW, mx, my);
            addHit(HIT_PAGE, sx + 3f, cy, sbW - 6f, SIDE_ITEM_H).arg = p;
            cy += SIDE_ITEM_H + 1f;
        }
    }

    private void sideItem(String label, String count, boolean selected, float sx, float y, float sbW, float mx, float my) {
        Theme th = Theme.current();
        float x1 = sx + 3f, x2 = sx + sbW - 3f;
        boolean hov = mx >= x1 && mx <= x2 && my >= y && my <= y + SIDE_ITEM_H;
        if (selected) {
            RenderUtil.roundedRectH(x1, y, x2, y + SIDE_ITEM_H, 5f,
                    fa(Colors.withAlpha(th.c1, 95)), fa(Colors.withAlpha(th.c3, 95)));
            RenderUtil.roundedRect(x1, y + 3f, x1 + 1.5f, y + SIDE_ITEM_H - 3f, 0.75f, fa(Colors.opaque(th.c1)));
        } else if (hov) {
            RenderUtil.roundedRect(x1, y, x2, y + SIDE_ITEM_H, 5f, fa(0x18FFFFFF));
        }
        int dot = selected ? Colors.opaque(th.c1) : 0xFF59608A;
        RenderUtil.circle(x1 + 8f, y + SIDE_ITEM_H / 2f, 2f, fa(dot));
        text(label, x1 + 15f, y + 4.5f, 0.9f, fa(selected ? 0xFFFFFFFF : 0xFFA4ABC6));
        if (count != null) {
            float cw = textW(count, 0.7f);
            text(count, x2 - 6f - cw, y + 5.5f, 0.7f, fa(selected ? 0xFFE0E4F4 : 0xFF6D7497));
        }
    }

    // ---- header ---------------------------------------------------------------------------------

    private void drawHeader(float mainR, float mx, float my, long now) {
        Theme th = Theme.current();
        int tint = Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f);
        String title, sub;
        if (page == PAGE_SETTINGS) {
            title = "Client Settings";
            sub = "General options";
        } else if (page == PAGE_THEME) {
            title = "Client Theme";
            sub = Theme.ALL.size() + " themes | " + Theme.current().name + " selected";
        } else if (page == PAGE_KEYBINDS) {
            title = "Module Keybinds";
            sub = "Click a bind, then press a key";
        } else {
            List<Module> mods = visibleModules();
            int enabled = 0;
            for (Module m : mods) if (m.isEnabled()) enabled++;
            title = search.trim().length() > 0 ? "Search Results" : Category.values()[catIndex].label + " Modules";
            sub = mods.size() + " modules | " + enabled + " enabled";
        }
        titleText(title, vx, wy + 10f, 1.2f, fa(tint));
        text(sub, vx, wy + 25f, 0.72f, fa(0xFF7C84A3));

        if (page != PAGE_MODULES) return;

        // search box
        float sw = Math.max(64f, Math.min(112f, vw - 104f));
        float sx2 = mainR - sw, sy2 = wy + 9f;
        boolean hov = mx >= sx2 && mx <= sx2 + sw && my >= sy2 && my <= sy2 + 14f;
        int sb = searchFocused ? Colors.withAlpha(th.c1, 230) : sf(0xFF262B52);
        RenderUtil.roundedRect(sx2, sy2, sx2 + sw, sy2 + 14f, 5f, fa(sb));
        RenderUtil.roundedRect(sx2 + 1f, sy2 + 1f, sx2 + sw - 1f, sy2 + 13f, 4f, fa(hov ? sf(0xFF181B3B) : sf(0xFF14173A)));
        RenderUtil.circle(sx2 + 8f, sy2 + 6.5f, 2.6f, fa(0xFF6D7497));
        RenderUtil.circle(sx2 + 8f, sy2 + 6.5f, 1.4f, fa(hov ? sf(0xFF181B3B) : sf(0xFF14173A)));
        String shown;
        int col;
        if (search.length() == 0 && !searchFocused) {
            shown = "Search modules";
            col = 0xFF6D7497;
        } else {
            shown = search;
            col = 0xFFE8ECF4;
            if (searchFocused && (now / 450L) % 2L == 0L) shown = shown + "_";
        }
        // keep the end of long queries visible
        while (shown.length() > 1 && textW(shown, 0.8f) > sw - 20f) shown = shown.substring(1);
        text(shown, sx2 + 14f, sy2 + 3.5f, 0.8f, fa(col));
        addHit(HIT_SEARCH, sx2, sy2, sw, 14f);

        // list / grid toggle
        float bx = mainR - 2f * 15f - 2f, by = wy + 28f;
        for (int i = 0; i < 2; i++) {
            float x = bx + i * 17f;
            boolean sel = (i == 1) == gridView;
            boolean h2 = mx >= x && mx <= x + 15f && my >= by && my <= by + 13f;
            RenderUtil.roundedRect(x, by, x + 15f, by + 13f, 4f,
                    fa(sel ? Colors.withAlpha(th.c1, 120) : (h2 ? sf(0xFF22264D) : sf(0xFF181B3B))));
            int ic = fa(sel ? 0xFFFFFFFF : 0xFF8E96B8);
            if (i == 0) {
                for (int l = 0; l < 3; l++) RenderUtil.rect(x + 4f, by + 3.5f + l * 2.6f, x + 11f, by + 4.5f + l * 2.6f, ic);
            } else {
                for (int gx = 0; gx < 2; gx++) {
                    for (int gy = 0; gy < 2; gy++) {
                        float qx = x + 4f + gx * 3.8f, qy = by + 3.2f + gy * 3.4f;
                        RenderUtil.rect(qx, qy, qx + 2.8f, qy + 2.6f, ic);
                    }
                }
            }
            addHit(HIT_VIEW, x, by, 15f, 13f).arg = i;
        }
    }

    // ---- pages ----------------------------------------------------------------------------------

    private float drawModulesPage(float top, float mx, float my) {
        List<Module> mods = visibleModules();
        int cols = gridView ? 2 : 1;
        float cardW = (vw - SCROLL_PAD - ROW_GAP * (cols - 1)) / cols;
        float y = top + 1f;
        if (mods.isEmpty()) {
            strC("No modules found", vx + vw / 2f, vy + 24f, fa(0xFF6D7497));
            return 0f;
        }
        for (int i = 0; i < mods.size(); i += cols) {
            float rowH = 0f;
            for (int c = 0; c < cols && i + c < mods.size(); c++) {
                rowH = Math.max(rowH, moduleHeight(mods.get(i + c)));
            }
            if (y + rowH >= vy && y <= vy + vh) {
                for (int c = 0; c < cols && i + c < mods.size(); c++) {
                    drawCard(mods.get(i + c), vx + c * (cardW + ROW_GAP), y, cardW, mx, my);
                }
            }
            y += rowH + ROW_GAP;
        }
        return y - top;
    }

    private void drawCard(Module m, float x, float y, float w, float mx, float my) {
        Theme th = Theme.current();
        float h = moduleHeight(m);
        float tg = m.toggleAnim;
        boolean hov = inViewport(mx, my) && mx >= x && mx <= x + w && my >= y && my < y + CARD_H;

        int bodyBase = Colors.lerp(sf(0xFF14173A), sf(0xFF1B1F46), hov ? 1f : 0f);
        int body = Colors.lerp(bodyBase, Colors.opaque(th.c3), 0.12f * tg);
        int border = Colors.lerp(sf(0xFF23274D), Colors.opaque(th.c1), 0.55f * tg);
        RenderUtil.roundedRect(x, y, x + w, y + h, 6f, fa(border));
        RenderUtil.roundedRect(x + 1f, y + 1f, x + w - 1f, y + h - 1f, 5f, fa(body));

        float textMax = w - 9f - 62f;
        text(trim(m.name, textMax, 0.95f), x + 9f, y + 6.5f, 0.95f,
                fa(Colors.lerp(0xFFD5D9E8, 0xFFFFFFFF, tg)));
        text(trim(m.description, textMax, 0.68f), x + 9f, y + 18.5f, 0.68f, fa(0xFF7C84A3));

        // arrow (expands settings)
        RenderUtil.triangle(x + w - 41f, y + CARD_H / 2f, 2.8f, 90f * m.expandAnim, fa(0xFFA2AAC9));

        // switch
        float tx = x + w - 30f, ty = y + (CARD_H - 11f) / 2f;
        drawSwitch(tx, ty, tg);

        Hit hit = addHit(HIT_CARD, x, y, w, CARD_H);
        hit.module = m;

        float setH = settingsHeight(m);
        if (m.expandAnim > 0.005f) {
            float areaH = setH * m.expandAnim;
            float sy = y + CARD_H;
            clipTo(x + 1f, sy, w - 2f, areaH);
            RenderUtil.rect(x + 8f, sy, x + w - 8f, sy + 1f, fa(0x22FFFFFF));
            boolean interactive = m.expandAnim > 0.97f && !closing;
            float ry = sy + 5f;
            for (Setting s : m.settings) {
                drawSetting(s, m, x + 10f, ry, w - 20f, interactive);
                ry += s.height();
            }
            drawBind(m, x + 10f, ry, w - 20f, interactive);
            viewClip();
        }
    }

    private void drawSwitch(float tx, float ty, float on) {
        Theme th = Theme.current();
        RenderUtil.roundedRectH(tx, ty, tx + 22f, ty + 11f, 5.5f,
                fa(Colors.lerp(sf(0xFF2B2F55), Colors.opaque(th.c1), on)),
                fa(Colors.lerp(sf(0xFF2B2F55), Colors.opaque(th.c2), on)));
        RenderUtil.circle(tx + 5.5f + 11f * on, ty + 5.5f, 4f, fa(0xFFFFFFFF));
    }

    private void drawSetting(Setting s, Module m, float x, float y, float w, boolean interactive) {
        Theme th = Theme.current();
        int label = fa(0xFFC3C9D6);
        float step = Math.min(1f, dtNow * 16f);

        if (s instanceof BooleanSetting) {
            BooleanSetting b = (BooleanSetting) s;
            b.anim += ((b.value ? 1f : 0f) - b.anim) * step;
            str(b.name, x, y + 3f, label);
            float tx = x + w - 16f, ty = y + 3f;
            RenderUtil.roundedRect(tx, ty, tx + 16f, ty + 8f, 4f,
                    fa(Colors.lerp(0xFF3A4052, Colors.opaque(th.c1), b.anim)));
            float kx = tx + 1f + 8f * b.anim;
            RenderUtil.roundedRect(kx, ty + 1f, kx + 6f, ty + 7f, 3f, fa(0xFFFFFFFF));
            if (interactive) {
                Hit h = addHit(HIT_BOOL, x - 2f, y, w + 4f, 14f);
                h.module = m;
                h.setting = s;
            }
        } else if (s instanceof ModeSetting) {
            ModeSetting ms = (ModeSetting) s;
            str(ms.name, x, y + 3f, label);
            String v = ms.get();
            str(v, x + w - LumenFont.width(v), y + 3f, fa(Colors.opaque(th.c1)));
            if (interactive) {
                Hit h = addHit(HIT_MODE, x - 2f, y, w + 4f, 14f);
                h.module = m;
                h.setting = s;
            }
        } else if (s instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) s;
            str(ns.name, x, y + 2f, label);
            String v = ns.display();
            str(v, x + w - LumenFont.width(v), y + 2f, fa(Colors.opaque(th.c1)));
            float fw = Math.max(3f, w * (float) ns.fraction());
            RenderUtil.roundedRect(x, y + 13f, x + w, y + 16f, 1.5f, fa(0x55FFFFFF));
            RenderUtil.roundedRectH(x, y + 13f, x + fw, y + 16f, 1.5f,
                    fa(Colors.opaque(th.c1)), fa(Colors.opaque(th.c2)));
            RenderUtil.circle(x + fw, y + 14.5f, 3.2f, fa(0xFFFFFFFF));
            if (interactive) {
                Hit h = addHit(HIT_NUMBER, x - 2f, y + 8f, w + 4f, 11f);
                h.module = m;
                h.setting = s;
                h.trackX = x;
                h.trackW = w;
            }
        }
    }

    private String keyName(Module m) {
        if (binding == m) return "press a key...";
        if (m.key == Keyboard.KEY_NONE) return "None";
        String name = Keyboard.getKeyName(m.key);
        return name == null ? "?" : name;
    }

    private void drawBind(Module m, float x, float y, float w, boolean interactive) {
        Theme th = Theme.current();
        str("Bind", x, y + 3f, fa(0xFFC3C9D6));
        String v = keyName(m);
        str(v, x + w - LumenFont.width(v), y + 3f, fa(Colors.opaque(th.c1)));
        if (interactive) {
            Hit h = addHit(HIT_BIND, x - 2f, y, w + 4f, BIND_H);
            h.module = m;
        }
    }

    private float drawSettingsPage(float top, float mx, float my) {
        float w = vw - SCROLL_PAD;
        float y = top + 1f;
        toggleRow("Aurora background", "Animated colour ribbons behind the menu", auroraAnim, vx, y, w, mx, my, HIT_AURORA);
        y += CARD_H + ROW_GAP;
        toggleRow("UI sounds", "Click sounds while using the menu", soundsAnim, vx, y, w, mx, my, HIT_SOUNDS);
        y += CARD_H + ROW_GAP;
        fontRow(vx, y, w, mx, my);
        y += CARD_H + ROW_GAP;
        return y - top;
    }

    /** "Font" card: shows the current ClickGUI font; click = next, right-click = previous. */
    private void fontRow(float x, float y, float w, float mx, float my) {
        Theme th = Theme.current();
        boolean hov = inViewport(mx, my) && mx >= x && mx <= x + w && my >= y && my < y + CARD_H;
        RenderUtil.roundedRect(x, y, x + w, y + CARD_H, 6f, fa(sf(0xFF23274D)));
        RenderUtil.roundedRect(x + 1f, y + 1f, x + w - 1f, y + CARD_H - 1f, 5f, fa(hov ? sf(0xFF1B1F46) : sf(0xFF14173A)));
        text("Font", x + 9f, y + 6.5f, 0.95f, fa(0xFFD5D9E8));
        text(trim("Font of the menu (click to cycle). HUD keeps the vanilla font", w - 9f - 70f, 0.68f),
                x + 9f, y + 18.5f, 0.68f, fa(0xFF7C84A3));
        String v = ClientSettings.font;
        text(v, x + w - 9f - textW(v, 0.95f), y + 6.5f, 0.95f, fa(Colors.opaque(th.c1)));
        addHit(HIT_FONT, x, y, w, CARD_H);
    }

    private void toggleRow(String name, String desc, float on, float x, float y, float w, float mx, float my, int hitType) {
        Theme th = Theme.current();
        boolean hov = inViewport(mx, my) && mx >= x && mx <= x + w && my >= y && my < y + CARD_H;
        int bodyBase = Colors.lerp(sf(0xFF14173A), sf(0xFF1B1F46), hov ? 1f : 0f);
        RenderUtil.roundedRect(x, y, x + w, y + CARD_H, 6f, fa(Colors.lerp(sf(0xFF23274D), Colors.opaque(th.c1), 0.55f * on)));
        RenderUtil.roundedRect(x + 1f, y + 1f, x + w - 1f, y + CARD_H - 1f, 5f,
                fa(Colors.lerp(bodyBase, Colors.opaque(th.c3), 0.12f * on)));
        text(name, x + 9f, y + 6.5f, 0.95f, fa(Colors.lerp(0xFFD5D9E8, 0xFFFFFFFF, on)));
        text(trim(desc, w - 9f - 40f, 0.68f), x + 9f, y + 18.5f, 0.68f, fa(0xFF7C84A3));
        drawSwitch(x + w - 30f, y + (CARD_H - 11f) / 2f, on);
        addHit(hitType, x, y, w, CARD_H);
    }

    private float drawThemePage(float top, float mx, float my) {
        List<Theme> all = Theme.ALL;
        float gap = ROW_GAP;
        float cw = (vw - SCROLL_PAD - gap) / 2f;
        float ch = 30f;
        float y = top + 1f;
        for (int i = 0; i < all.size(); i += 2) {
            for (int c = 0; c < 2 && i + c < all.size(); c++) {
                int idx = i + c;
                Theme t = all.get(idx);
                float x = vx + c * (cw + gap);
                boolean sel = idx == Theme.index();
                boolean hov = inViewport(mx, my) && mx >= x && mx <= x + cw && my >= y && my < y + ch;
                Theme cur = Theme.current();
                RenderUtil.roundedRect(x, y, x + cw, y + ch, 6f, fa(sel ? Colors.opaque(cur.c1) : sf(0xFF23274D)));
                RenderUtil.roundedRect(x + 1f, y + 1f, x + cw - 1f, y + ch - 1f, 5f,
                        fa(hov ? sf(0xFF1B1F46) : sf(0xFF14173A)));
                // 3-colour swatch
                float sx = x + 8f, sy = y + 8f, sw = 30f, sh = 14f;
                RenderUtil.gradientH(sx, sy, sx + sw / 2f, sy + sh, fa(Colors.opaque(t.c1)), fa(Colors.opaque(t.c2)));
                RenderUtil.gradientH(sx + sw / 2f, sy, sx + sw, sy + sh, fa(Colors.opaque(t.c2)), fa(Colors.opaque(t.c3)));
                text(t.name, x + 46f, y + 11f, 0.95f, fa(sel ? 0xFFFFFFFF : 0xFFC3C9D6));
                if (sel) RenderUtil.circle(x + cw - 10f, y + ch / 2f, 2.6f, fa(Colors.opaque(cur.c1)));
                addHit(HIT_THEME, x, y, cw, ch).arg = idx;
            }
            y += ch + gap;
        }
        return y - top;
    }

    private float drawKeybindsPage(float top, float mx, float my) {
        Theme th = Theme.current();
        float w = vw - SCROLL_PAD;
        float rh = 22f;
        float y = top + 1f;
        for (Module m : ModuleManager.modules) {
            boolean hov = inViewport(mx, my) && mx >= vx && mx <= vx + w && my >= y && my < y + rh;
            boolean act = binding == m;
            RenderUtil.roundedRect(vx, y, vx + w, y + rh, 6f, fa(act ? Colors.opaque(th.c1) : sf(0xFF23274D)));
            RenderUtil.roundedRect(vx + 1f, y + 1f, vx + w - 1f, y + rh - 1f, 5f, fa(hov ? sf(0xFF1B1F46) : sf(0xFF14173A)));
            text(m.name, vx + 9f, y + 6.5f, 0.95f, fa(0xFFD5D9E8));
            String cat = m.category.label;
            text(cat, vx + 9f + textW(m.name, 0.95f) + 6f, y + 8f, 0.65f, fa(0xFF6D7497));
            String v = keyName(m);
            float kw = textW(v, 0.85f) + 12f;
            float kx = vx + w - kw - 6f;
            RenderUtil.roundedRect(kx, y + 4f, kx + kw, y + rh - 4f, 4f,
                    fa(act ? Colors.withAlpha(th.c1, 120) : sf(0xFF262B52)));
            text(v, kx + 6f, y + 7.5f, 0.85f, fa(act ? 0xFFFFFFFF : Colors.opaque(th.c1)));
            addHit(HIT_BIND, vx, y, w, rh).module = m;
            y += rh + 4f;
        }
        return y - top;
    }

    private void drawScrollbar() {
        float max = maxScroll();
        if (max <= 0.5f) return;
        Theme th = Theme.current();
        float trackH = vh - 4f;
        float barH = Math.max(14f, trackH * vh / (vh + max));
        float barY = vy + 2f + (trackH - barH) * (scroll / max);
        float bx = vx + vw - 3f;
        RenderUtil.roundedRect(bx, vy + 2f, bx + 2f, vy + 2f + trackH, 1f, fa(0x22FFFFFF));
        RenderUtil.roundedRect(bx, barY, bx + 2f, barY + barH, 1f, fa(Colors.withAlpha(th.c1, 200)));
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    private Hit findHit(float mx, float my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (h.content && !inViewport(mx, my)) continue;
            return h;
        }
        return null;
    }

    @Override
    public void handleMouseInput() throws IOException {
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0 && !closing) {
            targetScroll = Math.max(0f, Math.min(maxScroll(), targetScroll - Integer.signum(wheel) * 24f));
        }
        super.handleMouseInput();
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (closing) return;
        if (binding != null) {
            binding = null; // clicking elsewhere cancels key binding
        }
        searchFocused = false;
        pressHit = null;
        pressActive = false;
        dragScrolling = false;

        if (button == 0 && mc.theWorld != null && HudEditor.overButton(height, mouseX, mouseY)) {
            Sounds.click();
            mc.displayGuiScreen(new HudEditor());
            return;
        }

        final float mx = mouseX / ui, my = mouseY / ui;
        Hit hit = findHit(mx, my);
        if (hit == null) {
            return;
        }

        switch (hit.type) {
            case HIT_BG:
                break;
            case HIT_CAT:
                if (button == 0) {
                    page = PAGE_MODULES;
                    catIndex = hit.arg;
                    search = "";
                    resetScroll();
                    Sounds.click();
                }
                return;
            case HIT_PAGE:
                if (button == 0) {
                    page = hit.arg;
                    resetScroll();
                    Sounds.click();
                }
                return;
            case HIT_SEARCH:
                searchFocused = true;
                Sounds.click();
                return;
            case HIT_VIEW:
                gridView = hit.arg == 1;
                resetScroll();
                Sounds.click();
                return;
            case HIT_NUMBER:
                if (button == 0) {
                    draggingSlider = hit.setting;
                    sliderX = hit.trackX;
                    sliderW = hit.trackW;
                    NumberSetting ns = (NumberSetting) hit.setting;
                    double f = Math.max(0.0, Math.min(1.0, (mx - sliderX) / sliderW));
                    ns.set(ns.min + f * (ns.max - ns.min));
                    Sounds.click();
                }
                return;
            default:
                break;
        }

        // everything else lives in the scrolling area: act on release, unless the finger/mouse dragged
        if (inViewport(mx, my)) {
            pressActive = true;
            pressY = mouseY;
            pressButton = button;
            pressScroll = targetScroll;
            if (hit.type != HIT_BG) pressHit = hit;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (!pressActive || closing) return;
        if (!dragScrolling && Math.abs(mouseY - pressY) > 4) {
            dragScrolling = true;
        }
        if (dragScrolling) {
            float max = maxScroll();
            targetScroll = Math.max(0f, Math.min(max, pressScroll - (mouseY - pressY) / ui));
            scroll = targetScroll;
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        if (pressActive && !dragScrolling && pressHit != null && !closing) {
            Hit hit = pressHit;
            // only fire if the pointer is still over the thing that was pressed
            float mx = mouseX / ui, my = mouseY / ui;
            if (hit.contains(mx, my) && inViewport(mx, my)) {
                performHit(hit, pressButton, mx);
            }
        }
        pressActive = false;
        dragScrolling = false;
        pressHit = null;
    }

    private void performHit(Hit hit, int button, float mouseX) {
        switch (hit.type) {
            case HIT_CARD:
                if (button == 0 && mouseX >= hit.x + hit.w - 34f) {
                    hit.module.toggle();
                    Sounds.toggle(hit.module.isEnabled());
                } else if (button == 1 || (button == 0 && mouseX >= hit.x + hit.w - 56f)) {
                    // right-click, or a tap on the arrow, expands the settings
                    hit.module.expanded = !hit.module.expanded;
                    Sounds.expand(hit.module.expanded);
                } else if (button == 0) {
                    hit.module.toggle();
                    Sounds.toggle(hit.module.isEnabled());
                }
                break;
            case HIT_BOOL:
                ((BooleanSetting) hit.setting).toggle();
                Sounds.click();
                break;
            case HIT_MODE:
                ((ModeSetting) hit.setting).cycle(button == 1 ? -1 : 1);
                Sounds.click();
                break;
            case HIT_BIND:
                binding = hit.module;
                Sounds.click();
                break;
            case HIT_THEME:
                Theme.set(hit.arg);
                Sounds.theme(hit.arg);
                break;
            case HIT_AURORA:
                ClientSettings.aurora = !ClientSettings.aurora;
                Sounds.click();
                break;
            case HIT_SOUNDS:
                ClientSettings.sounds = !ClientSettings.sounds;
                Sounds.click();
                break;
            case HIT_FONT:
                ClientSettings.cycleFont(button == 1 ? -1 : 1);
                Sounds.click();
                break;
            default:
                break;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (closing) return;
        if (binding != null) {
            boolean clear = keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_BACK || keyCode == Keyboard.KEY_DELETE;
            binding.key = clear ? Keyboard.KEY_NONE : keyCode;
            binding = null;
            Sounds.click();
            return;
        }
        if (searchFocused) {
            if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_RETURN) {
                searchFocused = false;
            } else if (keyCode == Keyboard.KEY_BACK) {
                if (search.length() > 0) {
                    search = search.substring(0, search.length() - 1);
                    resetScroll();
                }
            } else if (typedChar >= 32 && typedChar != 127 && search.length() < 24) {
                search = search + typedChar;
                resetScroll();
            }
            return;
        }
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == LumenClient.openGuiKey.getKeyCode()) {
            beginClose();
        }
    }
}
