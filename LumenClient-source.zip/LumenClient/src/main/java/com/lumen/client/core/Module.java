package com.lumen.client.core;

import net.minecraft.client.Minecraft;
import com.lumen.client.util.Events;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class of every feature. A module is registered on the Forge event bus
 * while it is enabled, so its @SubscribeEvent methods only run when it's on.
 */
public abstract class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();

    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<Setting>();
    public int key = Keyboard.KEY_NONE;

    // ClickGUI state
    public boolean expanded;
    public float expandAnim;
    public float toggleAnim;
    public float hoverAnim;

    private boolean enabled;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Non-null = this module can't be used right now (the text says why). */
    public String lockReason() {
        return null;
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        if (value && lockReason() != null) {
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new net.minecraft.util.ChatComponentText("\u00a7b[Lumen] \u00a7c" + name + " is disabled here."));
            }
            return;
        }
        enabled = value;
        com.lumen.client.gui.CutePicture.bob();
        if (value) {
            Events.register(this);
            onEnable();
        } else {
            Events.unregister(this);
            onDisable();
        }
    }

    protected void onEnable() {}

    protected void onDisable() {}
}
