package com.lumen.client.core;

public enum Category {
    HUD("HUD"),
    COMBAT("Combat"),
    VISUALS("Visuals"),
    SETTINGS("Settings");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
