package com.lumen.client.core;

public enum Category {
    HUD("HUD"),
    COMBAT("Combat"),
    VISUALS("Visuals"),
    CLIENT("Client");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
