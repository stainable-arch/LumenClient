package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.gui.LumenFont;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Client-wide GUI options. Currently: the font used by the ClickGUI and all HUD elements.
 * While the module is off the client uses its default font (Winkle).
 */
public class GuiModule extends Module {
    public final ModeSetting font = add(new ModeSetting("Font", "Winkle", LumenFont.FACES));

    public GuiModule() {
        super("GUI", "Change the font used by the ClickGUI and the HUD.", Category.SETTINGS);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) apply();
    }

    private void apply() {
        LumenFont.setFace(font.get());
    }

    @Override
    protected void onEnable() {
        apply();
    }

    @Override
    protected void onDisable() {
        LumenFont.setFace("Winkle");
    }
}
