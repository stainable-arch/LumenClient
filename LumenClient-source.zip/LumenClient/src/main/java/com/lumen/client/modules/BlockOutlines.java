package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/** Changes the width of the vanilla block-selection outline. */
public class BlockOutlines extends Module {
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 1, 1, 20, 1));
    private float oldWidth = 1f;

    public BlockOutlines() {
        super("Block Outlines", "Adjusts the thickness of the targeted block outline.", Category.VISUALS);
    }

    @SubscribeEvent
    public void onBlockHighlight(DrawBlockHighlightEvent e) {
        oldWidth = GL11.glGetFloat(GL11.GL_LINE_WIDTH);
        GL11.glLineWidth(thickness.getFloat());
    }

    @Override
    protected void onDisable() {
        GL11.glLineWidth(1f);
    }
}
