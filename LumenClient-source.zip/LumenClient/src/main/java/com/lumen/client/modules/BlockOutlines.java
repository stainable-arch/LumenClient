package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Replaces the vanilla black block outline with a custom one: thickness 1-10 and any colour.
 *
 * Wide GL lines are capped to 1px on many GPUs / mobile GL wrappers, so the outline is drawn as
 * real geometry (12 thin bars along the block's edges) instead of glLineWidth. The bar width
 * grows with distance, so the on-screen thickness stays about the same wherever you look.
 */
public class BlockOutlines extends Module {
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 3, 1, 10, 1));
    private final ModeSetting colorMode = add(new ModeSetting("Color", "Custom", "Custom", "Theme", "Rainbow"));
    private final NumberSetting red = add(new NumberSetting("Red", 255, 0, 255, 5));
    private final NumberSetting green = add(new NumberSetting("Green", 255, 0, 255, 5));
    private final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 5));
    private final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 5));

    public BlockOutlines() {
        super("Block Outlines", "Custom outline around the block you look at: thickness 1-10 and colour.", Category.VISUALS);
    }

    private int currentColor() {
        if (colorMode.is("Rainbow")) {
            return Colors.hsb((System.currentTimeMillis() % 4000L) / 4000f, 0.75f, 1f);
        }
        if (colorMode.is("Theme")) {
            return Colors.gradient(Theme.current(), (System.currentTimeMillis() % 4000L) / 4000f);
        }
        return Colors.opaque((red.getInt() << 16) | (green.getInt() << 8) | blue.getInt());
    }

    @SubscribeEvent
    public void onDrawHighlight(DrawBlockHighlightEvent e) {
        MovingObjectPosition mop = e.target;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || e.subID != 0) return;
        if (mc.theWorld == null) return;

        BlockPos pos = mop.getBlockPos();
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block.getMaterial() == Material.air || !mc.theWorld.getWorldBorder().contains(pos)) return;

        // we draw the outline ourselves, so hide the vanilla one
        e.setCanceled(true);

        block.setBlockBoundsBasedOnState(mc.theWorld, pos);
        Entity view = e.player;
        double px = view.lastTickPosX + (view.posX - view.lastTickPosX) * e.partialTicks;
        double py = view.lastTickPosY + (view.posY - view.lastTickPosY) * e.partialTicks;
        double pz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * e.partialTicks;
        AxisAlignedBB box = block.getSelectedBoundingBox(mc.theWorld, pos).offset(-px, -py, -pz);

        // distance from the camera to the box centre, used to keep the bars a steady screen size
        double cx = (box.minX + box.maxX) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
        double w = thickness.value * (0.0025 + 0.0022 * dist);
        w = Math.min(w, 0.15);

        int color = currentColor();
        int a = (int) (255 * opacity.value / 100.0);

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableTexture2D();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);

        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        drawFrame(wr, box, w, Colors.channel(color, 16), Colors.channel(color, 8), Colors.channel(color, 0), a);
        t.draw();

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** 12 bars, one per edge. Each bar sits just outside the block so the full width is visible. */
    private static void drawFrame(WorldRenderer wr, AxisAlignedBB b, double w, int r, int g, int bl, int a) {
        double[] lo = { b.minX, b.minY, b.minZ };
        double[] hi = { b.maxX, b.maxY, b.maxZ };
        for (int axis = 0; axis < 3; axis++) {
            int o1 = (axis + 1) % 3;
            int o2 = (axis + 2) % 3;
            for (int s1 = 0; s1 < 2; s1++) {
                for (int s2 = 0; s2 < 2; s2++) {
                    double[] mn = new double[3];
                    double[] mx = new double[3];
                    // along the edge: stretch by w so the corners are filled in
                    mn[axis] = lo[axis] - w;
                    mx[axis] = hi[axis] + w;
                    if (s1 == 0) { mn[o1] = lo[o1] - w; mx[o1] = lo[o1]; }
                    else         { mn[o1] = hi[o1];     mx[o1] = hi[o1] + w; }
                    if (s2 == 0) { mn[o2] = lo[o2] - w; mx[o2] = lo[o2]; }
                    else         { mn[o2] = hi[o2];     mx[o2] = hi[o2] + w; }
                    cuboid(wr, mn[0], mn[1], mn[2], mx[0], mx[1], mx[2], r, g, bl, a);
                }
            }
        }
    }

    private static void cuboid(WorldRenderer wr, double x1, double y1, double z1, double x2, double y2, double z2,
                               int r, int g, int b, int a) {
        // bottom
        v(wr, x1, y1, z1, r, g, b, a); v(wr, x2, y1, z1, r, g, b, a); v(wr, x2, y1, z2, r, g, b, a); v(wr, x1, y1, z2, r, g, b, a);
        // top
        v(wr, x1, y2, z1, r, g, b, a); v(wr, x1, y2, z2, r, g, b, a); v(wr, x2, y2, z2, r, g, b, a); v(wr, x2, y2, z1, r, g, b, a);
        // north
        v(wr, x1, y1, z1, r, g, b, a); v(wr, x1, y2, z1, r, g, b, a); v(wr, x2, y2, z1, r, g, b, a); v(wr, x2, y1, z1, r, g, b, a);
        // south
        v(wr, x1, y1, z2, r, g, b, a); v(wr, x2, y1, z2, r, g, b, a); v(wr, x2, y2, z2, r, g, b, a); v(wr, x1, y2, z2, r, g, b, a);
        // west
        v(wr, x1, y1, z1, r, g, b, a); v(wr, x1, y1, z2, r, g, b, a); v(wr, x1, y2, z2, r, g, b, a); v(wr, x1, y2, z1, r, g, b, a);
        // east
        v(wr, x2, y1, z1, r, g, b, a); v(wr, x2, y2, z1, r, g, b, a); v(wr, x2, y2, z2, r, g, b, a); v(wr, x2, y1, z2, r, g, b, a);
    }

    private static void v(WorldRenderer wr, double x, double y, double z, int r, int g, int b, int a) {
        wr.pos(x, y, z).color(r, g, b, a).endVertex();
    }
}
