package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * Replaces the vanilla black block outline with a custom one: thickness 1-10 and any colour.
 *
 * Wide GL lines are capped to 1px on many GPUs / mobile GL wrappers, so the outline is drawn as
 * real geometry (flat frames on the block's faces) instead of glLineWidth. The frame width
 * grows with distance, so the on-screen thickness stays about the same wherever you look.
 */
public class BlockOutlines extends Module {
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 3, 1, 10, 1));
    private final ModeSetting colorMode = add(new ModeSetting("Color", "Custom", "Custom", "Theme", "Rainbow"));
    private final NumberSetting red = add(new NumberSetting("Red", 255, 0, 255, 5));
    private final NumberSetting green = add(new NumberSetting("Green", 255, 0, 255, 5));
    private final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 5));
    private final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 5));

    public BlockOutlines() {
        super("Block Outlines", "Custom outline around the block you look at: thickness 1-10 and colour.", Category.VISUALS);
    }

    private int currentColor() {
        if (colorMode.is("Rainbow")) {
            return Colors.hsb((System.currentTimeMillis() % 4000L) / 4000f, 0.75f, 1f);
        }
        if (colorMode.is("Theme")) {
            return Colors.gradient(Theme.current(), (System.currentTimeMillis() % 4000L) / 4000f);
        }
        return Colors.opaque((red.getInt() << 16) | (green.getInt() << 8) | blue.getInt());
    }

    @SubscribeEvent
    public void onDrawHighlight(DrawBlockHighlightEvent e) {
        MovingObjectPosition mop = e.target;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || e.subID != 0) return;
        if (mc.theWorld == null) return;

        BlockPos pos = mop.getBlockPos();
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block.getMaterial() == Material.air || !mc.theWorld.getWorldBorder().contains(pos)) return;

        // we draw the outline ourselves, so hide the vanilla one
        e.setCanceled(true);

        block.setBlockBoundsBasedOnState(mc.theWorld, pos);
        Entity view = e.player;
        double px = view.lastTickPosX + (view.posX - view.lastTickPosX) * e.partialTicks;
        double py = view.lastTickPosY + (view.posY - view.lastTickPosY) * e.partialTicks;
        double pz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * e.partialTicks;
        AxisAlignedBB box = block.getSelectedBoundingBox(mc.theWorld, pos).offset(-px, -py, -pz);

        // distance from the camera to the box centre, used to keep the bars a steady screen size
        double cx = (box.minX + box.maxX) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
        double w = thickness.value * (0.0025 + 0.0022 * dist);
        w = Math.min(w, 0.15);
        double eps = 0.003 + 0.0012 * dist;

        int color = currentColor();
        int a = (int) (255 * opacity.value / 100.0);

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableTexture2D();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
        GL11.glPolygonOffset(-2f, -4f);

        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        drawFrame(wr, box, w, eps, Colors.channel(color, 16), Colors.channel(color, 8), Colors.channel(color, 0), a);
        t.draw();

        GL11.glPolygonOffset(0f, 0f);
        GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /**
     * Draws a flat frame on each of the 6 faces. The frames lie just outside the block's surface and
     * grow inwards, so nothing pokes into neighbouring blocks (that is what caused z-fighting).
     */
    private static void drawFrame(WorldRenderer wr, AxisAlignedBB b, double w, double eps, int r, int g, int bl, int a) {
        double[] lo = { b.minX, b.minY, b.minZ };
        double[] hi = { b.maxX, b.maxY, b.maxZ };
        for (int axis = 0; axis < 3; axis++) {
            int u = (axis + 1) % 3;
            int v = (axis + 2) % 3;
            // keep the border from being wider than the face itself
            double fw = Math.min(w, 0.45 * Math.min(hi[u] - lo[u], hi[v] - lo[v]));
            for (int side = 0; side < 2; side++) {
                double p = side == 0 ? lo[axis] - eps : hi[axis] + eps;
                // two strips along v (full height) ...
                face(wr, axis, u, v, p, lo[u], lo[v], lo[u] + fw, hi[v], r, g, bl, a);
                face(wr, axis, u, v, p, hi[u] - fw, lo[v], hi[u], hi[v], r, g, bl, a);
                // ... and two strips along u (between them)
                face(wr, axis, u, v, p, lo[u] + fw, lo[v], hi[u] - fw, lo[v] + fw, r, g, bl, a);
                face(wr, axis, u, v, p, lo[u] + fw, hi[v] - fw, hi[u] - fw, hi[v], r, g, bl, a);
            }
        }
    }

    /** One flat rectangle in the plane (axis = p), spanning u0..u1 and v0..v1. */
    private static void face(WorldRenderer wr, int axis, int u, int v, double p,
                             double u0, double v0, double u1, double v1, int r, int g, int b, int a) {
        vert(wr, axis, u, v, p, u0, v0, r, g, b, a);
        vert(wr, axis, u, v, p, u1, v0, r, g, b, a);
        vert(wr, axis, u, v, p, u1, v1, r, g, b, a);
        vert(wr, axis, u, v, p, u0, v1, r, g, b, a);
    }

    private static void vert(WorldRenderer wr, int axis, int u, int v, double p, double pu, double pv,
                             int r, int g, int b, int a) {
        double[] c = new double[3];
        c[axis] = p;
        c[u] = pu;
        c[v] = pv;
        wr.pos(c[0], c[1], c[2]).color(r, g, b, a).endVertex();
    }
}
