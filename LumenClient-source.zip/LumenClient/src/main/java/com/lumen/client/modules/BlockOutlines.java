package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.ColorSetting;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Replaces the vanilla black block outline with a custom one: thickness 1-10 and any colour.
 *
 * Wide GL lines are capped to 1px on many GPUs / mobile GL wrappers, so the outline is drawn as
 * real geometry (12 edge bars) instead of glLineWidth. The bars are centred on the edges of the
 * block (inflated by a tiny epsilon to avoid z-fighting), so they hug the block with no gap and
 * stay visible next to blocks that touch the edge diagonally. The bar width grows with distance, so
 * the on-screen thickness stays about the same wherever you look.
 */
public class BlockOutlines extends Module {
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 3, 1, 10, 1));
    private final ModeSetting colorMode = add(new ModeSetting("Color", "Custom", "Custom", "Theme", "Rainbow"));
    private final ColorSetting customColor = add(new ColorSetting("Custom Color", 0xFFFFFF));
    private final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 5));

    public BlockOutlines() {
        super("Block Outlines", "Custom outline around the block you look at: thickness 1-10 and colour.", Category.VISUALS);
        customColor.showIf(() -> colorMode.is("Custom")); // the wheel is only needed for the Custom colour mode
    }

    private int currentColor() {
        if (colorMode.is("Rainbow")) {
            return Colors.hsb((System.currentTimeMillis() % 4000L) / 4000f, 0.75f, 1f);
        }
        if (colorMode.is("Theme")) {
            return Colors.gradient(Theme.current(), (System.currentTimeMillis() % 4000L) / 4000f);
        }
        return Colors.opaque(customColor.rgb());
    }

    @SubscribeEvent
    public void onDrawHighlight(DrawBlockHighlightEvent e) {
        MovingObjectPosition mop = e.target;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || e.subID != 0) return;
        if (mc.theWorld == null) return;

        BlockPos pos = mop.getBlockPos();
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block.getMaterial() == Material.air || !mc.theWorld.getWorldBorder().contains(pos)) return;

        // we draw the outline ourselves, so hide the vanilla one
        e.setCanceled(true);

        block.setBlockBoundsBasedOnState(mc.theWorld, pos);
        Entity view = e.player;
        double px = view.lastTickPosX + (view.posX - view.lastTickPosX) * e.partialTicks;
        double py = view.lastTickPosY + (view.posY - view.lastTickPosY) * e.partialTicks;
        double pz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * e.partialTicks;
        AxisAlignedBB box = block.getSelectedBoundingBox(mc.theWorld, pos).offset(-px, -py, -pz);

        // distance from the camera to the box centre, used to keep the bars a steady screen size
        double cx = (box.minX + box.maxX) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
        double w = thickness.value * (0.0025 + 0.0022 * dist);
        w = Math.min(w, 0.15);
        double eps = 0.002 + 0.0003 * dist;

        int color = currentColor();
        int a = (int) (255 * opacity.value / 100.0);

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableTexture2D();
        GlStateManager.enableCull();
        GlStateManager.disableAlpha(); // vanilla alpha test (>0.1) would hide very low opacities
        GlStateManager.depthMask(false);

        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        drawBars(wr, box, w, eps, Colors.channel(color, 16), Colors.channel(color, 8), Colors.channel(color, 0), a);
        t.draw();

        GlStateManager.depthMask(true);
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /**
     * Draws the 12 edges of the box as bars centred on the edges (box inflated by {@code eps}). The
     * x-aligned bars also cover the 8
     * corner cubes; the y/z bars stop at the corners, so no two bars overlap (clean with opacity < 100%).
     */
    private static void drawBars(WorldRenderer wr, AxisAlignedBB b, double w, double eps, int r, int g, int bl, int a) {
        // bars are CENTRED on each edge of the (slightly inflated) box, so they hug the block with no gap
        // and never sit in the space of a block that is diagonal to the edge (which hid them before)
        double h = w * 0.5;
        double[] lo = { b.minX - eps, b.minY - eps, b.minZ - eps };
        double[] hi = { b.maxX + eps, b.maxY + eps, b.maxZ + eps };
        double[] min = new double[3];
        double[] max = new double[3];
        for (int axis = 0; axis < 3; axis++) {
            int p = (axis + 1) % 3;
            int q = (axis + 2) % 3;
            // x bars include the corner cubes, y/z bars stop at them, so no two bars overlap
            double ext = axis == 0 ? h : -h;
            min[axis] = lo[axis] - ext;
            max[axis] = hi[axis] + ext;
            if (min[axis] >= max[axis]) continue;
            for (int sp = 0; sp < 2; sp++) {
                for (int sq = 0; sq < 2; sq++) {
                    double cp = sp == 0 ? lo[p] : hi[p];
                    double cq = sq == 0 ? lo[q] : hi[q];
                    min[p] = cp - h; max[p] = cp + h;
                    min[q] = cq - h; max[q] = cq + h;
                    box(wr, min, max, axis, axis == 0, r, g, bl, a);
                }
            }
        }
    }

    /** An axis-aligned box with outward-facing quads (for backface culling). The end caps along barAxis are optional. */
    private static void box(WorldRenderer wr, double[] min, double[] max, int barAxis, boolean caps,
                            int r, int g, int b, int a) {
        for (int axis = 0; axis < 3; axis++) {
            if (axis == barAxis && !caps) continue;
            int u = (axis + 1) % 3;
            int v = (axis + 2) % 3;
            for (int side = 0; side < 2; side++) {
                double p = side == 0 ? min[axis] : max[axis];
                face(wr, axis, u, v, p, min[u], min[v], max[u], max[v], side == 1, r, g, b, a);
            }
        }
    }

    /** One flat rectangle in the plane (axis = p). {@code positive} = normal points along +axis. */
    private static void face(WorldRenderer wr, int axis, int u, int v, double p,
                             double u0, double v0, double u1, double v1, boolean positive, int r, int g, int b, int a) {
        // (u, v, axis) is a cyclic permutation, so this order is counter-clockwise seen from +axis
        if (positive) {
            vert(wr, axis, u, v, p, u0, v0, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v0, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v1, r, g, b, a);
            vert(wr, axis, u, v, p, u0, v1, r, g, b, a);
        } else {
            vert(wr, axis, u, v, p, u0, v1, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v1, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v0, r, g, b, a);
            vert(wr, axis, u, v, p, u0, v0, r, g, b, a);
        }
    }

    private static void vert(WorldRenderer wr, int axis, int u, int v, double p, double pu, double pv,
                             int r, int g, int b, int a) {
        double[] c = new double[3];
        c[axis] = p;
        c[u] = pu;
        c[v] = pv;
        wr.pos(c[0], c[1], c[2]).color(r, g, b, a).endVertex();
    }
}
