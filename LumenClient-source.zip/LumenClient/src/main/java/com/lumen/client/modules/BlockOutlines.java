package com.lumen.client.modules;

import com.lumen.client.core.Category;
import com.lumen.client.core.ColorSetting;
import com.lumen.client.core.ModeSetting;
import com.lumen.client.core.Module;
import com.lumen.client.core.NumberSetting;
import com.lumen.client.gui.Theme;
import com.lumen.client.util.Colors;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Replaces the vanilla black block outline with a custom one: thickness 1-10 and any colour.
 *
 * Wide GL lines are capped to 1px on many GPUs / mobile GL wrappers, so the outline is drawn as
 * real geometry (12 edge bars) instead of glLineWidth. The bars sit entirely OUTSIDE the block,
 * separated from it by a tiny gap, so they never share a plane with the block or its neighbours
 * (no z-fighting) and never cover the block's own faces. The bar width grows with distance, so the
 * on-screen thickness stays about the same wherever you look.
 */
public class BlockOutlines extends Module {
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 3, 1, 10, 1));
    private final ModeSetting colorMode = add(new ModeSetting("Color", "Custom", "Custom", "Theme", "Rainbow"));
    private final ColorSetting customColor = add(new ColorSetting("Custom Color", 0xFFFFFF));
    private final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 5));

    public BlockOutlines() {
        super("Block Outlines", "Custom outline around the block you look at: thickness 1-10 and colour.", Category.VISUALS);
        customColor.showIf(() -> colorMode.is("Custom")); // the wheel is only needed for the Custom colour mode
    }

    private int currentColor() {
        if (colorMode.is("Rainbow")) {
            return Colors.hsb((System.currentTimeMillis() % 4000L) / 4000f, 0.75f, 1f);
        }
        if (colorMode.is("Theme")) {
            return Colors.gradient(Theme.current(), (System.currentTimeMillis() % 4000L) / 4000f);
        }
        return Colors.opaque(customColor.rgb());
    }

    @SubscribeEvent
    public void onDrawHighlight(DrawBlockHighlightEvent e) {
        MovingObjectPosition mop = e.target;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || e.subID != 0) return;
        if (mc.theWorld == null) return;

        BlockPos pos = mop.getBlockPos();
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block.getMaterial() == Material.air || !mc.theWorld.getWorldBorder().contains(pos)) return;

        // we draw the outline ourselves, so hide the vanilla one
        e.setCanceled(true);

        block.setBlockBoundsBasedOnState(mc.theWorld, pos);
        Entity view = e.player;
        double px = view.lastTickPosX + (view.posX - view.lastTickPosX) * e.partialTicks;
        double py = view.lastTickPosY + (view.posY - view.lastTickPosY) * e.partialTicks;
        double pz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * e.partialTicks;
        AxisAlignedBB box = block.getSelectedBoundingBox(mc.theWorld, pos).offset(-px, -py, -pz);

        // distance from the camera to the box centre, used to keep the bars a steady screen size
        double cx = (box.minX + box.maxX) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
        double w = thickness.value * (0.0025 + 0.0022 * dist);
        w = Math.min(w, 0.15);
        double eps = 0.003 + 0.0012 * dist;

        int color = currentColor();
        int a = (int) (255 * opacity.value / 100.0);

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableTexture2D();
        GlStateManager.enableCull();
        GlStateManager.depthMask(false);

        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        drawBars(wr, box, w, eps, Colors.channel(color, 16), Colors.channel(color, 8), Colors.channel(color, 0), a);
        t.draw();

        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /**
     * Draws the 12 edges of the box as bars lying completely outside it. Each bar starts {@code eps}
     * away from the block and extends {@code w} further out. The x-aligned bars also cover the 8
     * corner cubes; the y/z bars stop at the corners, so no two bars overlap (clean with opacity < 100%).
     */
    private static void drawBars(WorldRenderer wr, AxisAlignedBB b, double w, double eps, int r, int g, int bl, int a) {
        double[] lo = { b.minX, b.minY, b.minZ };
        double[] hi = { b.maxX, b.maxY, b.maxZ };
        double[] min = new double[3];
        double[] max = new double[3];
        for (int axis = 0; axis < 3; axis++) {
            int p = (axis + 1) % 3;
            int q = (axis + 2) % 3;
            // along the bar: x bars include the corner cubes, y/z bars stop at them
            double ext = axis == 0 ? eps + w : eps;
            min[axis] = lo[axis] - ext;
            max[axis] = hi[axis] + ext;
            for (int sp = 0; sp < 2; sp++) {
                for (int sq = 0; sq < 2; sq++) {
                    if (sp == 0) { min[p] = lo[p] - eps - w; max[p] = lo[p] - eps; }
                    else         { min[p] = hi[p] + eps;     max[p] = hi[p] + eps + w; }
                    if (sq == 0) { min[q] = lo[q] - eps - w; max[q] = lo[q] - eps; }
                    else         { min[q] = hi[q] + eps;     max[q] = hi[q] + eps + w; }
                    // the end caps of y/z bars touch other bars, so only x bars get them
                    box(wr, min, max, axis, axis == 0, r, g, bl, a);
                }
            }
        }
    }

    /** An axis-aligned box with outward-facing quads (for backface culling). The end caps along barAxis are optional. */
    private static void box(WorldRenderer wr, double[] min, double[] max, int barAxis, boolean caps,
                            int r, int g, int b, int a) {
        for (int axis = 0; axis < 3; axis++) {
            if (axis == barAxis && !caps) continue;
            int u = (axis + 1) % 3;
            int v = (axis + 2) % 3;
            for (int side = 0; side < 2; side++) {
                double p = side == 0 ? min[axis] : max[axis];
                face(wr, axis, u, v, p, min[u], min[v], max[u], max[v], side == 1, r, g, b, a);
            }
        }
    }

    /** One flat rectangle in the plane (axis = p). {@code positive} = normal points along +axis. */
    private static void face(WorldRenderer wr, int axis, int u, int v, double p,
                             double u0, double v0, double u1, double v1, boolean positive, int r, int g, int b, int a) {
        // (u, v, axis) is a cyclic permutation, so this order is counter-clockwise seen from +axis
        if (positive) {
            vert(wr, axis, u, v, p, u0, v0, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v0, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v1, r, g, b, a);
            vert(wr, axis, u, v, p, u0, v1, r, g, b, a);
        } else {
            vert(wr, axis, u, v, p, u0, v1, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v1, r, g, b, a);
            vert(wr, axis, u, v, p, u1, v0, r, g, b, a);
            vert(wr, axis, u, v, p, u0, v0, r, g, b, a);
        }
    }

    private static void vert(WorldRenderer wr, int axis, int u, int v, double p, double pu, double pv,
                             int r, int g, int b, int a) {
        double[] c = new double[3];
        c[axis] = p;
        c[u] = pu;
        c[v] = pv;
        wr.pos(c[0], c[1], c[2]).color(r, g, b, a).endVertex();
    }
}
