package com.lumen.client.util;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

/** Counts left/right mouse clicks of the last second (always active, shared by CPS Display and Keystrokes). */
public final class ClickCounter {
    public static final ClickCounter INSTANCE = new ClickCounter();

    private static final List<Long> LEFT = new ArrayList<Long>();
    private static final List<Long> RIGHT = new ArrayList<Long>();

    private ClickCounter() {}

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate || Minecraft.getMinecraft().currentScreen != null) return;
        long now = System.currentTimeMillis();
        if (e.button == 0) {
            LEFT.add(now);
        } else if (e.button == 1) {
            RIGHT.add(now);
        }
    }

    public static int cps(boolean left) {
        List<Long> list = left ? LEFT : RIGHT;
        long cutoff = System.currentTimeMillis() - 1000L;
        while (!list.isEmpty() && list.get(0) < cutoff) {
            list.remove(0);
        }
        return list.size();
    }
}
