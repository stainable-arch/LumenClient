package com.lumen.client.gui;

import com.lumen.client.util.Colors;
import com.lumen.client.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenAddServer;
import net.minecraft.client.gui.GuiScreenServerList;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerDetector;
import net.minecraft.client.network.OldServerPinger;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * Multiplayer server list in the look of {@link LumenMainMenu}: themed background, drifting
 * stripes, text-only rows and text-only actions. Uses the vanilla server list, pinger, LAN
 * detection and the vanilla add / edit / direct-connect screens, so saved servers are shared.
 */
public class LumenServerSelect extends GuiScreen implements GuiYesNoCallback {
    private static final String[] ACTIONS = { "Join", "Direct Connect", "Add", "Edit", "Delete", "Refresh", "Back" };
    private static final int A_JOIN = 0, A_DIRECT = 1, A_ADD = 2, A_EDIT = 3, A_DELETE = 4, A_REFRESH = 5, A_BACK = 6;
    private static final int PROTOCOL = 47; // Minecraft 1.8.x

    private static final ExecutorService PINGER = Executors.newFixedThreadPool(5, new ThreadFactory() {
        private int n;

        @Override
        public synchronized Thread newThread(Runnable r) {
            Thread t = new Thread(r, "Lumen Server Pinger #" + (n++));
            t.setDaemon(true);
            return t;
        }
    });

    private static final ResourceLocation UNKNOWN_ICON = new ResourceLocation("textures/misc/unknown_server.png");
    private static int iconCounter;

    /** A server's favicon uploaded as a GL texture, together with the data it was made from. */
    private static final class Icon {
        final ResourceLocation loc = new ResourceLocation("lumen", "servericons/" + (iconCounter++));
        DynamicTexture tex;
        String source;
    }

    private enum Mode { NONE, ADD, EDIT, DIRECT, DELETE }

    private final GuiScreen parent;
    private final OldServerPinger oldPinger = new OldServerPinger();
    // ServerData has no public 'pinged' flag in 1.8.9, so track pinged servers here
    private final java.util.Set<ServerData> pinged =
            java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<ServerData, Boolean>());
    private final java.util.Map<ServerData, Icon> icons = new java.util.IdentityHashMap<ServerData, Icon>();
    private final float[] actionHover = new float[ACTIONS.length];
    private float[] rowHover = new float[0];

    private ServerList serverList;
    private final List<LanServerDetector.LanServer> lan = new ArrayList<LanServerDetector.LanServer>();
    private LanServerDetector.LanServerList lanList;
    private LanServerDetector.ThreadLanServerFind lanThread;
    private boolean started;

    private Mode mode = Mode.NONE;
    private ServerData pending;
    private int pendingIndex;

    private int selected = -1;
    private float scroll, scrollTarget;

    // cursor scrolling: drag the scrollbar, or drag the list itself
    private boolean barDrag, listPress, listDragging;
    private float barGrab, pressY, pressScroll;
    private int pressSelected, pressLastRow;
    private long pressLastTime;

    private long start = System.currentTimeMillis();
    private long last = start;
    private float fade;
    private float parX, parY;
    private long lastClickTime;
    private int lastClickRow = -1;

    public LumenServerSelect(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    // ------------------------------------------------------------------------------------------
    // data
    // ------------------------------------------------------------------------------------------

    @Override
    public void initGui() {
        if (!started) {
            started = true;
            serverList = new ServerList(mc);
            serverList.loadServerList();
            lanList = new LanServerDetector.LanServerList();
            try {
                lanThread = new LanServerDetector.ThreadLanServerFind(lanList);
                lanThread.start();
            } catch (Exception ignored) {
                lanThread = null;
            }
            pingAll();
            if (serverList.countServers() > 0) selected = 0;
        }
        syncRows();
    }

    private int serverCount() {
        return serverList == null ? 0 : serverList.countServers();
    }

    private int totalRows() {
        return serverCount() + lan.size();
    }

    private void syncRows() {
        if (rowHover.length != totalRows()) rowHover = new float[totalRows()];
        if (selected >= totalRows()) selected = totalRows() - 1;
    }

    private void pingAll() {
        for (int i = 0; i < serverList.countServers(); i++) ping(serverList.getServerData(i));
    }

    private void ping(final ServerData d) {
        if (!pinged.add(d)) return;
        d.pingToServer = -2L;
        d.serverMOTD = "";
        d.populationInfo = "";
        PINGER.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    oldPinger.ping(d);
                } catch (java.net.UnknownHostException ex) {
                    d.pingToServer = -1L;
                    d.serverMOTD = EnumChatFormatting.DARK_RED + "Can't resolve hostname";
                } catch (Exception ex) {
                    d.pingToServer = -1L;
                    d.serverMOTD = EnumChatFormatting.DARK_RED + "Can't connect to server.";
                }
            }
        });
    }

    @Override
    public void updateScreen() {
        oldPinger.pingPendingNetworks();
        if (lanList != null && lanList.getWasUpdated()) {
            lan.clear();
            lan.addAll(lanList.getLanServers());
            lanList.setWasNotUpdated();
            syncRows();
        }
    }

    @Override
    public void onGuiClosed() {
        oldPinger.clearPendingNetworks();
        for (ServerData d : new ArrayList<ServerData>(icons.keySet())) releaseIcon(d);
    }

    // ------------------------------------------------------------------------------------------
    // server icons
    // ------------------------------------------------------------------------------------------

    /** Texture for the server's favicon (64x64 PNG sent in the ping), or the vanilla "unknown server" icon. */
    private ResourceLocation iconFor(ServerData d) {
        String data = d == null ? null : d.getBase64EncodedIconData();
        if (data == null || data.length() == 0) {
            releaseIcon(d);
            return UNKNOWN_ICON;
        }
        Icon ic = icons.get(d);
        if (ic != null && ic.tex != null && (ic.source == data || data.equals(ic.source))) return ic.loc;
        try {
            byte[] png = java.util.Base64.getMimeDecoder().decode(data);
            BufferedImage img = TextureUtil.readBufferedImage(new ByteArrayInputStream(png));
            if (img == null || img.getWidth() != 64 || img.getHeight() != 64) throw new IllegalStateException("bad icon size");
            if (ic == null) {
                ic = new Icon();
                icons.put(d, ic);
            }
            if (ic.tex == null) {
                ic.tex = new DynamicTexture(64, 64);
                mc.getTextureManager().loadTexture(ic.loc, ic.tex);
            }
            img.getRGB(0, 0, 64, 64, ic.tex.getTextureData(), 0, 64);
            ic.tex.updateDynamicTexture();
            ic.source = data;
            return ic.loc;
        } catch (Throwable ex) {
            // broken favicon: behave like vanilla and forget it so we don't retry every frame
            d.setBase64EncodedIconData(null);
            releaseIcon(d);
            return UNKNOWN_ICON;
        }
    }

    private void releaseIcon(ServerData d) {
        Icon ic = icons.remove(d);
        if (ic != null && ic.tex != null) mc.getTextureManager().deleteTexture(ic.loc);
    }

    private static void drawTexture(ResourceLocation loc, float x, float y, float size, float alpha) {
        Minecraft.getMinecraft().getTextureManager().bindTexture(loc);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1f, 1f, 1f, alpha);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        wr.pos(x, y + size, 0).tex(0, 1).endVertex();
        wr.pos(x + size, y + size, 0).tex(1, 1).endVertex();
        wr.pos(x + size, y, 0).tex(1, 0).endVertex();
        wr.pos(x, y, 0).tex(0, 0).endVertex();
        t.draw();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void stopLan() {
        if (lanThread != null) lanThread.interrupt();
        lanThread = null;
        oldPinger.clearPendingNetworks();
    }

    private void leave() {
        stopLan();
        mc.displayGuiScreen(parent);
    }

    private ServerData dataAt(int i) {
        if (i < 0) return null;
        if (i < serverCount()) return serverList.getServerData(i);
        int l = i - serverCount();
        if (l < lan.size()) {
            LanServerDetector.LanServer s = lan.get(l);
            return new ServerData(s.getServerMotd(), s.getServerIpPort(), true);
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------
    // layout
    // ------------------------------------------------------------------------------------------

    /**
     * Fixed layout factor, so these screens follow the GUI scale setting (a size in GUI units
     * grows/shrinks with it). 0.85 is 0.8x the old height-based size at 1080p / GUI scale 4.
     */
    private float k() {
        return 0.85f;
    }

    private float listTop() {
        return height * 0.27f;
    }

    private float listBottom() {
        return height * 0.80f;
    }

    private float rowH() {
        return 27f * k();
    }

    private float listW() {
        return Math.min(width * 0.8f, 360f * k());
    }

    private float maxScroll() {
        return Math.max(0f, totalRows() * rowH() - (listBottom() - listTop()));
    }

    private float actionScale() {
        float sc = 0.9f * k();
        float gap = 14f * k();
        float total = 0f;
        for (int n = 0; n < ACTIONS.length; n++) total += LumenFont.width(ACTIONS[n]) * sc + (n > 0 ? gap : 0f);
        float max = width * 0.94f;
        return total > max ? sc * max / total : sc;
    }

    private float actionX(int i, float[] outW) {
        float sc = actionScale();
        float gap = 14f * k() * sc / (0.9f * k());
        float total = 0f;
        for (int n = 0; n < ACTIONS.length; n++) {
            outW[n] = LumenFont.width(ACTIONS[n]) * sc;
            total += outW[n] + (n > 0 ? gap : 0f);
        }
        float x = (width - total) / 2f;
        for (int n = 0; n < i; n++) x += outW[n] + gap;
        return x;
    }

    private float actionY() {
        return height * 0.90f;
    }

    private boolean actionEnabled(int i) {
        switch (i) {
            case A_JOIN:
                return selected >= 0 && selected < totalRows();
            case A_EDIT:
            case A_DELETE:
                return selected >= 0 && selected < serverCount();
            default:
                return true;
        }
    }

    private boolean overAction(int i, int mx, int my) {
        float[] w = new float[ACTIONS.length];
        float x = actionX(i, w);
        float pad = 5f * k();
        float cy = actionY();
        return mx >= x - pad && mx <= x + w[i] + pad && my >= cy - 9f * k() && my <= cy + 9f * k();
    }

    private int rowAt(int mx, int my) {
        if (my < listTop() || my > listBottom()) return -1;
        if (mx < (width - listW()) / 2f || mx > (width + listW()) / 2f) return -1;
        int i = (int) ((my - listTop() + scroll) / rowH());
        return i >= 0 && i < totalRows() ? i : -1;
    }

    // ------------------------------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------------------------------

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (float) Math.pow(1f - x, 3);
    }

    private static void text(String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 5) return;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        LumenFont.draw(s, 0f, 0f, color, true);
        GlStateManager.popMatrix();
    }

    private static String plain(String s) {
        if (s == null) return "";
        String t = EnumChatFormatting.getTextWithoutFormattingCodes(s);
        if (t == null) return "";
        int nl = t.indexOf('\n');
        return (nl >= 0 ? t.substring(0, nl) : t).trim();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now - start) / 1000f;
        fade = Math.min(1f, fade + dt * 2.2f);
        float e = 1f - (float) Math.pow(1f - fade, 3);

        float pk = Math.min(1f, dt * 3f);
        parX += (((float) mouseX / Math.max(1, width) - 0.5f) * 2f - parX) * pk;
        parY += (((float) mouseY / Math.max(1, height) - 0.5f) * 2f - parY) * pk;
        float pox = -parX * width * 0.03f, poy = -parY * height * 0.03f;

        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);

        Theme th = Theme.current();
        int tint = Colors.lerp(Colors.opaque(th.c3), Colors.opaque(th.c1), 0.4f);
        float k = k();

        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (th.glass) {
            GlassFx.backdrop(width, height, 1f, now, true, pox, poy);
        } else {
            RenderUtil.gradientV(0, 0, width, height,
                    Colors.lerp(0xFF000000, tint, 0.05f), Colors.lerp(0xFF000000, tint, 0.11f));
        }
        GlStateManager.pushMatrix();
        GlStateManager.translate(pox * 0.5f, poy * 0.5f, 0f);
        Stripes.draw(width, height, t, e);
        GlStateManager.popMatrix();
        if (!th.glass) GlassFx.ambient(width, height, e, now, pox, poy);

        // ---- title ----
        float tScale = 1.5f * k;
        String first = "\u00a7oMulti";
        String rest = "player";
        float tw = (LumenFont.width(first) + LumenFont.width(rest)) * tScale;
        float tx = (width - tw) / 2f;
        float te = ease((t - 0.05f) / 0.6f);
        float ty = height * 0.12f + (1f - te) * 10f * k;
        if (th.glass) {
            GlassFx.pane(tx - 14f * k, ty - 6f * k, tx + tw + 14f * k, ty + LumenFont.EM * tScale + 5f * k, 9f * k, te, 0f);
        }
        text(first, tx, ty, tScale, Colors.mulAlpha(Colors.lerp(Colors.opaque(th.c1), 0xFFFFFFFF, 0.45f), te));
        text(rest, tx + LumenFont.width(first) * tScale, ty, tScale, Colors.mulAlpha(0xFFFFFFFF, te));

        // ---- server list ----
        float lx = (width - listW()) / 2f, lx2 = lx + listW();
        float lt = listTop(), lb = listBottom(), rh = rowH();
        int hoverRow = rowAt(mouseX, mouseY);
        int n = totalRows();

        if (n == 0) {
            String msg = "No servers yet \u2013 add one below";
            float sc = 0.95f * k;
            text(msg, (width - LumenFont.width(msg) * sc) / 2f, (lt + lb) / 2f - LumenFont.EM * sc / 2f, sc,
                    Colors.mulAlpha(0xFFB8BCC6, e));
        } else {
            RenderUtil.scissor(0, lt, width, lb - lt);
            for (int i = 0; i < n; i++) {
                float ry = lt + i * rh - scroll;
                if (ry + rh < lt || ry > lb) continue;
                float ie = ease((t - 0.2f - Math.min(i, 8) * 0.06f) / 0.55f);
                boolean sel = i == selected;
                if (i < rowHover.length) rowHover[i] += (((i == hoverRow) ? 1f : 0f) - rowHover[i]) * Math.min(1f, dt * 14f);
                float h = i < rowHover.length ? rowHover[i] : 0f;
                float lit = Math.max(sel ? 1f : 0f, h * 0.7f);
                float yy = ry + (1f - ie) * 10f * k;

                if (th.glass) {
                    if (lit > 0.02f) GlassFx.pane(lx, yy + 1f * k, lx2, yy + rh - 1f * k, 7f * k, ie, lit);
                } else if (sel) {
                    RenderUtil.gradientH(lx, yy + 1f * k, lx2, yy + rh - 1f * k,
                            Colors.mulAlpha(Colors.withAlpha(th.c1, 34), ie), Colors.mulAlpha(Colors.withAlpha(th.c3, 8), ie));
                } else if (h > 0.02f) {
                    RenderUtil.rect(lx, yy + 1f * k, lx2, yy + rh - 1f * k, Colors.mulAlpha(Colors.withAlpha(0xFFFFFF, 12), h * ie));
                }
                if (sel) {
                    RenderUtil.rect(lx, yy + 3f * k, lx + Math.max(1f, 1.4f * k), yy + rh - 3f * k,
                            Colors.mulAlpha(Colors.opaque(th.c1), ie));
                }

                drawRow(i, lx, lx2, yy, k, ie, Math.max(h, sel ? 1f : 0f));
            }
            RenderUtil.endScissor();

            RenderUtil.gradientV(0, lt - 1f * k, width, lt + 10f * k, Colors.lerp(0xFF000000, tint, 0.05f) & 0x00FFFFFF | 0x66000000, 0x00000000);
            if (maxScroll() > 0f) {
                float trackH = lb - lt;
                float barH = Math.max(14f * k, trackH * trackH / (trackH + maxScroll()));
                float by = lt + (trackH - barH) * (scroll / maxScroll());
                RenderUtil.roundedRect(lx2 + 6f * k, by, lx2 + 6f * k + Math.max(1.5f, 1.6f * k), by + barH,
                        1f * k, Colors.mulAlpha(Colors.withAlpha(th.c1, 160), e));
            }
        }

        // ---- actions (text only) ----
        float asc = actionScale();
        float[] w = new float[ACTIONS.length];
        for (int i = 0; i < ACTIONS.length; i++) {
            float x = actionX(i, w);
            float ae = ease((t - 0.45f - i * 0.05f) / 0.5f);
            boolean en = actionEnabled(i);
            boolean hov = en && overAction(i, mouseX, mouseY);
            actionHover[i] += ((hov ? 1f : 0f) - actionHover[i]) * Math.min(1f, dt * 14f);
            float h = actionHover[i];
            int base = !en ? 0xFF4A4E5A : (i == A_JOIN ? 0xFFFFFFFF : 0xFFB8BCC6);
            int col = Colors.lerp(base, 0xFFFFFFFF, h);
            float sc = asc * (1f + 0.05f * h);
            float sw = LumenFont.width(ACTIONS[i]) * sc;
            float cy = actionY() + (1f - ae) * 8f * k;
            text(ACTIONS[i], x + (w[i] - sw) / 2f, cy - LumenFont.EM * sc / 2f, sc, Colors.mulAlpha(col, ae));
            if (h > 0.02f && !th.glass) {
                float lw = sw * h;
                float ly = cy + LumenFont.EM * sc / 2f + 2f * k;
                float mid = x + w[i] / 2f;
                RenderUtil.gradientH(mid - lw / 2f, ly, mid + lw / 2f, ly + Math.max(1f, k * 0.9f),
                        Colors.mulAlpha(Colors.opaque(th.c1), ae), Colors.mulAlpha(Colors.opaque(th.c3), ae));
            }
        }

        GlStateManager.enableCull();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private void drawRow(int i, float lx, float lx2, float yy, float k, float ie, float active) {
        boolean isLan = i >= serverCount();
        float pad = 10f * k;
        float ns = 0.95f * k, ds = 0.7f * k;
        float isz = rowH() - 7f * k;          // icon edge length
        float ix = lx + 6f * k, iy = yy + 3.5f * k;
        float tx = ix + isz + 7f * k;         // text starts right of the icon
        String name;
        String sub;
        String right;
        int rightCol;
        String ver = null;

        if (isLan) {
            LanServerDetector.LanServer s = lan.get(i - serverCount());
            name = plain(s.getServerMotd());
            sub = "LAN world  \u00b7  " + s.getServerIpPort();
            right = "LAN";
            rightCol = 0xFF9AA0AE;
        } else {
            ServerData d = serverList.getServerData(i);
            name = d.serverName == null ? "" : d.serverName;
            if (d.pingToServer == -2L) {
                sub = "Pinging\u2026";
                right = "";
                rightCol = 0xFF7E8494;
            } else if (d.pingToServer < 0L) {
                sub = plain(d.serverMOTD);
                right = "Offline";
                rightCol = 0xFFE05A5A;
            } else {
                sub = plain(d.serverMOTD);
                right = plain(d.populationInfo);
                rightCol = 0xFFB8BCC6;
                if (d.version != PROTOCOL && d.gameVersion != null && d.gameVersion.length() > 0) ver = plain(d.gameVersion);
            }
        }

        int nameCol = Colors.lerp(0xFFC4C8D2, 0xFFFFFFFF, active);

        // right column: players on top, ping / version below
        float rw = 0f;
        if (right.length() > 0) {
            rw = LumenFont.width(right) * ns;
            text(right, lx2 - pad - rw, yy + 4f * k, ns, Colors.mulAlpha(rightCol, ie));
        }
        if (!isLan) {
            ServerData d = serverList.getServerData(i);
            String low = null;
            int lowCol = 0xFF7E8494;
            if (ver != null) {
                low = ver;
                lowCol = 0xFFE0A24A;
            } else if (d.pingToServer >= 0L) {
                low = d.pingToServer + " ms";
                lowCol = d.pingToServer < 150L ? Colors.opaque(Theme.current().c1)
                        : d.pingToServer < 350L ? 0xFFE0C04A : 0xFFE05A5A;
            }
            if (low != null) {
                float lw = LumenFont.width(low) * ds;
                text(low, lx2 - pad - lw, yy + 4f * k + 11.5f * k, ds, Colors.mulAlpha(lowCol, ie));
            }
        }

        // icon: favicon from the server's ping (saved in servers.dat), vanilla placeholder otherwise
        ServerData iconData = isLan ? null : serverList.getServerData(i);
        boolean offline = !isLan && iconData.pingToServer < 0L && iconData.pingToServer != -2L;
        RenderUtil.rect(ix - 1f * k, iy - 1f * k, ix + isz + 1f * k, iy + isz + 1f * k,
                Colors.mulAlpha(Colors.withAlpha(0xFFFFFF, 10 + (int) (22 * active)), ie));
        drawTexture(iconFor(iconData), ix, iy, isz, ie * (offline ? 0.45f : 1f));

        float leftMax = lx2 - pad - Math.max(rw, 40f * k) - 8f * k - tx;
        text(LumenFont.trim(name, leftMax / ns), tx, yy + 4f * k, ns, Colors.mulAlpha(nameCol, ie));
        text(LumenFont.trim(sub, leftMax / ds), tx, yy + 4f * k + 11.5f * k, ds, Colors.mulAlpha(0xFF7E8494, ie));
    }

    // ------------------------------------------------------------------------------------------
    // input
    // ------------------------------------------------------------------------------------------

    private boolean inList(int mx, int my) {
        return my >= listTop() && my <= listBottom()
                && mx >= (width - listW()) / 2f && mx <= (width + listW()) / 2f;
    }

    private float barH() {
        float trackH = listBottom() - listTop();
        return Math.max(14f * k(), trackH * trackH / (trackH + maxScroll()));
    }

    private float barY() {
        float trackH = listBottom() - listTop();
        return listTop() + (trackH - barH()) * (scroll / maxScroll());
    }

    /** the scrollbar plus a comfortable grab margin around it */
    private boolean overBar(int mx, int my) {
        if (maxScroll() <= 0f) return false;
        float bx = (width + listW()) / 2f + 6f * k();
        return mx >= bx - 6f * k() && mx <= bx + 9f * k() && my >= listTop() && my <= listBottom();
    }

    private void setScroll(float v) {
        scrollTarget = scroll = Math.max(0f, Math.min(maxScroll(), v));
    }

    private void dragBarTo(int my) {
        float range = (listBottom() - listTop()) - barH();
        if (range <= 0f) return;
        setScroll((my - barGrab - listTop()) / range * maxScroll());
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, button, timeSinceLastClick);
        if (barDrag) {
            dragBarTo(mouseY);
        } else if (listPress) {
            if (!listDragging && Math.abs(mouseY - pressY) > 3f) {
                listDragging = true;
                // it was a drag, not a click: undo the selection the press made
                selected = pressSelected;
                lastClickRow = pressLastRow;
                lastClickTime = pressLastTime;
            }
            if (listDragging) setScroll(pressScroll - (mouseY - pressY));
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        barDrag = false;
        listPress = false;
        listDragging = false;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) {
            scrollTarget += d < 0 ? rowH() : -rowH();
            scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        if (button != 0) return;
        for (int i = 0; i < ACTIONS.length; i++) {
            if (actionEnabled(i) && overAction(i, mouseX, mouseY)) {
                Sounds.click();
                runAction(i);
                return;
            }
        }
        if (maxScroll() > 0f && overBar(mouseX, mouseY)) {
            float by = barY(), bh = barH();
            barGrab = (mouseY >= by && mouseY <= by + bh) ? mouseY - by : bh / 2f; // click track = jump there
            barDrag = true;
            dragBarTo(mouseY);
            return;
        }
        pressSelected = selected;
        pressLastRow = lastClickRow;
        pressLastTime = lastClickTime;
        if (inList(mouseX, mouseY) && maxScroll() > 0f) {
            listPress = true;
            listDragging = false;
            pressY = mouseY;
            pressScroll = scroll;
        }
        int row = rowAt(mouseX, mouseY);
        if (row >= 0) {
            long now = System.currentTimeMillis();
            Sounds.click();
            if (row == lastClickRow && now - lastClickTime < 400L) {
                selected = row;
                runAction(A_JOIN);
                return;
            }
            selected = row;
            lastClickRow = row;
            lastClickTime = now;
        }
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) {
            runAction(A_BACK);
        } else if (key == Keyboard.KEY_RETURN) {
            if (actionEnabled(A_JOIN)) runAction(A_JOIN);
        } else if (key == Keyboard.KEY_F5) {
            runAction(A_REFRESH);
        } else if (key == Keyboard.KEY_UP && totalRows() > 0) {
            selected = Math.max(0, selected - 1);
            ensureVisible();
        } else if (key == Keyboard.KEY_DOWN && totalRows() > 0) {
            selected = Math.min(totalRows() - 1, selected + 1);
            ensureVisible();
        }
    }

    private void ensureVisible() {
        float top = selected * rowH(), bottom = top + rowH(), view = listBottom() - listTop();
        if (top < scrollTarget) scrollTarget = top;
        else if (bottom > scrollTarget + view) scrollTarget = bottom - view;
    }

    private void runAction(int action) {
        switch (action) {
            case A_JOIN: {
                ServerData d = dataAt(selected);
                if (d != null) connect(d);
                break;
            }
            case A_DIRECT:
                mode = Mode.DIRECT;
                pending = new ServerData(I18n.format("selectServer.defaultName"), "", false);
                mc.displayGuiScreen(new GuiScreenServerList(this, pending));
                break;
            case A_ADD:
                mode = Mode.ADD;
                pending = new ServerData(I18n.format("selectServer.defaultName"), "", false);
                mc.displayGuiScreen(new GuiScreenAddServer(this, pending));
                break;
            case A_EDIT: {
                ServerData d = serverList.getServerData(selected);
                mode = Mode.EDIT;
                pendingIndex = selected;
                pending = new ServerData(d.serverName, d.serverIP, false);
                pending.copyFrom(d);
                mc.displayGuiScreen(new GuiScreenAddServer(this, pending));
                break;
            }
            case A_DELETE: {
                String name = serverList.getServerData(selected).serverName;
                if (name != null) {
                    mode = Mode.DELETE;
                    pendingIndex = selected;
                    mc.displayGuiScreen(new GuiYesNo(this, I18n.format("selectServer.deleteQuestion"),
                            "'" + name + "' " + I18n.format("selectServer.deleteWarning"),
                            I18n.format("selectServer.deleteButton"), I18n.format("gui.cancel"), selected));
                }
                break;
            }
            case A_REFRESH: {
                int keep = selected;
                oldPinger.clearPendingNetworks();
                serverList.loadServerList();
                pingAll();
                selected = keep;
                syncRows();
                break;
            }
            default:
                leave();
                break;
        }
    }

    private void connect(ServerData d) {
        stopLan();
        mc.displayGuiScreen(new GuiConnecting(this, mc, d));
    }

    /** Result of the add / edit / direct-connect / delete screens. */
    @Override
    public void confirmClicked(boolean result, int id) {
        Mode m = mode;
        mode = Mode.NONE;
        mc.displayGuiScreen(this); // initGui() only re-syncs the rows
        if (m == Mode.DELETE) {
            if (result) {
                releaseIcon(serverList.getServerData(pendingIndex));
                serverList.removeServerData(pendingIndex);
                serverList.saveServerList();
                selected = Math.min(selected, serverCount() - 1);
                syncRows();
            }
        } else if (m == Mode.ADD) {
            if (result) {
                serverList.addServerData(pending);
                serverList.saveServerList();
                selected = serverCount() - 1;
                ping(pending);
                syncRows();
                ensureVisible();
            }
        } else if (m == Mode.EDIT) {
            if (result) {
                ServerData d = serverList.getServerData(pendingIndex);
                boolean sameIp = d.serverIP != null && d.serverIP.equals(pending.serverIP);
                d.serverName = pending.serverName;
                d.serverIP = pending.serverIP;
                d.copyFrom(pending);
                if (!sameIp) d.setBase64EncodedIconData(null); // stale icon of the old address
                serverList.saveServerList();
                pinged.remove(d);
                ping(d);
            }
        } else if (m == Mode.DIRECT) {
            if (result) connect(pending);
        }
    }
}
