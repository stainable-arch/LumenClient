package com.lumen.client;

import com.lumen.client.core.BooleanSetting;
import com.lumen.client.core.NumberSetting;

/** Global client toggles that are not tied to a single module. */
public final class ClientSettings {
    public static boolean sounds = true;
    /** Cosmetics for Lumen users (currently the Lumen cape; no options yet). */
    public static boolean cosmetics = true;
    /** Cosmetics option: the black cape with a white "claude" in the Winkle font. */
    public static final BooleanSetting cape = new BooleanSetting("Black cape", true);
    /** Cosmetics option: a Tung Tung Tung Sahur pet that walks beside the player. */
    public static final BooleanSetting sahurPet = new BooleanSetting("Tung Tung Sahur pet", false);
    /** "cute": a picture in the bottom-left of the ClickGUI (Settings page). */
    public static boolean cute = false;
    public static final NumberSetting cuteScale = new NumberSetting("Scale", 1.0, 0.3, 3.0, 0.05);
    /** Top-left corner of the picture as a fraction of the screen; negative = default bottom-left spot. */
    public static float cuteX = -1f, cuteY = -1f;
    /** Which ClickGUI layout is used (General > Settings > Gui). Only the current one exists so far; add names here for new GUIs. */
    public static final com.lumen.client.core.ModeSetting gui = new com.lumen.client.core.ModeSetting("Gui", "Default", "Default");
    /** Resource pack screen: packs can be dragged between and inside the lists. */
    public static boolean packDraggable = true;

    /** Hypixel API key used by the Level Head module (set with /lumen apikey). */
    public static String hypixelKey = "";

    /** Voxyl (bedwarspractice.club) API key used by Level Head's Bedwars Practice source (set with /lumen voxylkey). */
    public static String voxylKey = "";


    /** Checkboxes of the Options screen (gear button, top right of the ClickGUI), in display order. */
    public static final java.util.List<BooleanSetting> OPTIONS = new java.util.ArrayList<BooleanSetting>();

    /** Registers a new checkbox for the Options screen. Its label doubles as the config key. */
    public static BooleanSetting option(String label, boolean def) {
        BooleanSetting b = new BooleanSetting(label, def);
        OPTIONS.add(b);
        return b;
    }

    /** Off = no grass, ferns, flowers or double plants are rendered. */
    public static final BooleanSetting renderFoliage = option("Render Foliage", true);

    /** On = the camera does not bob while walking; the hand keeps bobbing. */
    public static final BooleanSetting minimalViewBobbing = option("Minimal View Bobbing", false);

    /** On = no camera shake when you take damage. */
    public static final BooleanSetting noHurtCam = option("No Hurt Cam", false);

    private ClientSettings() {}
}
