package com.lumen.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Bitmap renderer for the Winkle font (baked into assets/lumen/fonts/winkle.png by tools/gen_font_atlas.py).
 * No java.awt.Font is used, so it also works on launchers whose JRE has no font support.
 * If the atlas can't be loaded it silently falls back to the vanilla font.
 *
 * Sizes are in "logical pixels" at scale 1: the em is EM px tall (vanilla text is 8). Callers scale with GL.
 * Supports the vanilla italic (§o), reset (§r) and colour (§x) codes; colour codes are skipped.
 */
public final class LumenFont {
    /** Height of one em in logical pixels at scale 1. */
    public static final float EM = 10f;
    private static final float BASELINE = 0.76f * EM;

    private static final Minecraft mc = Minecraft.getMinecraft();

    private static boolean loaded, failed;
    private static ResourceLocation tex;
    private static int atlasW, atlasH;
    private static float rasterSize, spaceAdv;
    // per char: advance, u, v, w, h, xoff, yoff (all in atlas px)
    private static final float[][] G = new float[128][];

    private LumenFont() {}

    private static boolean ready() {
        if (loaded) return true;
        if (failed) return false;
        try {
            InputStream in = mc.getResourceManager()
                    .getResource(new ResourceLocation("lumen", "fonts/winkle.txt")).getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String[] head = br.readLine().trim().split(" ");
            rasterSize = Float.parseFloat(head[0]);
            spaceAdv = Float.parseFloat(head[1]);
            atlasW = Integer.parseInt(head[2]);
            atlasH = Integer.parseInt(head[3]);
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.length() == 0) continue;
                String[] p = line.split(" ");
                int code = Integer.parseInt(p[0]);
                float[] g = new float[7];
                for (int i = 0; i < 7; i++) g[i] = Float.parseFloat(p[i + 1]);
                if (code >= 0 && code < 128) G[code] = g;
            }
            br.close();

            InputStream pin = mc.getResourceManager()
                    .getResource(new ResourceLocation("lumen", "fonts/winkle.png")).getInputStream();
            BufferedImage img = ImageIO.read(pin);
            pin.close();
            DynamicTexture dt = new DynamicTexture(img);
            tex = mc.getTextureManager().getDynamicTextureLocation("lumenclient_winkle", dt);
            // smooth scaling: the atlas is drawn at many sizes
            GlStateManager.bindTexture(dt.getGlTextureId());
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            loaded = true;
        } catch (Throwable t) {
            failed = true;
        }
        return loaded;
    }

    private static float scale() {
        return EM / rasterSize;
    }

    private static float advance(char c) {
        if (c == ' ') return spaceAdv * scale();
        float[] g = c < 128 ? G[c] : null;
        if (g == null) g = G['?'];
        return g == null ? spaceAdv * scale() : g[0] * scale();
    }

    /** Width in logical pixels at scale 1 (formatting codes are not counted). */
    public static float width(String s) {
        if (!ready()) return mc.fontRendererObj.getStringWidth(s);
        float w = 0f;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '§' && i + 1 < s.length()) {
                i++;
                continue;
            }
            w += advance(c);
        }
        return w;
    }

    /** Longest prefix of s that fits into maxW (scale-1 pixels). */
    public static String trim(String s, float maxW) {
        if (!ready()) return mc.fontRendererObj.trimStringToWidth(s, (int) maxW);
        float w = 0f;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '§' && i + 1 < s.length()) {
                i++;
                continue;
            }
            w += advance(c);
            if (w > maxW) return s.substring(0, i);
        }
        return s;
    }

    /** Draws s with its top-left at (x, y) at scale 1. Colour is ARGB. */
    public static void draw(String s, float x, float y, int color, boolean shadow) {
        if (((color >>> 24) & 255) < 5) return;
        if (!ready()) {
            if (shadow) mc.fontRendererObj.drawStringWithShadow(s, x, y, color);
            else mc.fontRendererObj.drawString(s, x, y, color, false);
            return;
        }
        mc.getTextureManager().bindTexture(tex);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        if (shadow) {
            int a = (color >>> 24) & 255;
            int sh = (a * 110 / 255) << 24 | ((color & 0xFCFCFC) >> 2);
            run(s, x + 0.7f, y + 0.7f, sh);
        }
        run(s, x, y, color);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void run(String s, float x, float y, int color) {
        GlStateManager.color(((color >> 16) & 255) / 255f, ((color >> 8) & 255) / 255f,
                (color & 255) / 255f, ((color >>> 24) & 255) / 255f);
        float k = scale();
        float base = y + BASELINE;
        boolean italic = false;
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        float pen = x;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '§' && i + 1 < s.length()) {
                char f = Character.toLowerCase(s.charAt(++i));
                if (f == 'o') italic = true;
                else if (f == 'r' || (f >= '0' && f <= '9') || (f >= 'a' && f <= 'f')) italic = false;
                continue;
            }
            float[] g = (c < 128 && c != ' ') ? G[c] : null;
            if (g == null && c != ' ') g = G['?'];
            if (g != null) {
                float gx = pen + g[5] * k, gy = base + g[6] * k;
                float gw = g[3] * k, gh = g[4] * k;
                float u1 = g[1] / atlasW, v1 = g[2] / atlasH;
                float u2 = (g[1] + g[3]) / atlasW, v2 = (g[2] + g[4]) / atlasH;
                float sk = italic ? 0.22f * gh : 0f; // shear the top edge to the right
                wr.pos(gx, gy + gh, 0).tex(u1, v2).endVertex();
                wr.pos(gx + gw, gy + gh, 0).tex(u2, v2).endVertex();
                wr.pos(gx + gw + sk, gy, 0).tex(u2, v1).endVertex();
                wr.pos(gx + sk, gy, 0).tex(u1, v1).endVertex();
            }
            pen += advance(c);
        }
        t.draw();
    }
}
